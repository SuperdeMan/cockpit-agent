# Aurora Glass · 极光液态座舱 — 设计契约 v1.0

> **本文件是唯一真相来源。** A-2 至 A-8 所有页面必须在动笔前先读本契约，优先复用已有 tokens 与组件，不得重建设计系统。

---

## 1 · 项目目标

| 维度 | 值 |
|---|---|
| 产品 | 智能座舱 AI 语音助手「小舟」|
| 画布 | 1920 × 1080 px，横屏，车机中控大屏 |
| 场景 | 泊车态（主交互）/ 行车态（受限）/ 阳光下（浅色高对比）|
| 气质 | 深邃 · Premium · 有生命感 · 可信赖 |
| 禁止 | SaaS 后台感、廉价玻璃、彩虹乱用、过曝炫光 |

融合参考：Tesla 地图极简 · 鸿蒙/小米卡片流畅 · NIO NOMI 人格化化身 · 奔驰 MBUX 玻璃奢华 · 宝马 iDrive 仪表精密 · iOS 液态玻璃材质

---

## 2 · 视觉气质与三层 z-index 体系

```
Layer 0 — 活的场景（底）：地图 / 极光氛围，始终可见，越深越模糊
Layer 1 — 液态玻璃面板（中）：所有卡片/面板，必须折射 Layer 0
Layer 2 — 悬浮控件（前）：光球 / 确认条 / Tooltip，最高层级
```

玻璃面板必须能透出背后内容（backdrop-filter 生效为前提）。

---

## 3 · 色彩系统

### 3-A 深色主题（默认）

```
深空底色：
  #06080F  Space-950（页面最底层背景）
  #0A0E1A  Space-900
  #0F1525  Space-800
  #151D30  Space-700
  #1C2540  Space-600
  #243055  Space-500

文字三级冷白灰阶（正文绝不上虹彩）：
  rgba(255,255,255,0.92)  Primary   ≥ 8.5:1
  rgba(255,255,255,0.56)  Secondary ≥ 4.5:1
  rgba(255,255,255,0.32)  Tertiary  ≥ 3.0:1

分隔线：rgba(255,255,255,0.07)

交互蓝（非 AI 时刻唯一高亮色）：#46D6E0

语义色（实色，绝不虹彩化，A股红涨绿跌）：
  涨   #EF4444    跌   #22C55E
  置信高 #46D6E0  置信中 #F59E0B  置信低 #6B7280
  危险 #EF4444    在线 #34D399   警告文字 #F59E0B

AQI 7 档：
  优 0–50     #34D399    良 51–100   #A3E635
  轻度 101–150 #FCD34D   中度 151–200 #FB923C
  重度 201–300 #EF4444   严重 301+   #9333EA
  未知         #6B7280
```

### 3-B 浅色主题（阳光下/磨砂白）

```
背景：    #EDF1FA / #E4EBF7
玻璃底：  rgba(255,255,255,0.76)
文字：    rgba(10,14,26,0.92 / 0.55 / 0.30)
```

---

## 4 · AI 签名渐变（极光）

```css
/* 线性版（用于 border、button、text-fill）*/
--aurora: linear-gradient(135deg,
  #5BE9FF 0%,    /* Aurora Cyan    */
  #5B8CFF 33%,   /* Aurora Blue    */
  #9A6BFF 66%,   /* Aurora Violet  */
  #FF6BD6 100%); /* Aurora Magenta */

/* Conic 版（用于光球内部旋转层）*/
--aurora-conic: conic-gradient(from 0deg,
  #5BE9FF, #5B8CFF, #9A6BFF, #FF6BD6, #5BE9FF);
```

**渐变文字：**
```css
background: var(--aurora);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
background-clip: text;
```

**AI 内容描边（AuroraBorder 组件）：**
```jsx
// wrapper: padding=1.5px, background=aurora, border-radius=r+1.5px
// 内层 Glass 正常渲染，外层 1.5px 极光环即为描边
box-shadow: 0 0 28px rgba(91,140,255,.18), 0 0 56px rgba(154,107,255,.10);
```

---

## 5 · 极光使用铁律

### ✓ 允许（仅限以下 5 处）

| 场景 | 用法 |
|---|---|
| 小舟光球 AuroraOrb | 极光流动，设计记忆点 |
| 聆听/思考态屏幕边缘 | 2px aurora border 呼吸辉光，类 Siri 激活态 |
| AI 流式输出虹彩光标 | 微光扫过动效 + 关键词极光文字 |
| AI 生成内容描边/角标 | 1–1.5px 虹彩细描边，标识 AI 来源 |
| 主操作按钮 | 虹彩填充或虹彩描边 |

### ✗ 绝对禁止

- 正文段落使用极光渐变色
- 车速/温度/价格等关键数字使用虹彩
- 玻璃面板背景使用彩虹渐变
- 语义色（涨/跌/警告/危险）虹彩化
- 普通功能图标极光描边
- 装饰纹理/分割线/背景使用极光

> 铁律：极光只在「AI 时刻」出现，其余交互用 `#46D6E0`。

---

## 6 · 液态玻璃材质规格

### 深色模式

```css
background: rgba(255,255,255, 0.056);
backdrop-filter: blur(32px) saturate(1.15);
-webkit-backdrop-filter: blur(32px) saturate(1.15);
border-top:    1px solid rgba(255,255,255, 0.17);  /* 顶缘高光 */
border-left:   1px solid rgba(255,255,255, 0.13);  /* 左缘高光 */
border-right:  1px solid rgba(255,255,255, 0.07);
border-bottom: 1px solid rgba(255,255,255, 0.05);
border-radius: 24px;  /* squircle，推荐默认值 */
box-shadow:
  0 8px 40px rgba(0,0,0, 0.50),
  0 2px 12px rgba(0,0,0, 0.28),
  inset 0 1px 0 rgba(255,255,255, 0.13);  /* 内顶高光（悬浮感关键）*/
/* 可叠冷色 tint：rgba(180,220,255, 0.08–0.11) */
```

### 浅色模式（磨砂白）

```css
background: rgba(255,255,255, 0.76);
backdrop-filter: blur(32px);
border-top:  1px solid rgba(255,255,255, 1.00);
border-left: 1px solid rgba(255,255,255, 1.00);
border-radius: 24px;
box-shadow:
  0 8px 32px rgba(10,14,26, 0.09),
  0 2px  8px rgba(10,14,26, 0.05),
  inset 0 1px 0 rgba(255,255,255, 1.00);
```

### 参数范围一览

| 属性 | 深色 | 浅色 |
|---|---|---|
| 背景透明度 | 5.6% | 76% |
| 模糊半径 | 28–40px（推荐 32px）| 28–40px |
| 冷色 tint | rgba(180,220,255, 8–11%) | 无 |
| 圆角 squircle | 20–28px（推荐 24px）| 同左 |
| 行车态降级 | blur 降至 20px，不透明度升至 10% | — |

---

## 7 · 字体与数字排印

### 字体族

```
中文正文 / UI 汉字：'Noto Sans SC', 'PingFang SC', sans-serif
拉丁字符 / UI 英文：'Inter', -apple-system, sans-serif
仪表数字（车速/温度/价格/ms）：'JetBrains Mono', monospace

完整栈：'Inter', 'Noto Sans SC', -apple-system, sans-serif
```

**铁律：所有数值类数据（车速/温度/价格/距离/时间戳数字）必须使用 JetBrains Mono，不得使用比例字体。**

### 字阶

| 级别 | 大小 | 字重 | 字距 | 用途 |
|---|---|---|---|---|
| Display | 48px | 700 | -0.03em | 欢迎语、空态大标题 |
| H1 | 32px | 600 | -0.02em | 页面主标题 |
| H2 | 24px | 500 | -0.01em | 分区/卡片标题 |
| H3 | 18px | 500 | 0 | 子项标题 |
| Body | 15px | 400 | +0.01em | 正文、对话气泡 |
| Caption | 12px | 400 | +0.02em | 标签、时间戳 |
| **Mono·Data** | **32px** | **700** | **-0.025em** | **车速/温度/里程（仪表级）** |
| Mono·SM | 14px | 500 | 0 | 小数值、代码标签 |

---

## 8 · 间距、圆角、阴影、z-index

### 间距（4px 基准网格）

| Token | 值 | 典型用途 |
|---|---|---|
| 4 | 4px | 图标内边距 |
| 8 | 8px | 行内紧凑间距 |
| 12 | 12px | 同组元素 |
| 16 | 16px | 卡片内间距 |
| **24** | **24px** | **卡片内边距（推荐默认）** |
| 32 | 32px | 区块间距 |
| 48 | 48px | 分区间距 |
| 64 | 64px | 页面分区 |

### 圆角（squircle 连续曲率）

| Token | 值 | 用途 |
|---|---|---|
| sm | 6–8px | 标签、图标背景 |
| md | 10–12px | 按钮、输入框 |
| lg | 14–16px | 小卡片 |
| xl | 18–20px | 标准卡片 |
| **2xl** | **24px** | **主面板（推荐默认）** |
| 3xl | 28px | 覆盖层、大卡片 |
| full | 9999px | 胶囊、光球 |

### 阴影 tokens

| Token | 值 | 用途 |
|---|---|---|
| glass-sm | 0 4px 16px rgba(0,0,0,.30) | 小卡片悬浮 |
| glass-md | 0 8px 32px rgba(0,0,0,.44) | 标准卡片 |
| glass-lg | 0 16px 48px rgba(0,0,0,.55) | 主面板 |
| aurora | 0 0 32px rgba(91,142,255,.45) | AI 光球辉光 |
| teal | 0 4px 18px rgba(70,214,224,.40) | 交互高亮 |

### z-index 层级

```
z-0  — 活的场景背景（地图/极光氛围）
z-5  — 右侧上下文舞台
z-10 — 液态玻璃面板（对话/卡片）
z-20 — 底部输入区 / 顶部状态栏
z-30 — 全局 Header（sticky）
z-40 — 弹层 / 确认条 / Tooltip
z-50 — AuroraOrb 光球（最前）
```

---

## 9 · 组件清单（已实现，禁止重建）

后续页面直接在同一 `App.tsx` 中引用或迁移以下组件定义，不得重新实现：

| 组件名 | 功能 | 关键 props |
|---|---|---|
| `AuroraOrb` / `Orb` | 小舟光球 | `size`, `state: idle/thinking/speaking` |
| `GlassCard` / `Glass` | 液态玻璃容器 | `p`, `r`, `light`, `style` |
| `AuroraBorder` | AI 内容虹彩描边包装器 | `r` |
| `ConfBadge` | 置信度徽章（高/中/低）| `level`, `small` |
| `CatChip` | 类别芯片（带语义色点）| `cat` |
| `AQISection` / `AQISec` | AQI 7档色阶 + 高亮 | `aqi` |
| `CandlestickChart` / `KChart` | A股日K线 SVG | `candles` |
| `WeatherCard` / `WCard` | 气象卡三态 | `data`, `variant` |
| `StockCard` / `SCard` | 股票卡三态 | `data`, `variant` |
| `SearchCard` | 联网搜索证据卡 | 内置 state |
| `NewsCard` | 新闻速览卡 | 内置 state |
| `ResearchCard` + `RSection` | 深度调研报告卡 | 内置 state |

---

## 10 · 小舟 AuroraOrb 三态规格

| 状态 | 触发场景 | 外环旋速 | 内环旋速 | 呼吸动效 | 辉光倍率 | 附加效果 |
|---|---|---|---|---|---|---|
| **idle** | 无任务 | 8s | 5s | 4s ease-in-out | 1× | 可朝内容微倾 ±4° / -6px |
| **thinking** | AI 处理中 | 1.6s | 1.1s | 1.4s（加速）| 1× | 屏幕边缘 2px aurora border 呼吸 |
| **speaking** | AI 语音输出 | 8s | 5s | pulse 0.72s（scale 0.96–1.07）| 1.35× | 向外 3 层同心圆波纹，颜色 #46D6E0 |

**波纹颜色必须用 `#46D6E0`（交互蓝），非极光，保持极光的 AI 专属克制性。**

行车态：动效频率 × 0.5，opacity × 0.6，`prefers-reduced-motion` 时动效 duration 强制为 0.01ms。

---

## 11 · 车规可读性护栏

### 对比度要求

| 文字场景 | 最低对比度 | 方法 |
|---|---|---|
| 正文 / 关键数据 | ≥ 4.5:1 (AA) | text-primary 92% 白 |
| 大字标题 (≥18px bold) | ≥ 3.0:1 | text-secondary 56% |
| 仪表数字（车速/温度）| ≥ 7:1 | JetBrains Mono 实色 |

### 文字保护规则

- 任何文字下方必须有玻璃面板或 scrim（`linear-gradient(to top, rgba(6,8,15,.70), transparent)`）
- 明亮地图区玻璃自动加深：背景透明度升至 ≥ 12%
- 地图直接压文字：禁止

### 行车态降级

```
backdrop-filter blur：32px → 20px（节省 GPU）
玻璃背景不透明度：5.6% → 10%
极光辉光 opacity：× 0.6
动效频率：× 0.5
不在主视野区使用脉动/旋转动效
```

### 触控目标尺寸

| 场景 | 最小触控区域 |
|---|---|
| 泊车态 | 48 × 48px |
| 行车态 | 56 × 56px |
| 芯片/按钮最小高度 | 32px（静止）/ 44px（行车）|

---

## 12 · 浅色主题与阳光下规则

| 规则 | 值 |
|---|---|
| 背景 | #EDF1FA / #E4EBF7 |
| 玻璃 | rgba(255,255,255, 0.76) + blur(32px)，去除冷色 tint |
| 边缘高光 | rgba(255,255,255, 1.0) 顶缘/左缘 |
| 文字 | rgba(10,14,26, 0.92 / 0.55 / 0.30) |
| 极光辉光 | box-shadow 强度 × 0.5，收敛不过曝 |
| 语义色 | 保持实色，必要时加深 20% 提高对比 |
| 投影 | rgba(10,14,26, 0.08–0.12) |

**阳光下原则：收敛辉光 → 提高不透明度 → 加深投影 → 仪表数字绝对可读。**

---

## 13 · 后续页面开发规范

### 每个新页面必须做

1. 读本契约后再动笔
2. 复用 §9 组件清单中的组件，不重建
3. 数值类数据一律 `JetBrains Mono`
4. 极光只用于 §5 允许的 5 处
5. 置信度用语义色（高=`#46D6E0` / 中=`#F59E0B` / 低=`#6B7280`）
6. A股：红涨（`#EF4444`）绿跌（`#22C55E`），绝不反向
7. 新增组件先在本文件 §9 末尾追加记录，再实现

### 禁止

- 引入新字体族（只允许 Inter / Noto Sans SC / JetBrains Mono）
- 创建平行色彩体系
- 用 CSS 类或 Tailwind 工具类覆盖玻璃层（会破坏 backdrop-filter）
- 在正文、数字、语义色上使用极光渐变
- 重建 AuroraOrb 或 GlassCard

### 引用声明模板

在每个新页面 `App.tsx` 顶部注释：

```tsx
// Design contract: guidelines/Guidelines.md
// Reused: AuroraOrb, Glass, AuroraBorder, ConfBadge, [其他组件]
// DO NOT rebuild design system tokens or components.
```

---

*Aurora Glass · 极光液态座舱 · Design Contract v1.0 · 2025-06-29*
