// Design contract: guidelines/Guidelines.md
// Page: A-3 卡片族 1 · 气象 + 金融
// Reused: AuroraOrb, GlassCard, AURORA, AURORA_CONIC, AURORA_TEXT, TEAL, FG1/2/3, DIV, KEYFRAMES
// New:    WCard, SCard, KChart, AQISec, AuroraBorder, ConfBadge, EmptyW, EmptyS

import { useState, useMemo, CSSProperties, ReactNode } from "react";

// ─── Design Tokens (§3 Guidelines.md) ────────────────────────────────────────
const AURORA       = "linear-gradient(135deg,#5BE9FF 0%,#5B8CFF 33%,#9A6BFF 66%,#FF6BD6 100%)";
const AURORA_CONIC = "conic-gradient(from 0deg,#5BE9FF,#5B8CFF,#9A6BFF,#FF6BD6,#5BE9FF)";
const AURORA_TEXT: CSSProperties = {
  background: AURORA, WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent", backgroundClip: "text",
};
const TEAL = "#46D6E0";
const UP   = "#EF4444";   // A股红涨 (§3-A 铁律)
const DN   = "#22C55E";   // A股绿跌
const FG1  = "rgba(255,255,255,0.92)";
const FG2  = "rgba(255,255,255,0.56)";
const FG3  = "rgba(255,255,255,0.32)";
const DIV  = "rgba(255,255,255,0.07)";

// Confidence semantic colours (§6 Guidelines: §3-A)
const CONF: Record<string, { c: string; bg: string; bc: string }> = {
  高: { c: TEAL,      bg: "rgba(70,214,224,.11)",  bc: "rgba(70,214,224,.26)"  },
  中: { c: "#F59E0B", bg: "rgba(245,158,11,.11)",  bc: "rgba(245,158,11,.26)"  },
  低: { c: "#6B7280", bg: "rgba(107,114,128,.11)", bc: "rgba(107,114,128,.24)" },
};

// AQI 7-tier spec (§3-A)
const AQI_TIERS = [
  { label: "优",   range: "0–50",    hex: "#34D399" },
  { label: "良",   range: "51–100",  hex: "#A3E635" },
  { label: "轻度", range: "101–150", hex: "#FCD34D" },
  { label: "中度", range: "151–200", hex: "#FB923C" },
  { label: "重度", range: "201–300", hex: "#EF4444" },
  { label: "严重", range: "301+",    hex: "#9333EA" },
  { label: "未知", range: "—",       hex: "#6B7280" },
];

const TIP_COLOR: Record<string, string> = {
  good: "#34D399", mid: "#F59E0B", warn: "#FB923C", bad: "#EF4444",
};

// ─── Keyframes (§8, §10) ─────────────────────────────────────────────────────
const KEYFRAMES = `
  @keyframes aurora-breathe {
    0%,100%{opacity:.82;transform:scale(1)} 50%{opacity:1;transform:scale(1.038)}
  }
  @keyframes aurora-breathe-fast {
    0%,100%{opacity:.85;transform:scale(1)} 50%{opacity:1;transform:scale(1.045)}
  }
  @keyframes aurora-spin {
    from{transform:rotate(0deg)} to{transform:rotate(360deg)}
  }
  @keyframes aurora-spin-r {
    from{transform:rotate(360deg)} to{transform:rotate(0deg)}
  }
  @keyframes aurora-pulse {
    0%,100%{transform:scale(1);opacity:.86}
    25%{transform:scale(1.07);opacity:1}
    75%{transform:scale(0.96);opacity:.80}
  }
  *{scrollbar-width:none}
  *::-webkit-scrollbar{display:none}
  @media(prefers-reduced-motion:reduce){*{animation-duration:.01ms!important}}
`;

// ─── Data ─────────────────────────────────────────────────────────────────────
type AQIData = { value: number; grade: string; hex: string } | null;
type Tip     = { label: string; value: string; icon: string; level: string };
type Candle  = { date: string; open: number; close: number; high: number; low: number; vol: number };

interface WData {
  city: string; temp: number; feels: number | null; condition: string;
  humidity: number | null; wind: string | null;
  visibility: number | null; pressure: number | null; precip: number | null;
  aqi: AQIData;
  forecast: { day: string; icon: string; cond: string; low: number; high: number }[];
  tips: Tip[] | null;
  alert: { text: string; desc: string } | null;
  updated: string; valid: string;
}
interface SData {
  name: string; ticker: string; exchange: string;
  price: number; change: number; changePct: number;
  open: number; high: number; low: number; prevClose: number;
  marketCap: string | null; pe: number | null; pb: number | null; vol: string | null;
  candles: Candle[] | null;
  marketStatus: string; closedAt: string;
}

const FULL_W: WData = {
  city: "杭州", temp: 28, feels: 30, condition: "多云",
  humidity: 65, wind: "东南风3级", visibility: 24, pressure: 1008, precip: 0.2,
  aqi: { value: 68, grade: "良", hex: "#A3E635" },
  forecast: [
    { day: "今天", icon: "⛅", cond: "多云",  low: 24, high: 30 },
    { day: "明天", icon: "🌧️", cond: "阵雨",  low: 23, high: 27 },
    { day: "后天", icon: "☀️", cond: "晴",    low: 25, high: 32 },
  ],
  tips: [
    { label: "洗车",   value: "适宜",  icon: "🚗",  level: "good" },
    { label: "紫外线", value: "中等",  icon: "🌤️", level: "mid"  },
    { label: "穿衣",   value: "短袖",  icon: "👕",  level: "good" },
    { label: "感冒",   value: "较易发", icon: "🤧", level: "warn" },
  ],
  alert: { text: "⚡ 雷电黄色预警", desc: "未来6小时内可能有雷雨大风，请注意防范" },
  updated: "17:30", valid: "20:00",
};
const DEG_W: WData = { ...FULL_W, feels: null, humidity: null, wind: null, precip: null, aqi: null, alert: null, tips: null };

const CANDLES: Candle[] = [
  { date: "6/23", open: 1645.00, close: 1658.50, high: 1672.00, low: 1638.00, vol: 12500 },
  { date: "6/24", open: 1658.50, close: 1651.00, high: 1669.00, low: 1644.00, vol: 9800  },
  { date: "6/25", open: 1651.00, close: 1675.50, high: 1682.00, low: 1648.00, vol: 15200 },
  { date: "6/26", open: 1675.50, close: 1669.00, high: 1688.50, low: 1662.00, vol: 11400 },
  { date: "6/27", open: 1669.00, close: 1689.00, high: 1695.00, low: 1665.00, vol: 18900 },
];
const FULL_S: SData = {
  name: "贵州茅台", ticker: "600519", exchange: "SH",
  price: 1689.00, change: 12.50, changePct: 0.75,
  open: 1669.00, high: 1695.00, low: 1662.00, prevClose: 1676.50,
  marketCap: "21,234亿", pe: 32.4, pb: 12.8, vol: "1.89万手",
  candles: CANDLES, marketStatus: "已收盘", closedAt: "15:00",
};
const DEG_S: SData = { ...FULL_S, candles: null, marketCap: null, pe: null, pb: null, vol: null };

// ─── AuroraOrb (reused, §9) ───────────────────────────────────────────────────
type OrbState = "idle" | "thinking" | "speaking";
function AuroraOrb({ state = "idle", size = 40 }: { state?: OrbState; size?: number }) {
  const thinking  = state === "thinking";
  const speaking  = state === "speaking";
  const glowMult  = speaking ? 1.35 : 1;
  const outerAnim = thinking ? "aurora-breathe-fast 1.4s ease-in-out infinite"
                  : speaking  ? "aurora-pulse 0.72s ease-in-out infinite"
                  :             "aurora-breathe 4s ease-in-out infinite";
  const haloSpeed  = thinking ? "1.6s" : "8s";
  const innerSpeed = thinking ? "1.1s" : "5s";
  const ctSpeed    = thinking ? "0.8s" : "3.8s";
  const s = size;
  return (
    <div style={{ position: "relative", width: s, height: s, flexShrink: 0 }}>
      <div style={{ position: "absolute", inset: -s*.52, borderRadius: "50%", background: `radial-gradient(circle,rgba(91,140,255,${.20*glowMult}) 0%,rgba(154,107,255,${.11*glowMult}) 40%,transparent 70%)`, animation: outerAnim, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: -s*.06, borderRadius: "50%", background: AURORA_CONIC, opacity: thinking?.52:.26, filter: `blur(${s*.115}px)`, animation: `aurora-spin ${haloSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: 0, borderRadius: "50%", background: `radial-gradient(circle at 36% 28%,rgba(255,255,255,.44) 0%,rgba(91,233,255,.22) 28%,rgba(91,140,255,.18) 56%,rgba(154,107,255,.26) 78%,rgba(255,107,214,.14) 100%)`, backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)", border: "1px solid rgba(255,255,255,.24)", boxShadow: `0 0 ${s*.32*glowMult}px rgba(91,142,255,.52),0 0 ${s*.70*glowMult}px rgba(154,107,255,.22),inset 0 0 ${s*.24}px rgba(91,233,255,.20),inset 0 ${s*.012}px 0 rgba(255,255,255,.34)`, animation: outerAnim, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: s*.16, borderRadius: "50%", background: AURORA_CONIC, opacity: .70, filter: `blur(${s*.036}px)`, animation: `aurora-spin ${innerSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: s*.28, borderRadius: "50%", background: `conic-gradient(from 180deg,#9A6BFF,#5B8CFF,#5BE9FF,#FF6BD6,#9A6BFF)`, opacity: .54, filter: `blur(${s*.028}px)`, animation: `aurora-spin-r ${ctSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", top: "9%", left: "13%", width: "44%", height: "33%", borderRadius: "50%", background: "radial-gradient(ellipse,rgba(255,255,255,.70) 0%,transparent 100%)", filter: "blur(2px)", pointerEvents: "none" }} />
    </div>
  );
}

// ─── GlassCard (reused, §6) ───────────────────────────────────────────────────
function GlassCard({ children, p = 0, r = 24, style }: { children?: ReactNode; p?: number; r?: number; style?: CSSProperties }) {
  return (
    <div style={{
      padding: p, borderRadius: r, overflow: "hidden",
      background: "rgba(255,255,255,.056)",
      backdropFilter: "blur(32px)", WebkitBackdropFilter: "blur(32px)",
      border: "1px solid rgba(255,255,255,.10)",
      borderTop: "1px solid rgba(255,255,255,.17)",
      borderLeft: "1px solid rgba(255,255,255,.13)",
      boxShadow: "0 8px 40px rgba(0,0,0,.50),0 2px 12px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.13)",
      ...style,
    }}>{children}</div>
  );
}

// ─── AuroraBorder — AI内容虹彩细描边 (§5 allowed) ───────────────────────────
function AuroraBorder({ children, r = 24 }: { children: ReactNode; r?: number }) {
  return (
    <div style={{ padding: 1.5, borderRadius: r + 1.5, background: AURORA, boxShadow: "0 0 28px rgba(91,140,255,.18),0 0 56px rgba(154,107,255,.10)" }}>
      <div style={{ borderRadius: r, overflow: "hidden" }}>{children}</div>
    </div>
  );
}

const HR = () => <div style={{ height: 1, background: DIV }} />;

// ─── Null-safe mono value ─────────────────────────────────────────────────────
function MV({ v, u = "", size = 13, w = 600, color }: { v: string | number | null; u?: string; size?: number; w?: number; color?: string }) {
  const miss = v === null || v === undefined;
  return (
    <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: size, fontWeight: miss ? 400 : w, color: color ?? (miss ? FG3 : FG1) }}>
      {miss ? "—" : `${v}${u}`}
    </span>
  );
}

// ─── Candlestick chart (new, §3-A 红涨绿跌) ──────────────────────────────────
function KChart({ candles }: { candles: Candle[] }) {
  const W = 376, CH = 152, VH = 30;
  const pL = 5, pR = 50, pT = 8, pB = 22;
  const dW = W - pL - pR, dH = CH - pT - pB;

  const lows  = candles.map(d => d.low);
  const highs = candles.map(d => d.high);
  const minP  = Math.min(...lows);
  const maxP  = Math.max(...highs);
  const range = maxP - minP;
  const pad   = range * 0.14;
  const lo = minP - pad, hi = maxP + pad, pRng = hi - lo;

  const toY  = (p: number) => pT + dH - ((p - lo) / pRng) * dH;
  const spc  = dW / candles.length;
  const bw   = spc * 0.46;

  const gridPs  = [0.2, 0.42, 0.64, 0.84].map(r => lo + pRng * r);
  const maxVol  = Math.max(...candles.map(d => d.vol));
  const lastClose = candles[candles.length - 1].close;

  return (
    <div>
      <svg width={W} height={CH} style={{ display: "block" }}>
        {/* Grid lines */}
        {gridPs.map((p, i) => (
          <g key={i}>
            <line x1={pL} y1={toY(p)} x2={W-pR} y2={toY(p)} stroke="rgba(255,255,255,.055)" strokeWidth={1} strokeDasharray="3,6" />
            <text x={W-pR+5} y={toY(p)+3.5} fontSize={9} fill="rgba(255,255,255,.28)" fontFamily="'JetBrains Mono',monospace">{p.toFixed(0)}</text>
          </g>
        ))}
        {/* Current price dashed line (§3-A TEAL = 非AI高亮) */}
        {(() => {
          const y = toY(lastClose);
          return (
            <g>
              <line x1={pL} y1={y} x2={W-pR} y2={y} stroke={TEAL} strokeWidth={1} strokeDasharray="4,5" opacity={.70} />
              <rect x={W-pR+3} y={y-8} width={44} height={16} rx={4} fill={TEAL} fillOpacity={.14} />
              <text x={W-pR+25} y={y+3.5} fontSize={9} fill={TEAL} fontFamily="'JetBrains Mono',monospace" textAnchor="middle" fontWeight={700}>{lastClose.toFixed(0)}</text>
            </g>
          );
        })()}
        {/* Candles — A股红涨绿跌 (§3-A 铁律) */}
        {candles.map((d, i) => {
          const cx  = pL + spc*i + spc/2;
          const isUp = d.close >= d.open;
          const col  = isUp ? UP : DN;
          const top  = toY(Math.max(d.open, d.close));
          const bot  = toY(Math.min(d.open, d.close));
          const bh   = Math.max(1.8, bot - top);
          return (
            <g key={i}>
              <line x1={cx} y1={toY(d.high)} x2={cx} y2={toY(d.low)} stroke={col} strokeWidth={1.3} />
              <rect x={cx-bw/2} y={top} width={bw} height={bh} fill={col} stroke={col} strokeWidth={1} rx={1.5} />
              <text x={cx} y={CH-4} fontSize={9} fill="rgba(255,255,255,.26)" textAnchor="middle" fontFamily="'JetBrains Mono',monospace">{d.date}</text>
            </g>
          );
        })}
      </svg>
      {/* Volume strip */}
      <svg width={W} height={VH} style={{ display: "block", marginTop: 2 }}>
        <text x={W-pR+5} y={12} fontSize={9} fill="rgba(255,255,255,.20)" fontFamily="'JetBrains Mono',monospace">VOL</text>
        {candles.map((d, i) => {
          const cx = pL + spc*i + spc/2;
          const vh = Math.max(3, (d.vol/maxVol)*(VH-8));
          return <rect key={i} x={cx-bw/2} y={VH-4-vh} width={bw} height={vh} fill={d.close >= d.open ? UP : DN} fillOpacity={.45} rx={1} />;
        })}
      </svg>
      {/* Legend */}
      <div style={{ display: "flex", gap: 12, padding: "5px 4px 0", justifyContent: "flex-end" }}>
        {[{ c: UP, l: "涨" }, { c: DN, l: "跌" }].map(({ c, l }) => (
          <div key={l} style={{ display: "flex", alignItems: "center", gap: 5 }}>
            <div style={{ width: 10, height: 10, borderRadius: 2, background: c }} />
            <span style={{ fontSize: 10, color: FG3 }}>{l}</span>
          </div>
        ))}
        <span style={{ fontSize: 10, color: FG3 }}>· A股红涨绿跌</span>
      </div>
    </div>
  );
}

// ─── AQI section — 7-tier (§3-A spec) ────────────────────────────────────────
function AQISec({ aqi }: { aqi: AQIData }) {
  return (
    <div style={{ padding: "13px 16px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 11 }}>
        <span style={{ fontSize: 10.5, color: FG3, letterSpacing: ".09em", textTransform: "uppercase" as const, fontWeight: 600 }}>空气质量</span>
        {aqi ? (
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: aqi.hex, boxShadow: `0 0 7px ${aqi.hex}` }} />
            <MV v={aqi.value} size={13} />
            <span style={{ fontSize: 12.5, fontWeight: 600, color: aqi.hex }}>{aqi.grade}</span>
          </div>
        ) : <MV v={null} />}
      </div>
      {/* 7-tier bar */}
      <div style={{ display: "flex", gap: 3, marginBottom: 5 }}>
        {AQI_TIERS.map((t, i) => {
          const active = aqi?.grade === t.label || (!aqi && t.label === "未知");
          return <div key={i} style={{ flex: 1, height: 5, borderRadius: 3, background: t.hex, opacity: active ? 1 : 0.22, boxShadow: active ? `0 0 9px ${t.hex}` : "none", transition: "opacity .2s" }} />;
        })}
      </div>
      {/* Labels */}
      <div style={{ display: "flex", gap: 3 }}>
        {AQI_TIERS.map((t, i) => {
          const active = aqi?.grade === t.label || (!aqi && t.label === "未知");
          return (
            <div key={i} style={{ flex: 1, textAlign: "center" as const }}>
              <div style={{ fontSize: 9, fontWeight: active ? 700 : 400, color: active ? t.hex : FG3 }}>{t.label}</div>
              <div style={{ fontSize: 8, color: FG3, opacity: .6, fontFamily: "'JetBrains Mono',monospace" }}>{t.range}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Empty states ─────────────────────────────────────────────────────────────
function EmptyW() {
  return (
    <GlassCard style={{ width: 384, height: 300, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14 }}>
      <div style={{ width: 60, height: 60 }}><AuroraOrb state="idle" size={60} /></div>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 5, color: FG1 }}>暂无天气数据</div>
        <div style={{ fontSize: 12, color: FG3 }}>点击以添加城市</div>
      </div>
      <button style={{ marginTop: 4, padding: "8px 22px", borderRadius: 20, border: `1px solid rgba(70,214,224,.30)`, background: "rgba(70,214,224,.10)", color: TEAL, fontSize: 13, fontWeight: 500, cursor: "pointer", fontFamily: "'Inter','Noto Sans SC',sans-serif" }}>
        ＋ 添加城市
      </button>
    </GlassCard>
  );
}
function EmptyS() {
  return (
    <GlassCard style={{ width: 384, height: 300, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14 }}>
      <svg width={52} height={38} viewBox="0 0 52 38" fill="none" stroke="rgba(255,255,255,.18)" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round">
        <polyline points="4,30 14,20 22,24 32,12 48,16" />
        <line x1="4" y1="34" x2="48" y2="34" />
      </svg>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 15, fontWeight: 500, marginBottom: 5, color: FG1 }}>暂未关注股票</div>
        <div style={{ fontSize: 12, color: FG3 }}>添加股票以查看实时行情</div>
      </div>
      <button style={{ marginTop: 4, padding: "8px 22px", borderRadius: 20, border: `1px solid rgba(70,214,224,.30)`, background: "rgba(70,214,224,.10)", color: TEAL, fontSize: 13, fontWeight: 500, cursor: "pointer", fontFamily: "'Inter','Noto Sans SC',sans-serif" }}>
        ＋ 添加股票
      </button>
    </GlassCard>
  );
}

// ─── Weather Card (new) ───────────────────────────────────────────────────────
function WCard({ data }: { data: WData }) {
  const tele = [
    { icon: "🌡",  label: "体感",   v: data.feels,      u: "°C" },
    { icon: "💧",  label: "湿度",   v: data.humidity,   u: "%"  },
    { icon: "🌬",  label: "风向",   v: data.wind,       u: ""   },
    { icon: "👁",  label: "能见度", v: data.visibility, u: "km" },
    { icon: "🌧",  label: "降水",   v: data.precip,     u: "mm" },
    { icon: "📊",  label: "气压",   v: data.pressure,   u: "hPa"},
  ];

  return (
    <GlassCard r={24} style={{ width: 384 }}>
        {/* Alert callout */}
        {data.alert && (
          <div style={{ padding: "10px 16px", background: "rgba(245,158,11,.11)", borderBottom: "1px solid rgba(245,158,11,.20)", display: "flex", gap: 10, alignItems: "flex-start" }}>
            <svg width={15} height={15} viewBox="0 0 16 16" fill="none" stroke="#F59E0B" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: 1 }}>
              <path d="M8 2L14 13H2L8 2Z" /><line x1="8" y1="7" x2="8" y2="10" /><circle cx="8" cy="12" r=".6" fill="#F59E0B" stroke="none" />
            </svg>
            <div>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: "#F59E0B" }}>{data.alert.text}</div>
              <div style={{ fontSize: 11, color: FG2, marginTop: 2, lineHeight: 1.55 }}>{data.alert.desc}</div>
            </div>
          </div>
        )}

        {/* Header */}
        <div style={{ padding: "18px 18px 12px", display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 8 }}>
              <span style={{ fontSize: 16, fontWeight: 600 }}>{data.city}</span>
              <span style={{ fontSize: 11.5, color: FG3 }}>浙江</span>
            </div>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 4, lineHeight: 1 }}>
              {/* Big temp — JetBrains Mono (§7 铁律) */}
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 68, fontWeight: 700, letterSpacing: "-0.03em", color: FG1 }}>{data.temp}</span>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 24, fontWeight: 300, color: FG2, marginTop: 10 }}>°C</span>
            </div>
            <div style={{ fontSize: 13.5, color: FG2, marginTop: 5 }}>{data.condition}</div>
          </div>
          <div style={{ textAlign: "right", display: "flex", flexDirection: "column", gap: 6, paddingTop: 2 }}>
            <span style={{ fontSize: 44, lineHeight: 1 }}>⛅</span>
            <span style={{ fontSize: 10.5, color: FG3 }}>更新 {data.updated}</span>
            <span style={{ fontSize: 10.5, color: FG3 }}>时效至 {data.valid}</span>
          </div>
        </div>

        <HR />

        {/* Telemetry chips 3×2 */}
        <div style={{ padding: "12px 13px", display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 7 }}>
          {tele.map((item, i) => {
            const miss = item.v === null || item.v === undefined;
            return (
              <div key={i} style={{ padding: "9px 6px", borderRadius: 11, background: miss ? "rgba(255,255,255,.028)" : "rgba(255,255,255,.048)", border: `1px solid rgba(255,255,255,${miss?.048:.08})`, display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
                <span style={{ fontSize: 15 }}>{item.icon}</span>
                <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: typeof item.v === "string" ? 9.5 : 12, fontWeight: miss ? 400 : 600, color: miss ? FG3 : FG1, textAlign: "center", lineHeight: 1.2 }}>
                  {miss ? "—" : `${item.v}${item.u}`}
                </span>
                <span style={{ fontSize: 9.5, color: FG3 }}>{item.label}</span>
              </div>
            );
          })}
        </div>

        <HR />

        {/* 3-day forecast */}
        <div style={{ padding: "13px 12px", display: "flex" }}>
          {data.forecast.map((f, i) => (
            <div key={i} style={{ flex: 1, textAlign: "center", padding: "0 6px", borderRight: i < 2 ? `1px solid ${DIV}` : "none" }}>
              <div style={{ fontSize: 11, color: FG3, marginBottom: 6 }}>{f.day}</div>
              <div style={{ fontSize: 28, marginBottom: 4, lineHeight: 1 }}>{f.icon}</div>
              <div style={{ fontSize: 11, color: FG2, marginBottom: 8 }}>{f.cond}</div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 4 }}>
                <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: "#93C5FD" }}>{f.low}°</span>
                <div style={{ flex: 1, height: 2.5, borderRadius: 2, background: "linear-gradient(to right,rgba(91,140,255,.5),rgba(255,165,50,.5))" }} />
                <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: "#FCA5A5" }}>{f.high}°</span>
              </div>
            </div>
          ))}
        </div>

        <HR />
        <AQISec aqi={data.aqi} />

        {/* Life tips or degraded note */}
        {data.tips ? (
          <>
            <HR />
            <div style={{ padding: "13px 14px" }}>
              <div style={{ fontSize: 10.5, color: FG3, letterSpacing: ".09em", textTransform: "uppercase" as const, fontWeight: 600, marginBottom: 10 }}>生活建议</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                {data.tips.map((t, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 9, padding: "8px 10px", borderRadius: 11, background: "rgba(255,255,255,.04)", border: "1px solid rgba(255,255,255,.07)" }}>
                    <span style={{ fontSize: 18 }}>{t.icon}</span>
                    <div>
                      <div style={{ fontSize: 10.5, color: FG3 }}>{t.label}</div>
                      <div style={{ fontSize: 12.5, fontWeight: 600, color: TIP_COLOR[t.level] }}>{t.value}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        ) : (
          <>
            <HR />
            <div style={{ padding: "12px 16px", display: "flex", gap: 8, alignItems: "center" }}>
              <span style={{ fontSize: 13, color: FG3 }}>⚠</span>
              <span style={{ fontSize: 12, color: FG3 }}>生活建议数据暂不可用</span>
            </div>
          </>
        )}
    </GlassCard>
  );
}

// ─── Stock Card (new) ─────────────────────────────────────────────────────────
function SCard({ data }: { data: SData }) {
  const isUp = data.change >= 0;
  const cc   = isUp ? UP : DN;   // A股红涨绿跌

  return (
    <GlassCard r={24} style={{ width: 384 }}>
        {/* Header */}
        <div style={{ padding: "16px 18px 12px", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 5 }}>{data.name}</div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, color: FG3 }}>{data.ticker}</span>
              <span style={{ fontSize: 11, color: FG3 }}>·</span>
              <span style={{ fontSize: 11, color: FG3 }}>{data.exchange === "SH" ? "上证" : "深证"}</span>
            </div>
          </div>
          <div style={{ textAlign: "right", display: "flex", flexDirection: "column", gap: 5 }}>
            <div style={{ padding: "3px 9px", borderRadius: 20, background: "rgba(107,114,128,.10)", border: "1px solid rgba(107,114,128,.20)", display: "inline-flex" }}>
              <span style={{ fontSize: 11, color: FG3 }}>{data.marketStatus} · {data.closedAt}</span>
            </div>
            <span style={{ fontSize: 10.5, color: FG3 }}>A股主板 · 沪市</span>
          </div>
        </div>

        <HR />

        {/* Price zone */}
        <div style={{ padding: "14px 18px 12px", display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
          <div>
            {/* Big price — JetBrains Mono (§7) */}
            <div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 8 }}>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 40, fontWeight: 700, letterSpacing: "-0.025em", lineHeight: 1, color: cc }}>{data.price.toFixed(2)}</span>
              <span style={{ fontSize: 13, color: FG3, fontFamily: "'JetBrains Mono',monospace" }}>CNY</span>
            </div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <span style={{ padding: "3px 10px", borderRadius: 7, background: `${cc}18`, border: `1px solid ${cc}35`, fontFamily: "'JetBrains Mono',monospace", fontSize: 13, fontWeight: 700, color: cc }}>
                {isUp ? "+" : ""}{data.change.toFixed(2)}
              </span>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 13, fontWeight: 600, color: cc }}>
                {isUp ? "+" : ""}{data.changePct.toFixed(2)}%
              </span>
            </div>
          </div>
          {/* OHLC */}
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {[
              { l: "今开", v: data.open },
              { l: "最高", v: data.high },
              { l: "最低", v: data.low  },
              { l: "昨收", v: data.prevClose },
            ].map(s => (
              <div key={s.l} style={{ display: "flex", gap: 10, justifyContent: "space-between" }}>
                <span style={{ fontSize: 10.5, color: FG3 }}>{s.l}</span>
                <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11.5, color: FG1 }}>{s.v.toFixed(2)}</span>
              </div>
            ))}
          </div>
        </div>

        <HR />

        {/* Chart or degraded placeholder */}
        {data.candles ? (
          <div style={{ padding: "12px 4px 8px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 14px", marginBottom: 8 }}>
              <span style={{ fontSize: 10.5, color: FG3, letterSpacing: ".09em", textTransform: "uppercase" as const, fontWeight: 600 }}>日K线 · 5日</span>
              <div style={{ display: "flex", gap: 10 }}>
                {["1日","5日","1月","3月"].map((t, i) => (
                  <span key={t} style={{ fontSize: 10.5, color: i === 1 ? TEAL : FG3, fontWeight: i === 1 ? 600 : 400, cursor: "pointer" }}>{t}</span>
                ))}
              </div>
            </div>
            <KChart candles={data.candles} />
          </div>
        ) : (
          <div style={{ padding: "22px 18px", display: "flex", flexDirection: "column", alignItems: "center", gap: 8, background: "rgba(255,255,255,.022)" }}>
            <svg width={44} height={32} viewBox="0 0 44 32" fill="none" stroke="rgba(255,255,255,.16)" strokeWidth={1.5} strokeLinecap="round">
              <polyline points="3,24 11,16 18,19 27,9 41,12" /><line x1="3" y1="28" x2="41" y2="28" />
            </svg>
            <span style={{ fontSize: 12, color: FG3 }}>K线数据暂不可用</span>
          </div>
        )}

        <HR />

        {/* Stats grid */}
        <div style={{ padding: "13px 16px", display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: "8px 6px" }}>
          {[
            { l: "市值",   v: data.marketCap },
            { l: "市盈率", v: data.pe ? data.pe.toFixed(1) : null },
            { l: "市净率", v: data.pb ? data.pb.toFixed(1) : null },
            { l: "成交量", v: data.vol },
          ].map((s, i) => (
            <div key={i} style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12.5, fontWeight: 600, color: s.v ? FG1 : FG3, marginBottom: 4 }}>{s.v ?? "—"}</div>
              <div style={{ fontSize: 10.5, color: FG3 }}>{s.l}</div>
            </div>
          ))}
        </div>
    </GlassCard>
  );
}

// ─── Page-level helpers ───────────────────────────────────────────────────────
function SecLabel({ num, title, sub }: { num: string; title: string; sub: string }) {
  return (
    <div style={{ marginBottom: 28 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 5 }}>
        <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10.5, color: FG3, letterSpacing: ".12em" }}>{num}</span>
        <div style={{ width: 1, height: 14, background: "rgba(255,255,255,.10)" }} />
        <div style={{ width: 3, height: 18, background: AURORA, borderRadius: 2 }} />
        <h2 style={{ fontSize: 16.5, fontWeight: 500, margin: 0, letterSpacing: ".03em" }}>{title}</h2>
      </div>
      <p style={{ fontSize: 12.5, color: FG3, margin: 0, paddingLeft: 52, lineHeight: 1.6 }}>{sub}</p>
    </div>
  );
}

function VLabel({ main, sub }: { main: string; sub: string }) {
  return (
    <div style={{ marginBottom: 11 }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: FG2 }}>{main}</div>
      <div style={{ fontSize: 10.5, color: FG3, marginTop: 2 }}>{sub}</div>
    </div>
  );
}

// ─── App — A-3 Showcase ───────────────────────────────────────────────────────
export default function App() {
  return (
    <div style={{
      minHeight: "100vh",
      fontFamily: "'Inter','Noto Sans SC',-apple-system,sans-serif",
      color: FG1,
      background: "linear-gradient(155deg,#06080F 0%,#0A0E1A 52%,#080D18 100%)",
    }}>
      <style>{KEYFRAMES}</style>

      {/* Atmosphere blobs (Layer 0, §2) */}
      <div aria-hidden style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
        <div style={{ position: "absolute", bottom: "8%",  left: "12%",  width: 620, height: 430, background: "radial-gradient(circle,rgba(91,140,255,.10) 0%,transparent 68%)", filter: "blur(52px)" }} />
        <div style={{ position: "absolute", top: "10%",   right: "10%", width: 500, height: 370, background: "radial-gradient(circle,rgba(91,233,255,.07) 0%,transparent 68%)", filter: "blur(58px)" }} />
        <div style={{ position: "absolute", top: "44%",   left: "36%",  width: 660, height: 490, background: "radial-gradient(circle,rgba(154,107,255,.06) 0%,transparent 68%)", filter: "blur(64px)" }} />
      </div>

      {/* Sticky header */}
      <header style={{
        position: "sticky", top: 0, zIndex: 30,
        height: 56, padding: "0 48px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        background: "rgba(6,8,15,.80)",
        backdropFilter: "blur(28px)", WebkitBackdropFilter: "blur(28px)",
        borderBottom: `1px solid ${DIV}`,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 26, height: 26 }}><AuroraOrb state="idle" size={26} /></div>
          <span style={{ ...AURORA_TEXT, fontSize: 14, fontWeight: 600 }}>Aurora Glass</span>
          <span style={{ fontSize: 13, color: FG3, fontWeight: 300 }}>· A-3 卡片族 · 气象 + 金融</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ width: 12, height: 12, borderRadius: 3, background: AURORA }} />
          <span style={{ fontSize: 11, color: FG3 }}>虹彩描边 = AI 生成内容（§5）· 卡片只给证据</span>
        </div>
      </header>

      {/* Content */}
      <div style={{ position: "relative", zIndex: 1, maxWidth: 1440, margin: "0 auto", padding: "52px 48px 100px" }}>

        {/* ── Weather Cards ── */}
        <section style={{ marginBottom: 72 }}>
          <SecLabel num="A-3.1" title="WEATHER CARD · 气象卡" sub="telemetry 芯片 · 3日预报 · AQI 7档色阶 · 预警 callout · 生活建议 · 正常/降级/空 三态" />
          <div style={{ display: "flex", gap: 20, alignItems: "flex-start", flexWrap: "wrap" }}>
            <div>
              <VLabel main="正常态" sub="全字段 + 预警 callout + 生活建议" />
              <WCard data={FULL_W} />
            </div>
            <div>
              <VLabel main="字段缺失降级" sub="AQI·湿度·风·降水·预警 缺失" />
              <WCard data={DEG_W} />
            </div>
            <div>
              <VLabel main="空态" sub="未添加城市" />
              <EmptyW />
            </div>
          </div>
        </section>

        {/* ── Stock Cards ── */}
        <section>
          <SecLabel num="A-3.2" title="STOCK CARD · 股票卡" sub="日K线蜡烛图数据驱动 SVG · A股红涨绿跌(§3-A 铁律) · 网格+当前价线+成交量条 · 正常/降级/空 三态" />
          <div style={{ display: "flex", gap: 20, alignItems: "flex-start", flexWrap: "wrap" }}>
            <div>
              <VLabel main="正常态" sub="完整行情 + 日K线 + 指标" />
              <SCard data={FULL_S} />
            </div>
            <div>
              <VLabel main="字段缺失降级" sub="K线·市值·估值暂不可用" />
              <SCard data={DEG_S} />
            </div>
            <div>
              <VLabel main="空态" sub="未关注任何股票" />
              <EmptyS />
            </div>
          </div>
        </section>

      </div>
    </div>
  );
}
