
  # 【新】座舱Agent-HMI

  This is a code bundle for 【新】座舱Agent-HMI. The original project is available at https://www.figma.com/design/IYsuxZHzG7t2PXtvHOT41N/%E3%80%90%E6%96%B0%E3%80%91%E5%BA%A7%E8%88%B1Agent-HMI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  