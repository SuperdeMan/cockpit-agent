// Design contract: guidelines/Guidelines.md
// Page: A-4 卡片族 2 · 搜索 / 新闻 / 深度调研
// Reused: AuroraOrb, GlassCard, AURORA, AURORA_TEXT, TEAL, FG1/2/3, DIV, KEYFRAMES, CONF,
//         MV, KChart, AQISec, WCard, SCard, EmptyW, EmptyS (A-3 preserved, not deleted)
// New:    AIBadge, ConfBadge, CatChip, Refs, RSection, SearchCard, NewsCard, ResearchCard

import { useState, useMemo, CSSProperties, ReactNode } from "react";
import { ChevronDown, ExternalLink, Maximize2, RefreshCw, AlertTriangle, Search, Newspaper, BookOpen } from "lucide-react";

// ─── Design Tokens (§3 Guidelines.md) ────────────────────────────────────────
const AURORA       = "linear-gradient(135deg,#5BE9FF 0%,#5B8CFF 33%,#9A6BFF 66%,#FF6BD6 100%)";
const AURORA_CONIC = "conic-gradient(from 0deg,#5BE9FF,#5B8CFF,#9A6BFF,#FF6BD6,#5BE9FF)";
const AURORA_TEXT: CSSProperties = {
  background: AURORA, WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent", backgroundClip: "text",
};
const TEAL = "#46D6E0";
const UP   = "#EF4444";
const DN   = "#22C55E";
const FG1  = "rgba(255,255,255,0.92)";
const FG2  = "rgba(255,255,255,0.56)";
const FG3  = "rgba(255,255,255,0.32)";
const DIV  = "rgba(255,255,255,0.07)";

const CONF: Record<string, { c: string; bg: string; bc: string }> = {
  高: { c: TEAL,      bg: "rgba(70,214,224,.11)",  bc: "rgba(70,214,224,.26)"  },
  中: { c: "#F59E0B", bg: "rgba(245,158,11,.11)",  bc: "rgba(245,158,11,.26)"  },
  低: { c: "#6B7280", bg: "rgba(107,114,128,.11)", bc: "rgba(107,114,128,.24)" },
};

const AQI_TIERS = [
  { label: "优",   range: "0–50",    hex: "#34D399" },
  { label: "良",   range: "51–100",  hex: "#A3E635" },
  { label: "轻度", range: "101–150", hex: "#FCD34D" },
  { label: "中度", range: "151–200", hex: "#FB923C" },
  { label: "重度", range: "201–300", hex: "#EF4444" },
  { label: "严重", range: "301+",    hex: "#9333EA" },
  { label: "未知", range: "—",       hex: "#6B7280" },
];

const TIP_COLOR: Record<string, string> = {
  good: "#34D399", mid: "#F59E0B", warn: "#FB923C", bad: "#EF4444",
};

// Category chip colours (A-4 news/search)
const CAT_C: Record<string, string> = {
  科技: TEAL, 汽车: "#3B82F6", 财经: "#22C55E", 宏观: "#F59E0B",
  能源: "#10B981", 学术: "#8B5CF6", 金融: "#A78BFA", 国际: "#FB923C",
};

// ─── Keyframes ────────────────────────────────────────────────────────────────
const KEYFRAMES = `
  @keyframes aurora-breathe {
    0%,100%{opacity:.82;transform:scale(1)} 50%{opacity:1;transform:scale(1.038)}
  }
  @keyframes aurora-breathe-fast {
    0%,100%{opacity:.85;transform:scale(1)} 50%{opacity:1;transform:scale(1.045)}
  }
  @keyframes aurora-spin {
    from{transform:rotate(0deg)} to{transform:rotate(360deg)}
  }
  @keyframes aurora-spin-r {
    from{transform:rotate(360deg)} to{transform:rotate(0deg)}
  }
  @keyframes aurora-pulse {
    0%,100%{transform:scale(1);opacity:.86}
    25%{transform:scale(1.07);opacity:1}
    75%{transform:scale(0.96);opacity:.80}
  }
  *{scrollbar-width:thin;scrollbar-color:rgba(91,140,255,.22) transparent}
  @media(prefers-reduced-motion:reduce){*{animation-duration:.01ms!important}}
`;

// ─── Data: A-3 (preserved) ────────────────────────────────────────────────────
type AQIData = { value: number; grade: string; hex: string } | null;
type Tip     = { label: string; value: string; icon: string; level: string };
type Candle  = { date: string; open: number; close: number; high: number; low: number; vol: number };

interface WData {
  city: string; temp: number; feels: number | null; condition: string;
  humidity: number | null; wind: string | null;
  visibility: number | null; pressure: number | null; precip: number | null;
  aqi: AQIData;
  forecast: { day: string; icon: string; cond: string; low: number; high: number }[];
  tips: Tip[] | null;
  alert: { text: string; desc: string } | null;
  updated: string; valid: string;
}
interface SData {
  name: string; ticker: string; exchange: string;
  price: number; change: number; changePct: number;
  open: number; high: number; low: number; prevClose: number;
  marketCap: string | null; pe: number | null; pb: number | null; vol: string | null;
  candles: Candle[] | null;
  marketStatus: string; closedAt: string;
}

const FULL_W: WData = {
  city: "杭州", temp: 28, feels: 30, condition: "多云",
  humidity: 65, wind: "东南风3级", visibility: 24, pressure: 1008, precip: 0.2,
  aqi: { value: 68, grade: "良", hex: "#A3E635" },
  forecast: [
    { day: "今天", icon: "⛅", cond: "多云", low: 24, high: 30 },
    { day: "明天", icon: "🌧️", cond: "阵雨", low: 23, high: 27 },
    { day: "后天", icon: "☀️", cond: "晴",   low: 25, high: 32 },
  ],
  tips: [
    { label: "洗车",   value: "适宜",   icon: "🚗",  level: "good" },
    { label: "紫外线", value: "中等",   icon: "🌤️", level: "mid"  },
    { label: "穿衣",   value: "短袖",   icon: "👕",  level: "good" },
    { label: "感冒",   value: "较易发", icon: "🤧",  level: "warn" },
  ],
  alert: { text: "⚡ 雷电黄色预警", desc: "未来6小时内可能有雷雨大风，请注意防范" },
  updated: "17:30", valid: "20:00",
};
const DEG_W: WData = { ...FULL_W, feels: null, humidity: null, wind: null, precip: null, aqi: null, alert: null, tips: null };

const CANDLES: Candle[] = [
  { date: "6/23", open: 1645.00, close: 1658.50, high: 1672.00, low: 1638.00, vol: 12500 },
  { date: "6/24", open: 1658.50, close: 1651.00, high: 1669.00, low: 1644.00, vol: 9800  },
  { date: "6/25", open: 1651.00, close: 1675.50, high: 1682.00, low: 1648.00, vol: 15200 },
  { date: "6/26", open: 1675.50, close: 1669.00, high: 1688.50, low: 1662.00, vol: 11400 },
  { date: "6/27", open: 1669.00, close: 1689.00, high: 1695.00, low: 1665.00, vol: 18900 },
];
const FULL_S: SData = {
  name: "贵州茅台", ticker: "600519", exchange: "SH",
  price: 1689.00, change: 12.50, changePct: 0.75,
  open: 1669.00, high: 1695.00, low: 1662.00, prevClose: 1676.50,
  marketCap: "21,234亿", pe: 32.4, pb: 12.8, vol: "1.89万手",
  candles: CANDLES, marketStatus: "已收盘", closedAt: "15:00",
};
const DEG_S: SData = { ...FULL_S, candles: null, marketCap: null, pe: null, pb: null, vol: null };

// ─── Data: A-4 ────────────────────────────────────────────────────────────────
const SEARCH_RESULTS = [
  { n: 1, site: "盖世汽车",      domain: "gasgoo.com",        time: "2小时前", cat: "汽车",
    excerpt: "宁德时代透露全固态电池计划于2027年实现小批量生产，初期年产能约2GWh，2030年前后进入规模化阶段。" },
  { n: 2, site: "第一财经",      domain: "yicai.com",         time: "5小时前", cat: "财经",
    excerpt: "多家整车厂发布固态电池路线图，量产窗口集中在2026—2030年间，成本与良率为核心挑战。" },
  { n: 3, site: "IEEE Spectrum", domain: "spectrum.ieee.org", time: "1天前",   cat: "学术",
    excerpt: "Interface stability and manufacturing yield remain primary barriers to 2027 mass-production targets." },
  { n: 4, site: "财联社",        domain: "cls.cn",            time: "3小时前", cat: "财经",
    excerpt: "丰田称将于2026年推出搭载全固态电池量产混合动力车，固态电解质良率已突破85%关键节点。" },
];

const NEWS_ITEMS = [
  { cat: "科技", title: "华为发布鸿蒙 Next 正式版，原生应用生态突破120万个",     summary: "彻底切割安卓底层，原生AI加持下流畅度与续航同步提升，鸿蒙生态进入独立加速期。",    source: "36氪",      time: "2小时前"  },
  { cat: "汽车", title: "蔚来Q3交付61,855辆同比增37%，现金流首次转正",           summary: "ET9超豪华车型贡献显著，公司表示2025年Q2前实现盈亏平衡，市场反应积极。",           source: "第一财经",  time: "3小时前"  },
  { cat: "宏观", title: "国家统计局：11月CPI同比-0.5%，PPI降幅收窄至-2.1%",     summary: "食品价格拖累CPI，但核心通胀保持稳定，机构预期后续货币政策仍有宽松空间。",         source: "财联社",    time: "4小时前"  },
  { cat: "能源", title: "欧盟CBAM碳边境调节机制正式生效，钢铁铝业首当其冲",       summary: "进口商须向欧盟申报隐含碳量，中国钢铁出口商成本压力将显著提升。",                   source: "澎湃新闻",  time: "6小时前"  },
  { cat: "科技", title: "OpenAI o3 发布，ARC-AGI达87.5%超越顶尖人类表现",       summary: "o3在GPQA Diamond达87.7%，数学编程基准全面创新高，o3-mini将面向开发者开放。",   source: "品玩",      time: "8小时前"  },
  { cat: "金融", title: "美联储12月议息暗示放缓降息，点阵图预期降至2次",          summary: "债市出现明显调整，美元指数走强，市场对2025年宽松预期大幅收缩。",                   source: "华尔街见闻",time: "10小时前" },
  { cat: "国际", title: "G20峰会就全球AI治理框架达成原则性共识",                 summary: "各国同意在数据跨境与模型安全标准上展开多边合作，细则谈判将持续至明年。",           source: "环球时报",  time: "12小时前" },
];

const RSECTIONS: { n: number; title: string; conf: string; body: string }[] = [
  { n: 1, title: "技术现状", conf: "高",
    body: "固态电解质技术路线已收敛为三大方向：氧化物（LLZO）、硫化物与聚合物。氧化物离子导率较低但化学稳定性优；硫化物导率最高但对水蒸气敏感，需严格干燥生产环境 [1]。全固态电池能量密度理论上限可达500 Wh/kg，远超液态锂电300 Wh/kg的天花板 [2]。主流电池厂与整车厂均已公开技术路径选择，产业共识基本形成。" },
  { n: 2, title: "量产产能", conf: "中",
    body: "宁德时代、比亚迪、丰田、三星SDI等均已公布2027—2030年量产路线图。当前全球固态电池产线总产能不足1 GWh/年，规模化至百GWh需解决极片涂布精度、叠片效率与界面工程等瓶颈 [3]。丰田计划2027年搭载量产车型，但外部分析机构对其公开良率目标持保留态度 [4]。" },
  { n: 3, title: "成本曲线", conf: "中",
    body: "当前固态电池制造成本约为液态锂电的5—8倍。行业预测2030年前后成本可降至$80—120/kWh，接近液态电池竞争区间。硫化物路线原料硫化锂（Li₂S）供应链尚未规模化，是成本路径关键变量 [5]。" },
  { n: 4, title: "风险与变数", conf: "低",
    body: "核心不确定因素：①固态电解质界面（SEI）在极端温度下长期稳定性缺乏十万公里实证数据；②薄膜极片（<10μm）大面积无缺陷涂布良率——当前最优公开数据约60—70%，距量产要求存在差距；③关键矿物供应链受地缘政治影响难以量化预测。" },
];

const GAPS = [
  "固态电解质量产良率数据缺乏公开来源（头部厂商均未披露）",
  "宁德时代产线具体投资规模及建设进度无官方公告",
  "超10万公里全固态电池循环寿命实测数据暂无公开报告",
];

const REFS = [
  { id: 1, site: "盖世汽车",    domain: "gasgoo.com",      time: "2024-12", title: "宁德时代全固态电池战略解析" },
  { id: 2, site: "Nature Energy", domain: "nature.com",    time: "2024-09", title: "Solid-state batteries: energy density limits" },
  { id: 3, site: "第一财经",    domain: "yicai.com",       time: "2024-11", title: "全球固态电池产能调查报告" },
  { id: 4, site: "Reuters",     domain: "reuters.com",     time: "2024-12", title: "Toyota solid-state EV timeline update" },
  { id: 5, site: "BloombergNEF", domain: "bnef.com",       time: "2024-10", title: "Solid-State Battery Cost Outlook 2030" },
];

// ─── AuroraOrb (reused §9) ────────────────────────────────────────────────────
type OrbState = "idle" | "thinking" | "speaking";
function AuroraOrb({ state = "idle", size = 40 }: { state?: OrbState; size?: number }) {
  const thinking  = state === "thinking";
  const speaking  = state === "speaking";
  const glowMult  = speaking ? 1.35 : 1;
  const outerAnim = thinking ? "aurora-breathe-fast 1.4s ease-in-out infinite"
                  : speaking  ? "aurora-pulse 0.72s ease-in-out infinite"
                  :             "aurora-breathe 4s ease-in-out infinite";
  const haloSpeed  = thinking ? "1.6s" : "8s";
  const innerSpeed = thinking ? "1.1s" : "5s";
  const ctSpeed    = thinking ? "0.8s" : "3.8s";
  const s = size;
  return (
    <div style={{ position: "relative", width: s, height: s, flexShrink: 0 }}>
      <div style={{ position: "absolute", inset: -s*.52, borderRadius: "50%", background: `radial-gradient(circle,rgba(91,140,255,${.20*glowMult}) 0%,rgba(154,107,255,${.11*glowMult}) 40%,transparent 70%)`, animation: outerAnim, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: -s*.06, borderRadius: "50%", background: AURORA_CONIC, opacity: thinking?.52:.26, filter: `blur(${s*.115}px)`, animation: `aurora-spin ${haloSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: 0, borderRadius: "50%", background: `radial-gradient(circle at 36% 28%,rgba(255,255,255,.44) 0%,rgba(91,233,255,.22) 28%,rgba(91,140,255,.18) 56%,rgba(154,107,255,.26) 78%,rgba(255,107,214,.14) 100%)`, backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)", border: "1px solid rgba(255,255,255,.24)", boxShadow: `0 0 ${s*.32*glowMult}px rgba(91,142,255,.52),0 0 ${s*.70*glowMult}px rgba(154,107,255,.22),inset 0 0 ${s*.24}px rgba(91,233,255,.20),inset 0 ${s*.012}px 0 rgba(255,255,255,.34)`, animation: outerAnim, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: s*.16, borderRadius: "50%", background: AURORA_CONIC, opacity: .70, filter: `blur(${s*.036}px)`, animation: `aurora-spin ${innerSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: s*.28, borderRadius: "50%", background: `conic-gradient(from 180deg,#9A6BFF,#5B8CFF,#5BE9FF,#FF6BD6,#9A6BFF)`, opacity: .54, filter: `blur(${s*.028}px)`, animation: `aurora-spin-r ${ctSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", top: "9%", left: "13%", width: "44%", height: "33%", borderRadius: "50%", background: "radial-gradient(ellipse,rgba(255,255,255,.70) 0%,transparent 100%)", filter: "blur(2px)", pointerEvents: "none" }} />
    </div>
  );
}

// ─── GlassCard (reused §6) ────────────────────────────────────────────────────
function GlassCard({ children, p = 0, r = 24, style }: { children?: ReactNode; p?: number; r?: number; style?: CSSProperties }) {
  return (
    <div style={{
      padding: p, borderRadius: r, overflow: "hidden",
      background: "rgba(255,255,255,.056)",
      backdropFilter: "blur(32px)", WebkitBackdropFilter: "blur(32px)",
      border: "1px solid rgba(255,255,255,.10)",
      borderTop: "1px solid rgba(255,255,255,.17)",
      borderLeft: "1px solid rgba(255,255,255,.13)",
      boxShadow: "0 8px 40px rgba(0,0,0,.50),0 2px 12px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.13)",
      ...style,
    }}>{children}</div>
  );
}

const HR = () => <div style={{ height: 1, background: DIV }} />;

// Null-safe mono value (reused §7)
function MV({ v, u = "", size = 13, w = 600, color }: { v: string | number | null; u?: string; size?: number; w?: number; color?: string }) {
  const miss = v === null || v === undefined;
  return (
    <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: size, fontWeight: miss ? 400 : w, color: color ?? (miss ? FG3 : FG1) }}>
      {miss ? "—" : `${v}${u}`}
    </span>
  );
}

// ─── KChart (reused from A-3) ─────────────────────────────────────────────────
function KChart({ candles }: { candles: Candle[] }) {
  const W = 376, CH = 152, VH = 30;
  const pL = 5, pR = 50, pT = 8, pB = 22;
  const dW = W-pL-pR, dH = CH-pT-pB;
  const lows = candles.map(d => d.low), highs = candles.map(d => d.high);
  const minP = Math.min(...lows), maxP = Math.max(...highs);
  const range = maxP-minP, pad = range*.14;
  const lo = minP-pad, hi = maxP+pad, pRng = hi-lo;
  const toY = (p: number) => pT+dH-((p-lo)/pRng)*dH;
  const spc = dW/candles.length, bw = spc*.46;
  const gridPs = [.2,.42,.64,.84].map(r => lo+pRng*r);
  const maxVol = Math.max(...candles.map(d => d.vol));
  const lastClose = candles[candles.length-1].close;
  return (
    <div>
      <svg width={W} height={CH} style={{ display: "block" }}>
        {gridPs.map((p,i) => (
          <g key={i}>
            <line x1={pL} y1={toY(p)} x2={W-pR} y2={toY(p)} stroke="rgba(255,255,255,.055)" strokeWidth={1} strokeDasharray="3,6" />
            <text x={W-pR+5} y={toY(p)+3.5} fontSize={9} fill="rgba(255,255,255,.28)" fontFamily="'JetBrains Mono',monospace">{p.toFixed(0)}</text>
          </g>
        ))}
        {(() => { const y=toY(lastClose); return (<g><line x1={pL} y1={y} x2={W-pR} y2={y} stroke={TEAL} strokeWidth={1} strokeDasharray="4,5" opacity={.70} /><rect x={W-pR+3} y={y-8} width={44} height={16} rx={4} fill={TEAL} fillOpacity={.14} /><text x={W-pR+25} y={y+3.5} fontSize={9} fill={TEAL} fontFamily="'JetBrains Mono',monospace" textAnchor="middle" fontWeight={700}>{lastClose.toFixed(0)}</text></g>); })()}
        {candles.map((d,i) => {
          const cx=pL+spc*i+spc/2, isUp=d.close>=d.open, col=isUp?UP:DN;
          const top=toY(Math.max(d.open,d.close)), bot=toY(Math.min(d.open,d.close)), bh=Math.max(1.8,bot-top);
          return (<g key={i}><line x1={cx} y1={toY(d.high)} x2={cx} y2={toY(d.low)} stroke={col} strokeWidth={1.3} /><rect x={cx-bw/2} y={top} width={bw} height={bh} fill={col} stroke={col} strokeWidth={1} rx={1.5} /><text x={cx} y={CH-4} fontSize={9} fill="rgba(255,255,255,.26)" textAnchor="middle" fontFamily="'JetBrains Mono',monospace">{d.date}</text></g>);
        })}
      </svg>
      <svg width={W} height={VH} style={{ display: "block", marginTop: 2 }}>
        <text x={W-pR+5} y={12} fontSize={9} fill="rgba(255,255,255,.20)" fontFamily="'JetBrains Mono',monospace">VOL</text>
        {candles.map((d,i) => { const cx=pL+spc*i+spc/2, vh=Math.max(3,(d.vol/maxVol)*(VH-8)); return <rect key={i} x={cx-bw/2} y={VH-4-vh} width={bw} height={vh} fill={d.close>=d.open?UP:DN} fillOpacity={.45} rx={1} />; })}
      </svg>
    </div>
  );
}

// ─── AQISec (reused from A-3) ────────────────────────────────────────────────
function AQISec({ aqi }: { aqi: AQIData }) {
  return (
    <div style={{ padding: "13px 16px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 11 }}>
        <span style={{ fontSize: 10.5, color: FG3, letterSpacing: ".09em", textTransform: "uppercase" as const, fontWeight: 600 }}>空气质量</span>
        {aqi ? (
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: aqi.hex, boxShadow: `0 0 7px ${aqi.hex}` }} />
            <MV v={aqi.value} size={13} /><span style={{ fontSize: 12.5, fontWeight: 600, color: aqi.hex }}>{aqi.grade}</span>
          </div>
        ) : <MV v={null} />}
      </div>
      <div style={{ display: "flex", gap: 3, marginBottom: 5 }}>
        {AQI_TIERS.map((t,i) => { const active=aqi?.grade===t.label||(!aqi&&t.label==="未知"); return <div key={i} style={{ flex: 1, height: 5, borderRadius: 3, background: t.hex, opacity: active?1:.22, boxShadow: active?`0 0 9px ${t.hex}`:"none", transition: "opacity .2s" }} />; })}
      </div>
      <div style={{ display: "flex", gap: 3 }}>
        {AQI_TIERS.map((t,i) => { const active=aqi?.grade===t.label||(!aqi&&t.label==="未知"); return <div key={i} style={{ flex: 1, textAlign: "center" as const }}><div style={{ fontSize: 9, fontWeight: active?700:400, color: active?t.hex:FG3 }}>{t.label}</div><div style={{ fontSize: 8, color: FG3, opacity: .6, fontFamily: "'JetBrains Mono',monospace" }}>{t.range}</div></div>; })}
      </div>
    </div>
  );
}

// ─── Empty states (reused from A-3) ──────────────────────────────────────────
function EmptyW() {
  return (
    <GlassCard style={{ width: 384, height: 300, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14 }}>
      <div style={{ width: 60, height: 60 }}><AuroraOrb state="idle" size={60} /></div>
      <div style={{ textAlign: "center" }}><div style={{ fontSize: 15, fontWeight: 500, marginBottom: 5, color: FG1 }}>暂无天气数据</div><div style={{ fontSize: 12, color: FG3 }}>点击以添加城市</div></div>
      <button style={{ marginTop: 4, padding: "8px 22px", borderRadius: 20, border: `1px solid rgba(70,214,224,.30)`, background: "rgba(70,214,224,.10)", color: TEAL, fontSize: 13, fontWeight: 500, cursor: "pointer", fontFamily: "'Inter','Noto Sans SC',sans-serif" }}>＋ 添加城市</button>
    </GlassCard>
  );
}
function EmptyS() {
  return (
    <GlassCard style={{ width: 384, height: 300, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14 }}>
      <svg width={52} height={38} viewBox="0 0 52 38" fill="none" stroke="rgba(255,255,255,.18)" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round"><polyline points="4,30 14,20 22,24 32,12 48,16" /><line x1="4" y1="34" x2="48" y2="34" /></svg>
      <div style={{ textAlign: "center" }}><div style={{ fontSize: 15, fontWeight: 500, marginBottom: 5, color: FG1 }}>暂未关注股票</div><div style={{ fontSize: 12, color: FG3 }}>添加股票以查看实时行情</div></div>
      <button style={{ marginTop: 4, padding: "8px 22px", borderRadius: 20, border: `1px solid rgba(70,214,224,.30)`, background: "rgba(70,214,224,.10)", color: TEAL, fontSize: 13, fontWeight: 500, cursor: "pointer", fontFamily: "'Inter','Noto Sans SC',sans-serif" }}>＋ 添加股票</button>
    </GlassCard>
  );
}

// ─── WCard (reused from A-3) ─────────────────────────────────────────────────
function WCard({ data }: { data: WData }) {
  const tele = [
    { icon: "🌡",  label: "体感",   v: data.feels,      u: "°C" },
    { icon: "💧",  label: "湿度",   v: data.humidity,   u: "%"  },
    { icon: "🌬",  label: "风向",   v: data.wind,       u: ""   },
    { icon: "👁",  label: "能见度", v: data.visibility, u: "km" },
    { icon: "🌧",  label: "降水",   v: data.precip,     u: "mm" },
    { icon: "📊",  label: "气压",   v: data.pressure,   u: "hPa"},
  ];
  return (
    <GlassCard r={24} style={{ width: 384 }}>
      {data.alert && (<div style={{ padding: "10px 16px", background: "rgba(245,158,11,.11)", borderBottom: "1px solid rgba(245,158,11,.20)", display: "flex", gap: 10, alignItems: "flex-start" }}><svg width={15} height={15} viewBox="0 0 16 16" fill="none" stroke="#F59E0B" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: 1 }}><path d="M8 2L14 13H2L8 2Z" /><line x1="8" y1="7" x2="8" y2="10" /><circle cx="8" cy="12" r=".6" fill="#F59E0B" stroke="none" /></svg><div><div style={{ fontSize: 12.5, fontWeight: 700, color: "#F59E0B" }}>{data.alert.text}</div><div style={{ fontSize: 11, color: FG2, marginTop: 2, lineHeight: 1.55 }}>{data.alert.desc}</div></div></div>)}
      <div style={{ padding: "18px 18px 12px", display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 8 }}><span style={{ fontSize: 16, fontWeight: 600 }}>{data.city}</span><span style={{ fontSize: 11.5, color: FG3 }}>浙江</span></div>
          <div style={{ display: "flex", alignItems: "flex-start", gap: 4, lineHeight: 1 }}><span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 68, fontWeight: 700, letterSpacing: "-0.03em", color: FG1 }}>{data.temp}</span><span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 24, fontWeight: 300, color: FG2, marginTop: 10 }}>°C</span></div>
          <div style={{ fontSize: 13.5, color: FG2, marginTop: 5 }}>{data.condition}</div>
        </div>
        <div style={{ textAlign: "right", display: "flex", flexDirection: "column", gap: 6, paddingTop: 2 }}><span style={{ fontSize: 44, lineHeight: 1 }}>⛅</span><span style={{ fontSize: 10.5, color: FG3 }}>更新 {data.updated}</span><span style={{ fontSize: 10.5, color: FG3 }}>时效至 {data.valid}</span></div>
      </div>
      <HR />
      <div style={{ padding: "12px 13px", display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 7 }}>
        {tele.map((item,i) => { const miss=item.v===null||item.v===undefined; return (<div key={i} style={{ padding: "9px 6px", borderRadius: 11, background: miss?"rgba(255,255,255,.028)":"rgba(255,255,255,.048)", border: `1px solid rgba(255,255,255,${miss?.048:.08})`, display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}><span style={{ fontSize: 15 }}>{item.icon}</span><span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: typeof item.v==="string"?9.5:12, fontWeight: miss?400:600, color: miss?FG3:FG1, textAlign: "center", lineHeight: 1.2 }}>{miss?"—":`${item.v}${item.u}`}</span><span style={{ fontSize: 9.5, color: FG3 }}>{item.label}</span></div>); })}
      </div>
      <HR />
      <div style={{ padding: "13px 12px", display: "flex" }}>
        {data.forecast.map((f,i) => (<div key={i} style={{ flex: 1, textAlign: "center", padding: "0 6px", borderRight: i<2?`1px solid ${DIV}`:"none" }}><div style={{ fontSize: 11, color: FG3, marginBottom: 6 }}>{f.day}</div><div style={{ fontSize: 28, marginBottom: 4, lineHeight: 1 }}>{f.icon}</div><div style={{ fontSize: 11, color: FG2, marginBottom: 8 }}>{f.cond}</div><div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 4 }}><span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: "#93C5FD" }}>{f.low}°</span><div style={{ flex: 1, height: 2.5, borderRadius: 2, background: "linear-gradient(to right,rgba(91,140,255,.5),rgba(255,165,50,.5))" }} /><span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: "#FCA5A5" }}>{f.high}°</span></div></div>))}
      </div>
      <HR /><AQISec aqi={data.aqi} />
      {data.tips ? (<><HR /><div style={{ padding: "13px 14px" }}><div style={{ fontSize: 10.5, color: FG3, letterSpacing: ".09em", textTransform: "uppercase" as const, fontWeight: 600, marginBottom: 10 }}>生活建议</div><div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>{data.tips.map((t,i) => (<div key={i} style={{ display: "flex", alignItems: "center", gap: 9, padding: "8px 10px", borderRadius: 11, background: "rgba(255,255,255,.04)", border: "1px solid rgba(255,255,255,.07)" }}><span style={{ fontSize: 18 }}>{t.icon}</span><div><div style={{ fontSize: 10.5, color: FG3 }}>{t.label}</div><div style={{ fontSize: 12.5, fontWeight: 600, color: TIP_COLOR[t.level] }}>{t.value}</div></div></div>))}</div></div></>) : (<><HR /><div style={{ padding: "12px 16px", display: "flex", gap: 8, alignItems: "center" }}><span style={{ fontSize: 13, color: FG3 }}>⚠</span><span style={{ fontSize: 12, color: FG3 }}>生活建议数据暂不可用</span></div></>)}
    </GlassCard>
  );
}

// ─── SCard (reused from A-3) ─────────────────────────────────────────────────
function SCard({ data }: { data: SData }) {
  const isUp=data.change>=0, cc=isUp?UP:DN;
  return (
    <GlassCard r={24} style={{ width: 384 }}>
      <div style={{ padding: "16px 18px 12px", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div><div style={{ fontSize: 16, fontWeight: 600, marginBottom: 5 }}>{data.name}</div><div style={{ display: "flex", gap: 8, alignItems: "center" }}><span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, color: FG3 }}>{data.ticker}</span><span style={{ fontSize: 11, color: FG3 }}>·</span><span style={{ fontSize: 11, color: FG3 }}>{data.exchange==="SH"?"上证":"深证"}</span></div></div>
        <div style={{ textAlign: "right", display: "flex", flexDirection: "column", gap: 5 }}><div style={{ padding: "3px 9px", borderRadius: 20, background: "rgba(107,114,128,.10)", border: "1px solid rgba(107,114,128,.20)", display: "inline-flex" }}><span style={{ fontSize: 11, color: FG3 }}>{data.marketStatus} · {data.closedAt}</span></div><span style={{ fontSize: 10.5, color: FG3 }}>A股主板 · 沪市</span></div>
      </div>
      <HR />
      <div style={{ padding: "14px 18px 12px", display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
        <div><div style={{ display: "flex", alignItems: "baseline", gap: 8, marginBottom: 8 }}><span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 40, fontWeight: 700, letterSpacing: "-0.025em", lineHeight: 1, color: cc }}>{data.price.toFixed(2)}</span><span style={{ fontSize: 13, color: FG3, fontFamily: "'JetBrains Mono',monospace" }}>CNY</span></div><div style={{ display: "flex", gap: 8, alignItems: "center" }}><span style={{ padding: "3px 10px", borderRadius: 7, background: `${cc}18`, border: `1px solid ${cc}35`, fontFamily: "'JetBrains Mono',monospace", fontSize: 13, fontWeight: 700, color: cc }}>{isUp?"+":""}{data.change.toFixed(2)}</span><span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 13, fontWeight: 600, color: cc }}>{isUp?"+":""}{data.changePct.toFixed(2)}%</span></div></div>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>{[{l:"今开",v:data.open},{l:"最高",v:data.high},{l:"最低",v:data.low},{l:"昨收",v:data.prevClose}].map(s => (<div key={s.l} style={{ display: "flex", gap: 10, justifyContent: "space-between" }}><span style={{ fontSize: 10.5, color: FG3 }}>{s.l}</span><span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11.5, color: FG1 }}>{s.v.toFixed(2)}</span></div>))}</div>
      </div>
      <HR />
      {data.candles ? (<div style={{ padding: "12px 4px 8px" }}><div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 14px", marginBottom: 8 }}><span style={{ fontSize: 10.5, color: FG3, letterSpacing: ".09em", textTransform: "uppercase" as const, fontWeight: 600 }}>日K线 · 5日</span><div style={{ display: "flex", gap: 10 }}>{["1日","5日","1月","3月"].map((t,i) => <span key={t} style={{ fontSize: 10.5, color: i===1?TEAL:FG3, fontWeight: i===1?600:400, cursor: "pointer" }}>{t}</span>)}</div></div><KChart candles={data.candles} /></div>) : (<div style={{ padding: "22px 18px", display: "flex", flexDirection: "column", alignItems: "center", gap: 8, background: "rgba(255,255,255,.022)" }}><svg width={44} height={32} viewBox="0 0 44 32" fill="none" stroke="rgba(255,255,255,.16)" strokeWidth={1.5} strokeLinecap="round"><polyline points="3,24 11,16 18,19 27,9 41,12" /><line x1="3" y1="28" x2="41" y2="28" /></svg><span style={{ fontSize: 12, color: FG3 }}>K线数据暂不可用</span></div>)}
      <HR />
      <div style={{ padding: "13px 16px", display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: "8px 6px" }}>
        {[{l:"市值",v:data.marketCap},{l:"市盈率",v:data.pe?data.pe.toFixed(1):null},{l:"市净率",v:data.pb?data.pb.toFixed(1):null},{l:"成交量",v:data.vol}].map((s,i) => (<div key={i} style={{ textAlign: "center" }}><div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12.5, fontWeight: 600, color: s.v?FG1:FG3, marginBottom: 4 }}>{s.v??"—"}</div><div style={{ fontSize: 10.5, color: FG3 }}>{s.l}</div></div>))}
      </div>
    </GlassCard>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// A-4 NEW COMPONENTS
// ═══════════════════════════════════════════════════════════════════════════════

// AI badge — marks AI-generated content (§5: 角标形式, 不做彩色背景)
function AIBadge({ label }: { label: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10 }}>
      <div style={{ width: 13, height: 13, borderRadius: 4, background: AURORA, flexShrink: 0 }} />
      <span style={{ ...AURORA_TEXT, fontSize: 10, fontWeight: 700, letterSpacing: ".09em" }}>{label}</span>
    </div>
  );
}

// Confidence badge (§3-A semantic colours, NOT aurora)
function ConfBadge({ level, small = false }: { level: string; small?: boolean }) {
  const { c, bg, bc } = CONF[level] ?? CONF["低"];
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 5, padding: small ? "2px 7px" : "3px 9px", borderRadius: 20, background: bg, border: `1px solid ${bc}`, flexShrink: 0 }}>
      <div style={{ width: small ? 5 : 6, height: small ? 5 : 6, borderRadius: "50%", background: c }} />
      <span style={{ fontSize: small ? 10 : 11.5, fontWeight: 600, color: c }}>置信度 {level}</span>
    </div>
  );
}

// Category chip
function CatChip({ cat }: { cat: string }) {
  const c = CAT_C[cat] ?? FG3;
  return (
    <span style={{ padding: "2px 7px", borderRadius: 5, background: `${c}15`, border: `1px solid ${c}30`, fontSize: 10, fontWeight: 600, color: c, flexShrink: 0 }}>{cat}</span>
  );
}

// Inline citation [N] → teal superscript (§7 数字等宽)
function Refs({ text }: { text: string }) {
  const parts = text.split(/(\[\d+\])/g);
  return (
    <>
      {parts.map((p, i) => {
        const m = p.match(/^\[(\d+)\]$/);
        return m
          ? <sup key={i} style={{ fontSize: ".72em", fontWeight: 700, color: TEAL, opacity: .9 }}>[{m[1]}]</sup>
          : <span key={i}>{p}</span>;
      })}
    </>
  );
}

// ─── A-4.1 Search Card ───────────────────────────────────────────────────────
function SearchCard() {
  const [showMore, setShowMore] = useState(false);
  const visible = showMore ? SEARCH_RESULTS : SEARCH_RESULTS.slice(0, 3);
  const extra   = SEARCH_RESULTS.length - 3;

  return (
    <GlassCard r={22} style={{ width: "100%" }}>
      <div style={{ padding: "15px 16px 12px" }}>
        <AIBadge label="AI · 联网搜索" />
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 10 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 4 }}>
              <Search size={13} color={FG2} />
              <span style={{ fontSize: 14, fontWeight: 600 }}>固态电池量产时间</span>
            </div>
            <span style={{ fontSize: 11, color: FG3 }}>找到 {SEARCH_RESULTS.length} 条来源 · 更新于2分钟前</span>
          </div>
          <ConfBadge level="中" />
        </div>
      </div>

      <HR />

      {visible.map((r, i) => (
        <div key={r.n}>
          <div style={{ padding: "11px 16px", display: "flex", gap: 11, alignItems: "flex-start" }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, flexShrink: 0, marginTop: 1 }}>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: FG3, lineHeight: 1 }}>{r.n}</span>
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: CAT_C[r.cat] ?? FG3 }} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 4, flexWrap: "wrap" as const }}>
                <span style={{ fontSize: 12, fontWeight: 600, color: FG1 }}>{r.site}</span>
                <span style={{ fontSize: 10.5, color: FG3 }}>{r.domain}</span>
                <CatChip cat={r.cat} />
                <span style={{ fontSize: 10.5, color: FG3, marginLeft: "auto", flexShrink: 0 }}>{r.time}</span>
              </div>
              <p style={{ fontSize: 12, color: FG2, lineHeight: 1.65, margin: 0 }}>{r.excerpt}</p>
            </div>
            <ExternalLink size={11} color="rgba(255,255,255,.20)" style={{ flexShrink: 0, marginTop: 2 }} />
          </div>
          {i < visible.length - 1 && <div style={{ height: 1, background: DIV, margin: "0 16px" }} />}
        </div>
      ))}

      <div style={{ padding: "10px 16px 13px", borderTop: `1px solid ${DIV}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", gap: 7, alignItems: "center" }}>
          <RefreshCw size={11} color={FG3} />
          <span style={{ fontSize: 11, color: FG3 }}>时效 2分钟</span>
        </div>
        {!showMore && extra > 0 && (
          <button onClick={() => setShowMore(true)} style={{ fontSize: 12, color: TEAL, background: "none", border: "none", cursor: "pointer", padding: 0, fontFamily: "'Inter',sans-serif" }}>
            更多 {extra} 条 ›
          </button>
        )}
      </div>
    </GlassCard>
  );
}

// ─── A-4.2 News Card ─────────────────────────────────────────────────────────
function NewsCard() {
  const [showMore, setShowMore] = useState(false);
  const [showSrc, setShowSrc]   = useState(false);
  const SHOW    = 5;
  const visible = showMore ? NEWS_ITEMS : NEWS_ITEMS.slice(0, SHOW);
  const extra   = NEWS_ITEMS.length - SHOW;

  return (
    <GlassCard r={22} style={{ width: "100%" }}>
      <div style={{ padding: "15px 16px 12px" }}>
        <AIBadge label="AI · 新闻速览" />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
            <Newspaper size={13} color={FG2} />
            <span style={{ fontSize: 14, fontWeight: 600 }}>今日要闻</span>
          </div>
          <span style={{ fontSize: 11, color: FG3 }}>已摘要 {NEWS_ITEMS.length} 条</span>
        </div>
      </div>

      <HR />

      {visible.map((item, i) => (
        <div key={i}>
          <div style={{ padding: "11px 16px", display: "flex", gap: 11, alignItems: "flex-start" }}>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10.5, color: FG3, flexShrink: 0, marginTop: 1.5, minWidth: 16 }}>
              {String(i + 1).padStart(2, "0")}
            </span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: 7, marginBottom: 5 }}>
                <CatChip cat={item.cat} />
                <span style={{ fontSize: 13, fontWeight: 600, color: FG1, lineHeight: 1.4 }}>{item.title}</span>
              </div>
              <p style={{ fontSize: 11.5, color: FG2, lineHeight: 1.68, margin: "0 0 5px" }}>{item.summary}</p>
              <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
                <span style={{ fontSize: 10.5, fontWeight: 500, color: FG3 }}>{item.source}</span>
                <span style={{ fontSize: 10, color: FG3 }}>·</span>
                <span style={{ fontSize: 10.5, color: FG3 }}>{item.time}</span>
              </div>
            </div>
          </div>
          {i < visible.length - 1 && <div style={{ height: 1, background: DIV, margin: "0 16px" }} />}
        </div>
      ))}

      <div style={{ borderTop: `1px solid ${DIV}`, padding: "10px 16px 13px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <button onClick={() => setShowSrc(v => !v)} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11.5, color: FG2, background: "none", border: "none", cursor: "pointer", padding: 0, fontFamily: "'Inter',sans-serif" }}>
            参考来源 {NEWS_ITEMS.length} 个
            <ChevronDown size={12} color={FG3} style={{ transform: showSrc ? "rotate(180deg)" : "none", transition: "transform .2s" }} />
          </button>
          {!showMore && extra > 0 && (
            <button onClick={() => setShowMore(true)} style={{ fontSize: 12, color: TEAL, background: "none", border: "none", cursor: "pointer", padding: 0, fontFamily: "'Inter',sans-serif" }}>
              更多 {extra} 条 ›
            </button>
          )}
        </div>
        {showSrc && (
          <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 5 }}>
            {NEWS_ITEMS.map((item, i) => (
              <div key={i} style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <div style={{ width: 6, height: 6, borderRadius: "50%", background: CAT_C[item.cat] ?? FG3, flexShrink: 0 }} />
                <span style={{ fontSize: 11, color: FG2 }}>{item.source}</span>
                <span style={{ fontSize: 10.5, color: FG3 }}>· {item.time}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </GlassCard>
  );
}

// ─── Research section (expandable) ───────────────────────────────────────────
function RSection({ data, open, onToggle }: { data: typeof RSECTIONS[0]; open: boolean; onToggle: () => void }) {
  const { c } = CONF[data.conf] ?? CONF["低"];
  return (
    <div>
      <button onClick={onToggle} style={{ width: "100%", padding: "12px 16px", display: "flex", alignItems: "center", gap: 10, background: "none", border: "none", cursor: "pointer", textAlign: "left", color: FG1, fontFamily: "'Inter','Noto Sans SC',sans-serif" }}>
        <div style={{ width: 24, height: 24, borderRadius: 8, flexShrink: 0, background: open ? `${c}18` : "rgba(255,255,255,.06)", border: `1px solid ${open ? `${c}35` : "rgba(255,255,255,.10)"}`, display: "flex", alignItems: "center", justifyContent: "center", transition: "all .22s" }}>
          <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, fontWeight: 700, color: open ? c : FG3 }}>{String(data.n).padStart(2, "0")}</span>
        </div>
        <span style={{ flex: 1, fontSize: 13.5, fontWeight: 600, color: open ? FG1 : FG2, transition: "color .2s" }}>{data.title}</span>
        <ConfBadge level={data.conf} small />
        <ChevronDown size={14} color={FG3} style={{ flexShrink: 0, transform: open ? "rotate(180deg)" : "none", transition: "transform .22s ease" }} />
      </button>
      <div style={{ maxHeight: open ? 600 : 0, overflow: "hidden", transition: "max-height .30s ease" }}>
        <div style={{ padding: "2px 16px 16px 52px" }}>
          <p style={{ fontSize: 13, color: FG2, lineHeight: 1.80, margin: 0 }}>
            <Refs text={data.body} />
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── A-4.3 Research Card (flagship) ──────────────────────────────────────────
function ResearchCard() {
  const [expanded, setExpanded] = useState(new Set<number>([1]));
  const allOpen = expanded.size === RSECTIONS.length;

  const toggle = (n: number) => setExpanded(prev => {
    const s = new Set(prev);
    s.has(n) ? s.delete(n) : s.add(n);
    return s;
  });

  return (
    <GlassCard r={24} style={{ width: "100%" }}>

      {/* Header */}
      <div style={{ padding: "16px 18px 14px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 11 }}>
          <AIBadge label="AI · 深度调研报告" />
          {/* 升舱 button — §5 主操作 */}
          <button style={{ display: "flex", alignItems: "center", gap: 5, padding: "4px 11px", borderRadius: 20, background: "rgba(255,255,255,.04)", border: "1px solid rgba(255,255,255,.09)", fontSize: 10.5, color: FG2, cursor: "pointer", flexShrink: 0, fontFamily: "'Inter',sans-serif" }}>
            <Maximize2 size={10} color={FG3} />
            在右屏展开
          </button>
        </div>

        {/* Question */}
        <div style={{ display: "flex", gap: 9, alignItems: "flex-start", marginBottom: 12 }}>
          <BookOpen size={14} color={FG2} style={{ flexShrink: 0, marginTop: 2 }} />
          <span style={{ fontSize: 15, fontWeight: 600, lineHeight: 1.38 }}>固态电池 2027 年量产可行性</span>
        </div>

        {/* One-line summary */}
        <div style={{ padding: "11px 14px", borderRadius: 12, background: "rgba(70,214,224,.07)", border: "1px solid rgba(70,214,224,.16)", marginBottom: 13 }}>
          <p style={{ fontSize: 13, color: FG1, lineHeight: 1.72, margin: 0 }}>
            技术路线已基本确立，但量产良率与成本控制仍是决定性障碍；
            <span style={{ fontWeight: 600 }}>2027年小批量可行，规模化量产大概率推迟至2030年后</span>。
          </p>
        </div>

        {/* Meta */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" as const }}>
          <ConfBadge level="中" />
          <span style={{ fontSize: 11, color: FG3 }}>·</span>
          <span style={{ fontSize: 11, color: FG3 }}>调研日期 2025-06-29</span>
          <span style={{ fontSize: 11, color: FG3 }}>·</span>
          <span style={{ fontSize: 11, color: FG3 }}>时效 12小时</span>
          <span style={{ fontSize: 11, color: FG3 }}>·</span>
          <span style={{ fontSize: 11, color: FG3 }}>引用 {REFS.length} 篇</span>
        </div>
      </div>

      <HR />

      {/* Sections */}
      {RSECTIONS.map((sec, i) => (
        <div key={sec.n}>
          <RSection data={sec} open={expanded.has(sec.n)} onToggle={() => toggle(sec.n)} />
          {i < RSECTIONS.length - 1 && <HR />}
        </div>
      ))}

      {/* Expand all */}
      {!allOpen && (
        <>
          <HR />
          <div style={{ padding: "12px 16px", textAlign: "center" as const }}>
            <button onClick={() => setExpanded(new Set(RSECTIONS.map(s => s.n)))} style={{ padding: "8px 22px", borderRadius: 20, background: "rgba(70,214,224,.08)", border: "1px solid rgba(70,214,224,.22)", color: TEAL, fontSize: 12.5, fontWeight: 500, cursor: "pointer", fontFamily: "'Inter','Noto Sans SC',sans-serif" }}>
              展开完整报告（共 {RSECTIONS.length} 节）
            </button>
          </div>
        </>
      )}

      <HR />

      {/* Gaps */}
      <div style={{ padding: "13px 16px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
          <AlertTriangle size={13} color="#F59E0B" />
          <span style={{ fontSize: 11.5, fontWeight: 700, color: "#F59E0B" }}>未覆盖数据缺口</span>
        </div>
        {GAPS.map((g, i) => (
          <div key={i} style={{ display: "flex", gap: 9, alignItems: "flex-start", marginBottom: i < GAPS.length - 1 ? 7 : 0 }}>
            <div style={{ width: 5, height: 5, borderRadius: "50%", background: "rgba(245,158,11,.55)", flexShrink: 0, marginTop: 5.5 }} />
            <span style={{ fontSize: 12, color: FG2, lineHeight: 1.65 }}>{g}</span>
          </div>
        ))}
      </div>

      <HR />

      {/* Global bibliography */}
      <div style={{ padding: "13px 16px" }}>
        <div style={{ fontSize: 10.5, color: FG3, letterSpacing: ".09em", textTransform: "uppercase" as const, fontWeight: 600, marginBottom: 10 }}>参考来源</div>
        {REFS.map(r => (
          <div key={r.id} style={{ display: "flex", gap: 9, alignItems: "flex-start", marginBottom: 8 }}>
            <sup style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 9, fontWeight: 700, color: TEAL, flexShrink: 0, marginTop: 3.5, minWidth: 14 }}>[{r.id}]</sup>
            <div>
              <span style={{ fontSize: 12, color: FG2 }}>{r.title}</span>
              <span style={{ fontSize: 11, color: FG3 }}> — {r.site} · {r.domain} · {r.time}</span>
            </div>
          </div>
        ))}
      </div>

    </GlassCard>
  );
}

// ─── Page helpers ─────────────────────────────────────────────────────────────
function SecLabel({ num, title, sub }: { num: string; title: string; sub: string }) {
  return (
    <div style={{ marginBottom: 28 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 5 }}>
        <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10.5, color: FG3, letterSpacing: ".12em" }}>{num}</span>
        <div style={{ width: 1, height: 14, background: "rgba(255,255,255,.10)" }} />
        <div style={{ width: 3, height: 18, background: AURORA, borderRadius: 2 }} />
        <h2 style={{ fontSize: 16.5, fontWeight: 500, margin: 0, letterSpacing: ".03em" }}>{title}</h2>
      </div>
      <p style={{ fontSize: 12.5, color: FG3, margin: 0, paddingLeft: 52, lineHeight: 1.6 }}>{sub}</p>
    </div>
  );
}

// ─── App — A-4 Showcase ───────────────────────────────────────────────────────
export default function App() {
  return (
    <div style={{ minHeight: "100vh", fontFamily: "'Inter','Noto Sans SC',-apple-system,sans-serif", color: FG1, background: "linear-gradient(155deg,#06080F 0%,#0A0E1A 52%,#080D18 100%)" }}>
      <style>{KEYFRAMES}</style>

      {/* Atmosphere (Layer 0 §2) */}
      <div aria-hidden style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
        <div style={{ position: "absolute", bottom: "8%",  left: "12%",  width: 620, height: 430, background: "radial-gradient(circle,rgba(91,140,255,.10) 0%,transparent 68%)", filter: "blur(52px)" }} />
        <div style={{ position: "absolute", top: "10%",   right: "10%", width: 500, height: 370, background: "radial-gradient(circle,rgba(91,233,255,.07) 0%,transparent 68%)", filter: "blur(58px)" }} />
        <div style={{ position: "absolute", top: "44%",   left: "36%",  width: 660, height: 490, background: "radial-gradient(circle,rgba(154,107,255,.06) 0%,transparent 68%)", filter: "blur(64px)" }} />
      </div>

      {/* Header */}
      <header style={{ position: "sticky", top: 0, zIndex: 30, height: 56, padding: "0 48px", display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(6,8,15,.80)", backdropFilter: "blur(28px)", WebkitBackdropFilter: "blur(28px)", borderBottom: `1px solid ${DIV}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 26, height: 26 }}><AuroraOrb state="idle" size={26} /></div>
          <span style={{ ...AURORA_TEXT, fontSize: 14, fontWeight: 600 }}>Aurora Glass</span>
          <span style={{ fontSize: 13, color: FG3, fontWeight: 300 }}>· A-4 卡片族 · 搜索 / 新闻 / 深度调研</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ width: 12, height: 12, borderRadius: 3, background: AURORA }} />
          <span style={{ fontSize: 11, color: FG3 }}>AI 角标 = 生成内容标识（§5）· 卡片只给证据</span>
        </div>
      </header>

      {/* Content */}
      <div style={{ position: "relative", zIndex: 1, maxWidth: 1440, margin: "0 auto", padding: "52px 48px 100px" }}>

        {/* Section header */}
        <div style={{ marginBottom: 32 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 6 }}>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10.5, color: FG3, letterSpacing: ".12em" }}>A-4</span>
            <div style={{ width: 1, height: 14, background: "rgba(255,255,255,.10)" }} />
            <div style={{ width: 3, height: 18, background: AURORA, borderRadius: 2 }} />
            <h2 style={{ fontSize: 17, fontWeight: 500, margin: 0, letterSpacing: ".03em" }}>证据卡三件套 — 搜索 · 新闻 · 深度调研</h2>
          </div>
          <p style={{ fontSize: 12.5, color: FG3, margin: 0, paddingLeft: 52, lineHeight: 1.7 }}>
            三类卡均为 AI 生成内容，以极光方块 + 渐变文字角标标识。卡片只呈现数据证据，不复读气泡结论。深度调研卡可「在右屏展开」升舱至舞台区阅读。
          </p>
        </div>

        {/* Column labels */}
        <div style={{ display: "flex", gap: 20, marginBottom: 14, alignItems: "flex-end" }}>
          <div style={{ width: 400, flexShrink: 0 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: FG2, marginBottom: 2 }}>A-4.1 · 联网搜索证据卡</div>
            <div style={{ fontSize: 10.5, color: FG3 }}>来源列表 · 时效 · 置信度 · 更多</div>
          </div>
          <div style={{ width: 400, flexShrink: 0 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: FG2, marginBottom: 2 }}>A-4.2 · 新闻速览卡</div>
            <div style={{ fontSize: 10.5, color: FG3 }}>编号条目 · 折叠来源 · 更多 N 条</div>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: FG2, marginBottom: 2 }}>
              A-4.3 · 深度调研报告卡 <span style={{ ...AURORA_TEXT }}>（产品门面）</span>
            </div>
            <div style={{ fontSize: 10.5, color: FG3 }}>分节展开 · 置信度分级 · 数据缺口 · 全局引用 · 升舱按钮</div>
          </div>
        </div>

        {/* Cards */}
        <div style={{ display: "flex", gap: 20, alignItems: "flex-start" }}>
          {/* Left col: search + news */}
          <div style={{ width: 400, flexShrink: 0, display: "flex", flexDirection: "column", gap: 20 }}>
            <SearchCard />
            <NewsCard />
          </div>
          {/* Right col: research */}
          <div style={{ flex: 1, minWidth: 0 }}>
            <ResearchCard />
          </div>
        </div>

      </div>
    </div>
  );
}
