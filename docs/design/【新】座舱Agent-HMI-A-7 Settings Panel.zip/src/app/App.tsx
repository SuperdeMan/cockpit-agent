// Design contract: guidelines/Guidelines.md
// Page: A-7 设置面板 · 横屏侧栏式
// Reused: AuroraOrb, GlassCard, AURORA*, TEAL, FG1/2/3, DIV, KEYFRAMES
// New:    Toggle, Segment, TextInput, GhostBtn, DangerBtn, NavItem,
//         SettingRow, SettingGroup, SectionHdr, VoiceCard + 8 section renderers

import { useState, CSSProperties, ReactNode } from "react";
import { X, Plus, ChevronRight, MapPin, Check, Pencil } from "lucide-react";

// ─── Design Tokens ────────────────────────────────────────────────────────────
const AURORA       = "linear-gradient(135deg,#5BE9FF 0%,#5B8CFF 33%,#9A6BFF 66%,#FF6BD6 100%)";
const AURORA_CONIC = "conic-gradient(from 0deg,#5BE9FF,#5B8CFF,#9A6BFF,#FF6BD6,#5BE9FF)";
const AURORA_TEXT: CSSProperties = {
  background: AURORA, WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent", backgroundClip: "text",
};
const TEAL = "#46D6E0";
const FG1  = "rgba(255,255,255,0.92)";
const FG2  = "rgba(255,255,255,0.56)";
const FG3  = "rgba(255,255,255,0.32)";
const DIV  = "rgba(255,255,255,0.07)";

// ─── Keyframes ────────────────────────────────────────────────────────────────
const KEYFRAMES = `
  @keyframes aurora-breathe {
    0%,100%{opacity:.82;transform:scale(1)} 50%{opacity:1;transform:scale(1.038)}
  }
  @keyframes aurora-breathe-fast {
    0%,100%{opacity:.85;transform:scale(1)} 50%{opacity:1;transform:scale(1.045)}
  }
  @keyframes aurora-spin {
    from{transform:rotate(0deg)} to{transform:rotate(360deg)}
  }
  @keyframes aurora-spin-r {
    from{transform:rotate(360deg)} to{transform:rotate(0deg)}
  }
  @keyframes aurora-pulse {
    0%,100%{transform:scale(1);opacity:.86}
    25%{transform:scale(1.07);opacity:1}
    75%{transform:scale(0.96);opacity:.80}
  }
  @keyframes play-spin {
    from{transform:rotate(0deg)} to{transform:rotate(360deg)}
  }
  *{scrollbar-width:thin;scrollbar-color:rgba(91,140,255,.22) transparent}
  input::placeholder{color:rgba(255,255,255,0.28)}
  @media(prefers-reduced-motion:reduce){*{animation-duration:.01ms!important}}
`;

// ─── AuroraOrb ────────────────────────────────────────────────────────────────
type OrbState = "idle" | "thinking" | "speaking";
function AuroraOrb({ state = "idle", size = 40 }: { state?: OrbState; size?: number }) {
  const thinking = state === "thinking", speaking = state === "speaking";
  const glowMult = speaking ? 1.35 : 1;
  const outerAnim = thinking ? "aurora-breathe-fast 1.4s ease-in-out infinite"
                  : speaking  ? "aurora-pulse 0.72s ease-in-out infinite"
                  :             "aurora-breathe 4s ease-in-out infinite";
  const hs = thinking ? "1.6s" : "8s", is = thinking ? "1.1s" : "5s", cs = thinking ? "0.8s" : "3.8s";
  const s = size;
  return (
    <div style={{ position: "relative", width: s, height: s, flexShrink: 0 }}>
      <div style={{ position: "absolute", inset: -s*.52, borderRadius: "50%", background: `radial-gradient(circle,rgba(91,140,255,${.20*glowMult}) 0%,rgba(154,107,255,${.11*glowMult}) 40%,transparent 70%)`, animation: outerAnim, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: -s*.06, borderRadius: "50%", background: AURORA_CONIC, opacity: thinking?.52:.26, filter: `blur(${s*.115}px)`, animation: `aurora-spin ${hs} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: 0, borderRadius: "50%", background: `radial-gradient(circle at 36% 28%,rgba(255,255,255,.44) 0%,rgba(91,233,255,.22) 28%,rgba(91,140,255,.18) 56%,rgba(154,107,255,.26) 78%,rgba(255,107,214,.14) 100%)`, backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)", border: "1px solid rgba(255,255,255,.24)", boxShadow: `0 0 ${s*.32*glowMult}px rgba(91,142,255,.52),0 0 ${s*.70*glowMult}px rgba(154,107,255,.22),inset 0 0 ${s*.24}px rgba(91,233,255,.20),inset 0 ${s*.012}px 0 rgba(255,255,255,.34)`, animation: outerAnim, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: s*.16, borderRadius: "50%", background: AURORA_CONIC, opacity: .70, filter: `blur(${s*.036}px)`, animation: `aurora-spin ${is} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: s*.28, borderRadius: "50%", background: `conic-gradient(from 180deg,#9A6BFF,#5B8CFF,#5BE9FF,#FF6BD6,#9A6BFF)`, opacity: .54, filter: `blur(${s*.028}px)`, animation: `aurora-spin-r ${cs} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", top: "9%", left: "13%", width: "44%", height: "33%", borderRadius: "50%", background: "radial-gradient(ellipse,rgba(255,255,255,.70) 0%,transparent 100%)", filter: "blur(2px)", pointerEvents: "none" }} />
    </div>
  );
}

// ─── GlassCard ────────────────────────────────────────────────────────────────
function GlassCard({ children, p = 0, r = 20, style }: { children?: ReactNode; p?: number; r?: number; style?: CSSProperties }) {
  return (
    <div style={{
      padding: p, borderRadius: r, overflow: "hidden",
      background: "rgba(255,255,255,.056)",
      backdropFilter: "blur(32px)", WebkitBackdropFilter: "blur(32px)",
      border: "1px solid rgba(255,255,255,.10)",
      borderTop: "1px solid rgba(255,255,255,.17)",
      borderLeft: "1px solid rgba(255,255,255,.13)",
      boxShadow: "0 8px 40px rgba(0,0,0,.50),0 2px 12px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.13)",
      ...style,
    }}>{children}</div>
  );
}
const HR = () => <div style={{ height: 1, background: DIV }} />;

// ═══════════════════════════════════════════════════════════════════════════════
// CONTROL COMPONENTS (reusable, §9)
// ═══════════════════════════════════════════════════════════════════════════════

// Toggle switch — §6 glassmorphic thumb
function Toggle({ on, onChange, disabled = false }: { on: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <button
      onClick={() => !disabled && onChange(!on)}
      style={{
        width: 48, height: 28, borderRadius: 14, cursor: disabled ? "default" : "pointer",
        background: on ? (disabled ? "rgba(70,214,224,.35)" : TEAL) : "rgba(255,255,255,.10)",
        border: `1px solid ${on ? (disabled ? "rgba(70,214,224,.25)" : TEAL) : "rgba(255,255,255,.15)"}`,
        position: "relative", transition: "all .25s ease",
        opacity: disabled ? .45 : 1, flexShrink: 0,
        boxShadow: on && !disabled ? `0 0 12px rgba(70,214,224,.40)` : "none",
      }}>
      <div style={{
        position: "absolute", top: 3, left: on ? 22 : 2, width: 20, height: 20,
        borderRadius: "50%", background: "white",
        transition: "left .25s ease",
        boxShadow: "0 1px 4px rgba(0,0,0,.35)",
      }} />
    </button>
  );
}

// Segmented control
function Segment({ options, value, onChange, sm = false }: { options: string[]; value: string; onChange: (v: string) => void; sm?: boolean }) {
  return (
    <div style={{ display: "flex", background: "rgba(255,255,255,.04)", borderRadius: sm ? 10 : 12, padding: 3, gap: 2 }}>
      {options.map(opt => (
        <button key={opt} onClick={() => onChange(opt)} style={{
          padding: sm ? "5px 10px" : "7px 14px", borderRadius: sm ? 8 : 10,
          cursor: "pointer", fontSize: sm ? 11.5 : 13,
          fontWeight: opt === value ? 600 : 400,
          background: opt === value ? "rgba(255,255,255,.10)" : "transparent",
          border: `1px solid ${opt === value ? "rgba(255,255,255,.18)" : "transparent"}`,
          color: opt === value ? FG1 : FG2,
          transition: "all .18s", fontFamily: "'Inter','Noto Sans SC',sans-serif",
          whiteSpace: "nowrap" as const,
        }}>{opt}</button>
      ))}
    </div>
  );
}

// Text input
function TextInput({ value, onChange, placeholder, width = 200 }: { value: string; onChange: (v: string) => void; placeholder?: string; width?: number }) {
  return (
    <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
      style={{
        width, height: 38, paddingLeft: 14, paddingRight: 14, boxSizing: "border-box" as const,
        borderRadius: 10,
        background: "rgba(255,255,255,.058)",
        border: "1px solid rgba(255,255,255,.10)",
        borderTop: "1px solid rgba(255,255,255,.17)",
        color: FG1, fontSize: 13.5,
        fontFamily: "'Inter','Noto Sans SC',sans-serif",
        outline: "none", caretColor: TEAL,
        backdropFilter: "blur(12px)", WebkitBackdropFilter: "blur(12px)",
        boxShadow: "inset 0 1px 0 rgba(255,255,255,.06)",
      }}
    />
  );
}

// Ghost button
function GhostBtn({ children, onClick, sm = false }: { children: ReactNode; onClick?: () => void; sm?: boolean }) {
  return (
    <button onClick={onClick} style={{
      display: "flex", alignItems: "center", gap: 6,
      padding: sm ? "5px 12px" : "7px 14px", borderRadius: 10,
      border: "1px solid rgba(255,255,255,.16)", background: "rgba(255,255,255,.04)",
      color: FG2, fontSize: sm ? 12 : 13, cursor: "pointer",
      fontFamily: "'Inter','Noto Sans SC',sans-serif", transition: "all .18s",
    }}>{children}</button>
  );
}

// Danger button
function DangerBtn({ children, onClick }: { children: ReactNode; onClick?: () => void }) {
  return (
    <button onClick={onClick} style={{
      width: "100%", padding: "9px 0", borderRadius: 12,
      border: "1px solid rgba(239,68,68,.28)", background: "rgba(239,68,68,.06)",
      color: "#EF4444", fontSize: 13, cursor: "pointer",
      fontFamily: "'Inter','Noto Sans SC',sans-serif",
    }}>{children}</button>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// LAYOUT COMPONENTS
// ═══════════════════════════════════════════════════════════════════════════════

type SectionId = "voice-out" | "voice-in" | "display" | "location" | "places" | "assistant" | "caps" | "memory";

const NAV_ITEMS: { id: SectionId; icon: string; label: string }[] = [
  { id: "voice-out",  icon: "🔊", label: "语音播报"  },
  { id: "voice-in",   icon: "🎤", label: "语音输入"  },
  { id: "display",    icon: "🎨", label: "显示主题"  },
  { id: "location",   icon: "📍", label: "当前位置"  },
  { id: "places",     icon: "🏠", label: "常用地点"  },
  { id: "assistant",  icon: "🤖", label: "助手设置"  },
  { id: "caps",       icon: "⚡", label: "能力开关"  },
  { id: "memory",     icon: "💭", label: "记忆"      },
];

function NavItem({ icon, label, active, onClick }: { icon: string; label: string; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} style={{
      width: "100%", padding: "10px 12px", borderRadius: 12, cursor: "pointer",
      display: "flex", alignItems: "center", gap: 10, marginBottom: 2,
      background: active ? "rgba(70,214,224,.10)" : "transparent",
      border: `1px solid ${active ? "rgba(70,214,224,.22)" : "transparent"}`,
      color: active ? TEAL : FG2, textAlign: "left",
      transition: "all .18s", fontFamily: "'Inter','Noto Sans SC',sans-serif",
    }}>
      <span style={{ fontSize: 15, lineHeight: 1, flexShrink: 0 }}>{icon}</span>
      <span style={{ fontSize: 13, fontWeight: active ? 600 : 400, flex: 1 }}>{label}</span>
      {active && <ChevronRight size={13} color={TEAL} />}
    </button>
  );
}

function SectionHdr({ icon, title, sub }: { icon: string; title: string; sub?: string }) {
  return (
    <div style={{ padding: "22px 28px 16px", borderBottom: `1px solid ${DIV}` }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: sub ? 5 : 0 }}>
        <span style={{ fontSize: 20 }}>{icon}</span>
        <h2 style={{ fontSize: 17, fontWeight: 600, margin: 0 }}>{title}</h2>
      </div>
      {sub && <div style={{ fontSize: 12.5, color: FG3, paddingLeft: 30, lineHeight: 1.6 }}>{sub}</div>}
    </div>
  );
}

function SettingGroup({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div>
      <div style={{ padding: "14px 28px 6px", fontSize: 10.5, fontWeight: 600, letterSpacing: ".09em", textTransform: "uppercase" as const, color: FG3 }}>{title}</div>
      <div style={{ padding: "0 28px" }}>{children}</div>
    </div>
  );
}

function SettingRow({ label, sub, children, noBorder = false }: { label: string; sub?: string; children?: ReactNode; noBorder?: boolean }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "15px 0", borderBottom: noBorder ? "none" : `1px solid ${DIV}` }}>
      <div style={{ flex: 1, paddingRight: 20 }}>
        <div style={{ fontSize: 14, color: FG1 }}>{label}</div>
        {sub && <div style={{ fontSize: 12, color: FG3, marginTop: 3, lineHeight: 1.55 }}>{sub}</div>}
      </div>
      {children && <div style={{ flexShrink: 0 }}>{children}</div>}
    </div>
  );
}

// ─── Voice card ───────────────────────────────────────────────────────────────
const VOICES = [
  { id: "ice",    name: "冰糖",  desc: "温柔亲切", emoji: "🧊", color: "#5BE9FF" },
  { id: "jasmine",name: "茉莉",  desc: "清新自然", emoji: "🌸", color: "#34D399" },
  { id: "soda",   name: "苏打",  desc: "活泼明快", emoji: "🫧", color: "#A3E635" },
  { id: "birch",  name: "白桦",  desc: "沉稳成熟", emoji: "🌲", color: "#9A6BFF" },
  { id: "mia",    name: "Mia",   desc: "中英双语", emoji: "✨", color: "#FF6BD6" },
  { id: "chloe",  name: "Chloe", desc: "专业简洁", emoji: "💎", color: "#5B8CFF" },
];

function VoiceCard({ voice, selected, onSelect, playing, onPlay, disabled }: {
  voice: typeof VOICES[0]; selected: boolean; onSelect: (id: string) => void;
  playing: boolean; onPlay: (id: string) => void; disabled?: boolean;
}) {
  const { color } = voice;
  return (
    <div onClick={() => !disabled && onSelect(voice.id)} style={{
      padding: "14px 12px", borderRadius: 16, cursor: disabled ? "default" : "pointer",
      background: selected ? `${color}14` : "rgba(255,255,255,.04)",
      border: `1px solid ${selected ? color + "50" : "rgba(255,255,255,.08)"}`,
      borderTop: `1px solid ${selected ? color + "70" : "rgba(255,255,255,.12)"}`,
      transition: "all .2s",
      opacity: disabled ? .45 : 1,
      boxShadow: selected ? `0 0 18px ${color}18` : "none",
    }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
        <span style={{ fontSize: 20 }}>{voice.emoji}</span>
        {selected && <div style={{ width: 16, height: 16, borderRadius: "50%", background: color, display: "flex", alignItems: "center", justifyContent: "center" }}><Check size={9} color="#06080F" /></div>}
      </div>
      <div style={{ fontSize: 13.5, fontWeight: 600, color: selected ? color : FG1, marginBottom: 2 }}>{voice.name}</div>
      <div style={{ fontSize: 11, color: FG3, marginBottom: 10 }}>{voice.desc}</div>
      <button
        onClick={e => { e.stopPropagation(); !disabled && onPlay(voice.id); }}
        style={{
          display: "flex", alignItems: "center", gap: 5,
          padding: "4px 10px", borderRadius: 8,
          background: playing ? `${color}20` : "rgba(255,255,255,.05)",
          border: `1px solid ${playing ? color+"40" : "rgba(255,255,255,.10)"}`,
          fontSize: 11.5, color: playing ? color : FG3, cursor: disabled ? "default" : "pointer",
          fontFamily: "'Inter',sans-serif",
          transition: "all .18s",
        }}>
        {playing
          ? <div style={{ width: 10, height: 10, border: `1.5px solid ${color}`, borderTopColor: "transparent", borderRadius: "50%", animation: "play-spin .9s linear infinite" }} />
          : "▸"}
        {playing ? "播放中…" : "试听"}
      </button>
    </div>
  );
}

// ─── Capabilities data ────────────────────────────────────────────────────────
const CAPS_DATA = [
  { id: "car",      icon: "🚘", name: "车辆控制", core: true  },
  { id: "media",    icon: "🎵", name: "媒体",     core: true  },
  { id: "nav",      icon: "🧭", name: "导航",     core: false },
  { id: "info",     icon: "ℹ️", name: "信息",    core: false },
  { id: "trip",     icon: "🗺️", name: "行程",    core: false },
  { id: "research", icon: "🔬", name: "深度调研", core: false },
  { id: "food",     icon: "🍜", name: "点餐",     core: false },
  { id: "park",     icon: "🅿️", name: "停车",    core: false },
  { id: "manual",   icon: "📖", name: "手册",     core: false },
  { id: "chat",     icon: "💬", name: "闲聊",     core: true  },
];

// ─── Memory data ──────────────────────────────────────────────────────────────
const SESSIONS_DATA = [
  { id: "s1", title: "固态电池量产时间调研",   date: "2025-06-29 17:41", msgs: 8  },
  { id: "s2", title: "杭州今日天气",           date: "2025-06-29 14:30", msgs: 3  },
  { id: "s3", title: "成都3日自驾行程规划",    date: "2025-06-28 09:15", msgs: 12 },
  { id: "s4", title: "英超曼城 vs 阿森纳",    date: "2025-06-27 22:08", msgs: 4  },
];
const MEM_INITIAL = [
  { id: "m1", cat: "偏好",   text: "喜欢简短的回答，不喜欢长篇大论" },
  { id: "m2", cat: "偏好",   text: "出行时偏好避开高速收费路段" },
  { id: "m3", cat: "常去地点", text: "经常去杭州西溪湿地公园" },
  { id: "m4", cat: "常去地点", text: "工作地在阿里巴巴西溪园区附近" },
  { id: "m5", cat: "经历",   text: "喜欢固态电池相关的深度报告" },
  { id: "m6", cat: "经历",   text: "2025年6月规划了成都3日自驾游" },
];

// ═══════════════════════════════════════════════════════════════════════════════
// APP
// ═══════════════════════════════════════════════════════════════════════════════
export default function App() {
  const [active, setActive] = useState<SectionId>("voice-out");

  // ── Voice Output ──
  const [voiceOn,        setVoiceOn]        = useState(true);
  const [autoPlay,       setAutoPlay]       = useState(true);
  const [selectedVoice,  setSelectedVoice]  = useState("ice");
  const [playingVoice,   setPlayingVoice]   = useState<string | null>(null);

  // ── Voice Input ──
  const [lang,       setLang]       = useState("自动");
  const [micMode,    setMicMode]    = useState("点按");
  const [listenDur,  setListenDur]  = useState("15s");
  const [noiseCanc,  setNoiseCanc]  = useState(true);

  // ── Display ──
  const [theme,      setTheme]      = useState("深色");
  const [fontSz,     setFontSz]     = useState("标准");
  const [largeTap,   setLargeTap]   = useState(false);
  const [quickCmds,  setQuickCmds]  = useState(["打开空调 26°","附近的充电站","导航去公司","今天限行吗","讲个笑话"]);

  // ── Location ──
  const [locOn,      setLocOn]      = useState(true);
  const [preciseOn,  setPreciseOn]  = useState(true);
  const [bgLocOn,    setBgLocOn]    = useState(false);

  // ── Places ──
  const [places, setPlaces] = useState<Record<string,string>>({
    home: "杭州市西湖区文三路123号", work: "", school: "",
  });

  // ── Assistant ──
  const [nickname,     setNickname]     = useState("小舟");
  const [respLen,      setRespLen]      = useState("标准");
  const [modelChoice,  setModelChoice]  = useState("自动");

  // ── Capabilities ──
  const [caps, setCaps] = useState<Record<string,boolean>>(
    Object.fromEntries(CAPS_DATA.map(c => [c.id, true]))
  );

  // ── Memory ──
  const [memOn,    setMemOn]    = useState(true);
  const [memories, setMemories] = useState(MEM_INITIAL);

  const playVoice = (id: string) => {
    setPlayingVoice(id);
    setTimeout(() => setPlayingVoice(null), 2200);
  };

  // ── SECTION RENDERERS ────────────────────────────────────────────────────────

  const renderVoiceOut = () => (
    <div>
      <SectionHdr icon="🔊" title="语音播报" sub="控制助手的语音输出方式与音色偏好" />
      <SettingGroup title="输出控制">
        <SettingRow label="启用语音播报" sub="关闭后助手仅显示文字，不朗读回答">
          <Toggle on={voiceOn} onChange={setVoiceOn} />
        </SettingRow>
        <SettingRow label="自动播放回答" sub="收到回答后立即朗读，无需手动点击" noBorder>
          <Toggle on={autoPlay} onChange={setAutoPlay} disabled={!voiceOn} />
        </SettingRow>
      </SettingGroup>
      <HR />
      <SettingGroup title="音色选择">
        <div style={{ paddingBottom: 20 }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12, paddingTop: 10 }}>
            {VOICES.map(v => (
              <VoiceCard key={v.id} voice={v}
                selected={selectedVoice === v.id} onSelect={setSelectedVoice}
                playing={playingVoice === v.id} onPlay={playVoice}
                disabled={!voiceOn} />
            ))}
          </div>
        </div>
      </SettingGroup>
    </div>
  );

  const renderVoiceIn = () => (
    <div>
      <SectionHdr icon="🎤" title="语音输入" sub="配置语音识别的语言、模式与时长" />
      <SettingGroup title="识别设置">
        <SettingRow label="识别语言" sub="选择主要识别语言">
          <Segment options={["中文", "英文", "自动"]} value={lang} onChange={setLang} />
        </SettingRow>
        <SettingRow label="麦克风模式" sub="按住说话或单次点击激活">
          <Segment options={["按住", "点按"]} value={micMode} onChange={setMicMode} />
        </SettingRow>
        <SettingRow label="最长聆听时长" sub="超时后自动停止录音">
          <Segment options={["10s", "15s", "30s", "60s"]} value={listenDur} onChange={setListenDur} sm />
        </SettingRow>
        <SettingRow label="环境降噪" sub="在嘈杂环境下提升识别准确率" noBorder>
          <Toggle on={noiseCanc} onChange={setNoiseCanc} />
        </SettingRow>
      </SettingGroup>
    </div>
  );

  const renderDisplay = () => (
    <div>
      <SectionHdr icon="🎨" title="显示主题" sub="界面外观、字号与快捷指令定制" />
      <SettingGroup title="外观">
        <SettingRow label="主题" sub="深色适合夜间驾驶，浅色适合晴天">
          <Segment options={["深色", "浅色"]} value={theme} onChange={setTheme} />
        </SettingRow>
        <SettingRow label="字号" sub="大字模式放大所有文本，提升行车可读性">
          <Segment options={["标准", "大字"]} value={fontSz} onChange={setFontSz} />
        </SettingRow>
        <SettingRow label="大触控模式" sub={`行车时自动放大所有按钮至 56px（§11 车规）`} noBorder>
          <Toggle on={largeTap} onChange={setLargeTap} />
        </SettingRow>
      </SettingGroup>
      <HR />
      <SettingGroup title="快捷指令">
        <div style={{ paddingTop: 10, paddingBottom: 16 }}>
          <div style={{ display: "flex", flexWrap: "wrap" as const, gap: 8, marginBottom: 10 }}>
            {quickCmds.map((cmd, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 12px", borderRadius: 20, background: "rgba(255,255,255,.06)", border: "1px solid rgba(255,255,255,.10)" }}>
                <span style={{ fontSize: 12.5, color: FG2 }}>{cmd}</span>
                <button onClick={() => setQuickCmds(cs => cs.filter((_,j) => j!==i))} style={{ cursor: "pointer", background: "none", border: "none", padding: 0, display: "flex", lineHeight: 1 }}>
                  <X size={11} color={FG3} />
                </button>
              </div>
            ))}
            <button style={{ display: "flex", alignItems: "center", gap: 5, padding: "6px 12px", borderRadius: 20, border: "1px dashed rgba(255,255,255,.22)", background: "transparent", color: FG3, fontSize: 12.5, cursor: "pointer", fontFamily: "'Inter','Noto Sans SC',sans-serif" }}>
              <Plus size={11} />添加
            </button>
          </div>
          <div style={{ fontSize: 11, color: FG3 }}>最多8条 · 可拖拽排序 · 长按编辑</div>
        </div>
      </SettingGroup>
    </div>
  );

  const renderLocation = () => (
    <div>
      <SectionHdr icon="📍" title="当前位置" sub="位置权限与精度设置" />
      <SettingGroup title="权限">
        <SettingRow label="启用位置服务" sub="关闭后导航、充电站等功能将不可用">
          <Toggle on={locOn} onChange={setLocOn} />
        </SettingRow>
        <SettingRow label="精确定位" sub="使用GPS精确坐标，比网络定位更准">
          <Toggle on={preciseOn} onChange={setPreciseOn} disabled={!locOn} />
        </SettingRow>
        <SettingRow label="后台定位" sub="关闭后行程记录与主动播报将受限" noBorder>
          <Toggle on={bgLocOn} onChange={setBgLocOn} disabled={!locOn} />
        </SettingRow>
      </SettingGroup>
      <HR />
      <SettingGroup title="当前位置">
        <div style={{ paddingTop: 10, paddingBottom: 16 }}>
          {locOn ? (
            <div style={{ padding: "14px 16px", borderRadius: 14, background: "rgba(255,255,255,.04)", border: "1px solid rgba(255,255,255,.08)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#34D399", boxShadow: "0 0 6px #34D399" }} />
                <span style={{ fontSize: 12.5, fontWeight: 600, color: "#34D399" }}>定位已开启</span>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                {[["纬度", "30.2741° N"], ["经度", "120.1551° E"], ["精度", "±5m (GPS)"], ["更新", "2s前"]].map(([l, v]) => (
                  <div key={l}>
                    <div style={{ fontSize: 10.5, color: FG3 }}>{l}</div>
                    <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12.5, color: FG1, marginTop: 2 }}>{v}</div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "12px 0" }}>
              <div style={{ width: 8, height: 8, borderRadius: "50%", background: FG3 }} />
              <span style={{ fontSize: 13, color: FG3 }}>位置服务已关闭</span>
            </div>
          )}
          <div style={{ fontSize: 11, color: FG3, marginTop: 12, lineHeight: 1.6 }}>位置信息仅用于导航、就近搜索与行驶记录，不上传至服务器。</div>
        </div>
      </SettingGroup>
    </div>
  );

  const renderPlaces = () => {
    const placeItems = [
      { key: "home",   icon: "🏠", label: "家",  placeholder: "添加家的地址" },
      { key: "work",   icon: "🏢", label: "公司", placeholder: "添加公司地址" },
      { key: "school", icon: "🎓", label: "学校", placeholder: "添加学校地址" },
    ];
    return (
      <div>
        <SectionHdr icon="🏠" title="常用地点" sub={'快速导航到常用地点，支持语音"导航回家"'} />
        <SettingGroup title="地点设置">
          {placeItems.map(({ key, icon, label, placeholder }, i) => {
            const addr = places[key];
            return (
              <div key={key} style={{ padding: "16px 0", borderBottom: i < 2 ? `1px solid ${DIV}` : "none" }}>
                <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: addr ? "rgba(70,214,224,.12)" : "rgba(255,255,255,.06)", border: `1px solid ${addr ? "rgba(70,214,224,.25)" : "rgba(255,255,255,.10)"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>{icon}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13.5, fontWeight: 600, color: FG1, marginBottom: 4 }}>{label}</div>
                    {addr ? (
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div style={{ fontSize: 12.5, color: FG2, flex: 1 }}>{addr}</div>
                        <GhostBtn sm onClick={() => setPlaces(p => ({...p, [key]: ""}))}>
                          <Pencil size={11} />编辑
                        </GhostBtn>
                      </div>
                    ) : (
                      <button style={{ fontSize: 12.5, color: TEAL, background: "none", border: "none", cursor: "pointer", padding: 0, fontFamily: "'Inter','Noto Sans SC',sans-serif" }}>
                        ＋ {placeholder}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </SettingGroup>
      </div>
    );
  };

  const renderAssistant = () => (
    <div>
      <SectionHdr icon="🤖" title="助手设置" sub="个性化小舟的回答风格与底层模型" />
      <SettingGroup title="个性化">
        <SettingRow label="助手昵称" sub="你对助手的称呼，也是唤醒词前缀">
          <TextInput value={nickname} onChange={setNickname} width={180} />
        </SettingRow>
        <SettingRow label="回答长度" sub="简短适合行车；详细适合泊车深度调研">
          <Segment options={["简短", "标准", "详细"]} value={respLen} onChange={setRespLen} />
        </SettingRow>
        <SettingRow label="对话模型" sub="快速 = 低延迟；深度推理 = 复杂任务更准" noBorder>
          <Segment options={["快速", "深度推理", "自动"]} value={modelChoice} onChange={setModelChoice} sm />
        </SettingRow>
      </SettingGroup>
      <HR />
      <SettingGroup title="模型说明">
        <div style={{ paddingTop: 8, paddingBottom: 16, display: "flex", flexDirection: "column" as const, gap: 8 }}>
          {[
            { name: "快速", desc: "低延迟，适合导航/天气/音乐等实时任务", latency: "<0.5s" },
            { name: "深度推理", desc: "复杂推理，适合行程规划、调研报告", latency: "1-3s" },
            { name: "自动", desc: "根据任务复杂度智能切换，推荐日常使用", latency: "智能" },
          ].map(m => (
            <div key={m.name} style={{ display: "flex", gap: 12, padding: "10px 14px", borderRadius: 12, background: modelChoice === m.name ? "rgba(70,214,224,.07)" : "rgba(255,255,255,.03)", border: `1px solid ${modelChoice === m.name ? "rgba(70,214,224,.20)" : "rgba(255,255,255,.06)"}` }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: modelChoice === m.name ? TEAL : FG2, marginBottom: 2 }}>{m.name}</div>
                <div style={{ fontSize: 11.5, color: FG3 }}>{m.desc}</div>
              </div>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: FG3, flexShrink: 0, marginTop: 2 }}>{m.latency}</span>
            </div>
          ))}
        </div>
      </SettingGroup>
    </div>
  );

  const renderCaps = () => (
    <div>
      <SectionHdr icon="⚡" title="能力开关" sub="控制各 Agent 的启用状态。核心能力不可关闭。" />
      <SettingGroup title="Agent 列表">
        <div style={{ paddingBottom: 8 }}>
          {CAPS_DATA.map((cap, i) => (
            <div key={cap.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 0", borderBottom: i < CAPS_DATA.length - 1 ? `1px solid ${DIV}` : "none" }}>
              {/* Icon badge */}
              <div style={{ width: 36, height: 36, borderRadius: 10, background: caps[cap.id] ? "rgba(70,214,224,.10)" : "rgba(255,255,255,.05)", border: `1px solid ${caps[cap.id] ? "rgba(70,214,224,.22)" : "rgba(255,255,255,.09)"}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0, transition: "all .2s" }}>{cap.icon}</div>
              {/* Name */}
              <span style={{ flex: 1, fontSize: 14, fontWeight: 500, color: caps[cap.id] ? FG1 : FG3, transition: "color .2s" }}>{cap.name}</span>
              {/* Core badge */}
              {cap.core && (
                <span style={{ padding: "2px 8px", borderRadius: 6, background: "rgba(70,214,224,.10)", border: "1px solid rgba(70,214,224,.22)", fontSize: 10, fontWeight: 700, color: TEAL, flexShrink: 0 }}>核心</span>
              )}
              {/* Toggle */}
              <Toggle on={caps[cap.id]} onChange={v => !cap.core && setCaps(c => ({...c, [cap.id]: v}))} disabled={cap.core} />
            </div>
          ))}
        </div>
      </SettingGroup>
    </div>
  );

  const renderMemory = () => {
    const cats = ["偏好", "常去地点", "经历"];
    return (
      <div>
        <SectionHdr icon="💭" title="记忆" sub="小舟从对话中学到的你的偏好与经历" />
        <SettingGroup title="记忆开关">
          <SettingRow label="启用记忆" sub="关闭后新对话不再积累画像，已有记忆保留" noBorder>
            <Toggle on={memOn} onChange={setMemOn} />
          </SettingRow>
        </SettingGroup>
        <HR />
        <SettingGroup title="近期对话">
          <div style={{ paddingBottom: 8 }}>
            {SESSIONS_DATA.map((s, i) => (
              <div key={s.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 0", borderBottom: i < SESSIONS_DATA.length-1 ? `1px solid ${DIV}` : "none" }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 500, color: FG1, marginBottom: 3 }}>{s.title}</div>
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    <span style={{ fontSize: 11, color: FG3 }}>{s.date}</span>
                    <span style={{ fontSize: 11, color: FG3 }}>·</span>
                    <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: FG3 }}>{s.msgs}条消息</span>
                  </div>
                </div>
                <GhostBtn sm><X size={10} /> 删除</GhostBtn>
              </div>
            ))}
          </div>
        </SettingGroup>
        <HR />
        <SettingGroup title="学到的画像">
          <div style={{ paddingBottom: 16 }}>
            {cats.map(cat => {
              const items = memories.filter(m => m.cat === cat);
              if (!items.length) return null;
              return (
                <div key={cat} style={{ marginTop: 12 }}>
                  <div style={{ fontSize: 11, color: FG3, letterSpacing: ".06em", marginBottom: 7 }}>{cat}</div>
                  {items.map(m => (
                    <div key={m.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", borderRadius: 10, background: "rgba(255,255,255,.04)", border: "1px solid rgba(255,255,255,.07)", marginBottom: 6 }}>
                      <span style={{ flex: 1, fontSize: 13, color: FG2, lineHeight: 1.5 }}>{m.text}</span>
                      <button onClick={() => setMemories(ms => ms.filter(x => x.id !== m.id))} style={{ background: "none", border: "none", cursor: "pointer", padding: "2px", display: "flex", flexShrink: 0 }}>
                        <X size={12} color={FG3} />
                      </button>
                    </div>
                  ))}
                </div>
              );
            })}
            {memories.length === 0 && (
              <div style={{ padding: "16px 0", textAlign: "center" as const, color: FG3, fontSize: 13 }}>暂无已学习的记忆</div>
            )}
            <div style={{ marginTop: 16, display: "flex", gap: 10 }}>
              <GhostBtn onClick={() => setMemories(MEM_INITIAL)}>恢复示例</GhostBtn>
            </div>
          </div>
        </SettingGroup>
        <HR />
        <div style={{ padding: "14px 28px" }}>
          <DangerBtn onClick={() => setMemories([])}>清除所有记忆数据</DangerBtn>
        </div>
      </div>
    );
  };

  const renderSection = (): ReactNode => {
    switch (active) {
      case "voice-out":  return renderVoiceOut();
      case "voice-in":   return renderVoiceIn();
      case "display":    return renderDisplay();
      case "location":   return renderLocation();
      case "places":     return renderPlaces();
      case "assistant":  return renderAssistant();
      case "caps":       return renderCaps();
      case "memory":     return renderMemory();
    }
  };

  // ─── RENDER ────────────────────────────────────────────────────────────────
  return (
    <div style={{ height: "100vh", overflow: "hidden", fontFamily: "'Inter','Noto Sans SC',-apple-system,sans-serif", color: FG1, background: "linear-gradient(155deg,#06080F 0%,#0A0E1A 52%,#080D18 100%)" }}>
      <style>{KEYFRAMES}</style>

      {/* Atmosphere */}
      <div aria-hidden style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
        <div style={{ position: "absolute", bottom: "10%", left: "18%", width: 560, height: 400, background: "radial-gradient(circle,rgba(91,140,255,.10) 0%,transparent 68%)", filter: "blur(52px)" }} />
        <div style={{ position: "absolute", top: "8%",  right: "8%",  width: 480, height: 360, background: "radial-gradient(circle,rgba(91,233,255,.07) 0%,transparent 68%)", filter: "blur(58px)" }} />
      </div>

      {/* Header */}
      <header style={{ position: "relative", zIndex: 30, height: 56, padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(6,8,15,.80)", backdropFilter: "blur(28px)", WebkitBackdropFilter: "blur(28px)", borderBottom: `1px solid ${DIV}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 26, height: 26 }}><AuroraOrb state="idle" size={26} /></div>
          <span style={{ ...AURORA_TEXT, fontSize: 14, fontWeight: 600 }}>Aurora Glass</span>
          <span style={{ fontSize: 13, color: FG3, fontWeight: 300 }}>· A-7 设置面板 · 横屏侧栏式</span>
        </div>
        <div style={{ fontSize: 11, color: FG3 }}>点击左侧导航切换分区 · 所有控件可交互</div>
      </header>

      {/* Main: sidebar + content */}
      <div style={{ position: "relative", zIndex: 1, display: "flex", height: "calc(100vh - 56px)", padding: "16px 24px 16px", gap: 16, overflow: "hidden" }}>

        {/* Left nav */}
        <div style={{ width: 236, flexShrink: 0, height: "100%", display: "flex", flexDirection: "column" }}>
          <GlassCard r={20} style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
            {/* Orb + title */}
            <div style={{ padding: "20px 16px 14px", display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 40, height: 40 }}><AuroraOrb state="idle" size={40} /></div>
              <div>
                <div style={{ fontSize: 15, fontWeight: 600 }}>小舟</div>
                <div style={{ fontSize: 11, color: FG3 }}>助手设置</div>
              </div>
            </div>
            <HR />

            {/* Nav items */}
            <div style={{ flex: 1, overflowY: "auto", padding: "8px 10px" }}>
              {NAV_ITEMS.map(item => (
                <NavItem key={item.id} icon={item.icon} label={item.label} active={active === item.id} onClick={() => setActive(item.id)} />
              ))}
            </div>
            <HR />

            {/* Bottom: danger */}
            <div style={{ padding: "10px 10px 12px" }}>
              <DangerBtn>清除所有数据</DangerBtn>
            </div>
          </GlassCard>
        </div>

        {/* Right content */}
        <div style={{ flex: 1, height: "100%", overflowY: "auto" }}>
          <GlassCard r={20} style={{ minHeight: "100%" }}>
            {renderSection()}
          </GlassCard>
        </div>
      </div>
    </div>
  );
}
