// Design contract: guidelines/Guidelines.md
// Page: A-5 卡片族 3 · 出行 / 行程 / 赛事（右舞台地图联动）
// Reused: AuroraOrb, GlassCard, AURORA*, TEAL, FG1/2/3, DIV, KEYFRAMES, AIBadge, ConfBadge
// New: MapStage, POICard, RouteCard, ChargingRouteCard, ItineraryCard, SportsCard + empties

import { useState, CSSProperties, ReactNode } from "react";
import { MapPin, Navigation, Zap, Clock, Star, ChevronRight, Mic, Trophy, Calendar, ArrowRight } from "lucide-react";

// ─── Design Tokens (§3 Guidelines.md) ────────────────────────────────────────
const AURORA       = "linear-gradient(135deg,#5BE9FF 0%,#5B8CFF 33%,#9A6BFF 66%,#FF6BD6 100%)";
const AURORA_CONIC = "conic-gradient(from 0deg,#5BE9FF,#5B8CFF,#9A6BFF,#FF6BD6,#5BE9FF)";
const AURORA_TEXT: CSSProperties = {
  background: AURORA, WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent", backgroundClip: "text",
};
const TEAL = "#46D6E0";
const FG1  = "rgba(255,255,255,0.92)";
const FG2  = "rgba(255,255,255,0.56)";
const FG3  = "rgba(255,255,255,0.32)";
const DIV  = "rgba(255,255,255,0.07)";

// ─── Keyframes (§8, §10) ─────────────────────────────────────────────────────
const KEYFRAMES = `
  @keyframes aurora-breathe {
    0%,100%{opacity:.82;transform:scale(1)} 50%{opacity:1;transform:scale(1.038)}
  }
  @keyframes aurora-breathe-fast {
    0%,100%{opacity:.85;transform:scale(1)} 50%{opacity:1;transform:scale(1.045)}
  }
  @keyframes aurora-spin {
    from{transform:rotate(0deg)} to{transform:rotate(360deg)}
  }
  @keyframes aurora-spin-r {
    from{transform:rotate(360deg)} to{transform:rotate(0deg)}
  }
  @keyframes aurora-pulse {
    0%,100%{transform:scale(1);opacity:.86}
    25%{transform:scale(1.07);opacity:1}
    75%{transform:scale(0.96);opacity:.80}
  }
  @keyframes route-dash {
    from{stroke-dashoffset:300} to{stroke-dashoffset:0}
  }
  @keyframes dot-pulse {
    0%,100%{r:5;opacity:.8} 50%{r:7;opacity:1}
  }
  @keyframes map-glow {
    0%,100%{opacity:.55} 50%{opacity:.90}
  }
  * { scrollbar-width: thin; scrollbar-color: rgba(91,140,255,.22) transparent }
  @media(prefers-reduced-motion:reduce){*{animation-duration:.01ms!important}}
`;

// ─── AuroraOrb (reused §9, §10) ──────────────────────────────────────────────
type OrbState = "idle" | "thinking" | "speaking";
function AuroraOrb({ state = "idle", size = 40 }: { state?: OrbState; size?: number }) {
  const thinking = state === "thinking", speaking = state === "speaking";
  const glowMult = speaking ? 1.35 : 1;
  const outerAnim = thinking ? "aurora-breathe-fast 1.4s ease-in-out infinite"
                  : speaking  ? "aurora-pulse 0.72s ease-in-out infinite"
                  :             "aurora-breathe 4s ease-in-out infinite";
  const haloSpeed = thinking ? "1.6s" : "8s", innerSpeed = thinking ? "1.1s" : "5s", ctSpeed = thinking ? "0.8s" : "3.8s";
  const s = size;
  return (
    <div style={{ position: "relative", width: s, height: s, flexShrink: 0 }}>
      <div style={{ position: "absolute", inset: -s*.52, borderRadius: "50%", background: `radial-gradient(circle,rgba(91,140,255,${.20*glowMult}) 0%,rgba(154,107,255,${.11*glowMult}) 40%,transparent 70%)`, animation: outerAnim, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: -s*.06, borderRadius: "50%", background: AURORA_CONIC, opacity: thinking?.52:.26, filter: `blur(${s*.115}px)`, animation: `aurora-spin ${haloSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: 0, borderRadius: "50%", background: `radial-gradient(circle at 36% 28%,rgba(255,255,255,.44) 0%,rgba(91,233,255,.22) 28%,rgba(91,140,255,.18) 56%,rgba(154,107,255,.26) 78%,rgba(255,107,214,.14) 100%)`, backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)", border: "1px solid rgba(255,255,255,.24)", boxShadow: `0 0 ${s*.32*glowMult}px rgba(91,142,255,.52),0 0 ${s*.70*glowMult}px rgba(154,107,255,.22),inset 0 0 ${s*.24}px rgba(91,233,255,.20),inset 0 ${s*.012}px 0 rgba(255,255,255,.34)`, animation: outerAnim, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: s*.16, borderRadius: "50%", background: AURORA_CONIC, opacity: .70, filter: `blur(${s*.036}px)`, animation: `aurora-spin ${innerSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: s*.28, borderRadius: "50%", background: `conic-gradient(from 180deg,#9A6BFF,#5B8CFF,#5BE9FF,#FF6BD6,#9A6BFF)`, opacity: .54, filter: `blur(${s*.028}px)`, animation: `aurora-spin-r ${ctSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", top: "9%", left: "13%", width: "44%", height: "33%", borderRadius: "50%", background: "radial-gradient(ellipse,rgba(255,255,255,.70) 0%,transparent 100%)", filter: "blur(2px)", pointerEvents: "none" }} />
    </div>
  );
}

// ─── GlassCard (reused §6) ────────────────────────────────────────────────────
function GlassCard({ children, p = 0, r = 22, active = false, onClick, style }: {
  children?: ReactNode; p?: number; r?: number; active?: boolean; onClick?: () => void; style?: CSSProperties;
}) {
  return (
    <div onClick={onClick} style={{
      padding: p, borderRadius: r, overflow: "hidden",
      background: "rgba(255,255,255,.056)",
      backdropFilter: "blur(32px)", WebkitBackdropFilter: "blur(32px)",
      border: active ? `1px solid rgba(70,214,224,.38)` : "1px solid rgba(255,255,255,.10)",
      borderTop: active ? `1px solid rgba(70,214,224,.5)` : "1px solid rgba(255,255,255,.17)",
      borderLeft: active ? `1px solid rgba(70,214,224,.44)` : "1px solid rgba(255,255,255,.13)",
      boxShadow: active
        ? "0 8px 40px rgba(0,0,0,.50),0 2px 12px rgba(0,0,0,.28),0 0 20px rgba(70,214,224,.10),inset 0 1px 0 rgba(255,255,255,.13)"
        : "0 8px 40px rgba(0,0,0,.50),0 2px 12px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.13)",
      cursor: onClick ? "pointer" : "default",
      transition: "border-color .2s ease, box-shadow .2s ease",
      ...style,
    }}>{children}</div>
  );
}

const HR = () => <div style={{ height: 1, background: DIV }} />;

// AIBadge — §5 角标形式，无彩色背景
function AIBadge({ label }: { label: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10 }}>
      <div style={{ width: 13, height: 13, borderRadius: 4, background: AURORA, flexShrink: 0 }} />
      <span style={{ ...AURORA_TEXT, fontSize: 10, fontWeight: 700, letterSpacing: ".09em" }}>{label}</span>
    </div>
  );
}

// ─── A-5 Data ─────────────────────────────────────────────────────────────────

const POIS = [
  { n: 1, name: "特来电·西湖文化广场站", rating: 4.6, dist: "1.2km", addr: "西湖区文化广场B3层",     fast: true,  slots: "6/8空闲" },
  { n: 2, name: "星星充电·黄龙站",       rating: 4.5, dist: "1.8km", addr: "黄龙路88号地下停车场",   fast: true,  slots: "2/6空闲" },
  { n: 3, name: "特来电·湖滨店",         rating: 4.3, dist: "2.4km", addr: "湖滨路55号停车场P2层",   fast: false, slots: "4/4空闲" },
  { n: 4, name: "国家电网·钱江新城",     rating: 4.7, dist: "3.1km", addr: "钱江路145号地下停车室",   fast: true,  slots: "10/12空闲" },
];

const ROUTE_WPS = [
  { type: "origin",   icon: "📍", label: "当前位置",        sub: "杭州市西湖区灵隐路" },
  { type: "via",      icon: "🍴", label: "知味观·河坊街",   sub: "餐厅 · 清泰街167号", dur: "12分钟", dist: "5.2km" },
  { type: "dest",     icon: "🏁", label: "西湖景区·断桥",   sub: "景区 · 环湖北路",    dur: "16分钟", dist: "7.1km" },
];

const CHARGE_ROUTE = {
  origin: "杭州市区", dest: "都江堰", soc: 62,
  totalDist: 258, totalTime: "约3小时35分",
  stops: [{ name: "青城山服务区", atKm: 210, addSoc: "+30%", time: "约20分钟", power: "120kW快充" }],
};

const ITINERARY = {
  dest: "成都", days: 3,
  plan: [
    {
      day: 1, theme: "大熊猫 · 市区精华", color: "#F59E0B",
      stops: [
        { icon: "🐼", name: "成都大熊猫繁育研究基地", addr: "成华区熊猫大道1375号", nav: true  },
        { icon: "🍜", name: "陈麻婆豆腐（总店）",    addr: "青羊区西玉龙街197号",  nav: true  },
        { icon: "🏛", name: "宽窄巷子",              addr: "青羊区长顺上街251号",  nav: true  },
        { icon: "🏨", name: "成都瑞吉酒店",          addr: "锦江区大慈寺路88号",   nav: false },
        { icon: "⚡", name: "特来电·九方购物中心",   addr: "九方购物中心地下P3层", nav: false },
      ],
    },
    {
      day: 2, theme: "都江堰 · 青城山", color: "#10B981", charge: "途中补电 1 次 · 约20分钟",
      stops: [
        { icon: "🏛", name: "都江堰景区",   addr: "都江堰市都江堰景区路",  nav: true  },
        { icon: "🏔", name: "青城山前山",   addr: "都江堰市青城山镇",      nav: true  },
        { icon: "🍜", name: "青城道家素食", addr: "青城山景区内",          nav: false },
        { icon: "🏨", name: "都江堰精华酒店", addr: "都江堰市幸福路",      nav: false },
      ],
    },
    {
      day: 3, theme: "锦里 · IFS · 返程", color: "#3B82F6",
      stops: [
        { icon: "🏛", name: "锦里古街",              addr: "武侯区武侯祠大街231号", nav: true  },
        { icon: "🛍", name: "成都IFS国际金融中心",   addr: "锦江区红星路三段1号",   nav: true  },
        { icon: "🍜", name: "大龙燚火锅",            addr: "锦江区东糠市街45号",    nav: true  },
      ],
    },
  ],
};

const MATCH = {
  league: "英超 Premier League", date: "2024-12-22 周日 16:30", status: "已完赛",
  home: { name: "曼彻斯特城", short: "曼城", score: 2, color: "#6CABDD", abbr: "MCI" },
  away: { name: "阿森纳",     short: "阿森纳", score: 1, color: "#EF0107", abbr: "ARS" },
  goals: [
    { min: 23, side: "home", player: "哈兰德 G.Haaland" },
    { min: 67, side: "home", player: "福登 P.Foden"    },
    { min: 78, side: "away", player: "马丁内利 G.Martinelli" },
  ],
  scorers: [
    { name: "哈兰德",   team: "曼城",   goals: 18 },
    { name: "萨拉赫",   team: "利物浦", goals: 15 },
    { name: "沃特金斯", team: "阿斯顿", goals: 14 },
    { name: "福登",     team: "曼城",   goals: 12 },
  ],
};

// ─── MapStage — right context stage with linked visualization ─────────────────
type CardType = "poi" | "route" | "charge" | "itinerary" | "sports";

// Road network data (static)
const ROADS_H = [18, 32, 44, 56, 67, 78, 88];
const ROADS_V = [15, 28, 42, 55, 68, 80, 91];

function MapStage({ type }: { type: CardType }) {
  const W = 600, H = 480;

  // POI map coords (relative to 0-100 scale)
  const poiDots = [
    { x: 50, y: 50, n: 0, label: "当前位置", current: true },
    { x: 38, y: 40, n: 1, label: "特来电·西湖文广", dist: "1.2km" },
    { x: 60, y: 36, n: 2, label: "星星充电·黄龙",   dist: "1.8km" },
    { x: 32, y: 58, n: 3, label: "特来电·湖滨",     dist: "2.4km" },
    { x: 65, y: 62, n: 4, label: "国家电网·钱江",   dist: "3.1km" },
  ];

  // Route path points
  const routePts = [
    { x: 25, y: 70, label: "当前位置" },
    { x: 48, y: 52, label: "知味观·河坊街" },
    { x: 68, y: 30, label: "西湖景区·断桥" },
  ];

  // Charge route (left-to-right long distance)
  const chargePts = [
    { x: 8,  y: 55, label: "杭州" },
    { x: 72, y: 48, label: "青城山服务区", charge: true },
    { x: 92, y: 42, label: "都江堰" },
  ];

  // Itinerary cities
  const cityDots = [
    { x: 20, y: 35, label: "杭州（出发）", day: 0  },
    { x: 48, y: 60, label: "成都",         day: 1  },
    { x: 35, y: 45, label: "都江堰",       day: 2  },
    { x: 52, y: 55, label: "成都（返）",   day: 3  },
  ];

  const toX = (p: number) => (p / 100) * W;
  const toY = (p: number) => (p / 100) * H;

  const roadOpacity = 0.055;

  return (
    <div style={{
      borderRadius: 24, overflow: "hidden", position: "relative",
      background: "linear-gradient(158deg,#06080F 0%,#0B1020 60%,#080D18 100%)",
      border: "1px solid rgba(255,255,255,.06)",
      boxShadow: "0 8px 40px rgba(0,0,0,.60)",
    }}>
      {/* Aurora atmosphere blobs */}
      <div style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
        <div style={{ position: "absolute", top: "10%", left: "20%",  width: 240, height: 200, background: "radial-gradient(circle,rgba(91,140,255,.15) 0%,transparent 70%)", filter: "blur(40px)" }} />
        <div style={{ position: "absolute", bottom: "15%", right: "15%", width: 200, height: 160, background: "radial-gradient(circle,rgba(91,233,255,.10) 0%,transparent 70%)", filter: "blur(48px)" }} />
        {type === "sports" && <div style={{ position: "absolute", top: "20%", right: "20%", width: 300, height: 200, background: "radial-gradient(circle,rgba(154,107,255,.12) 0%,transparent 70%)", filter: "blur(52px)" }} />}
      </div>

      <svg width={W} height={H} style={{ display: "block", position: "relative" }}>
        {/* Road network grid */}
        {ROADS_H.map((y, i) => <line key={`h${i}`} x1={0} y1={toY(y)} x2={W} y2={toY(y)} stroke={`rgba(91,140,255,${roadOpacity})`} strokeWidth={1} />)}
        {ROADS_V.map((x, i) => <line key={`v${i}`} x1={toX(x)} y1={0} x2={toX(x)} y2={H} stroke={`rgba(91,140,255,${roadOpacity})`} strokeWidth={1} />)}
        {/* Diagonal connectors */}
        <line x1={toX(15)} y1={toY(18)} x2={toX(42)} y2={toY(44)} stroke={`rgba(91,140,255,${roadOpacity})`} strokeWidth={1} />
        <line x1={toX(55)} y1={toY(32)} x2={toX(80)} y2={toY(56)} stroke={`rgba(91,140,255,${roadOpacity})`} strokeWidth={1} />
        <line x1={toX(28)} y1={toY(67)} x2={toX(55)} y2={toY(88)} stroke={`rgba(91,140,255,${roadOpacity})`} strokeWidth={1} />
        <line x1={toX(68)} y1={toY(18)} x2={toX(91)} y2={toY(44)} stroke={`rgba(91,140,255,${roadOpacity})`} strokeWidth={1} />

        {/* ── POI view ── */}
        {type === "poi" && (
          <g>
            {/* Range rings from current location */}
            {[60, 90, 120].map((r, i) => (
              <circle key={i} cx={toX(50)} cy={toY(50)} r={r} fill="none"
                stroke={`rgba(70,214,224,${0.06 - i*0.015})`} strokeWidth={1} strokeDasharray="4,8" />
            ))}
            {/* POI dots */}
            {poiDots.map((d, i) => (
              <g key={i}>
                {d.current ? (
                  <>
                    <circle cx={toX(d.x)} cy={toY(d.y)} r={10} fill="rgba(70,214,224,.15)" stroke={TEAL} strokeWidth={1.5} />
                    <circle cx={toX(d.x)} cy={toY(d.y)} r={5}  fill={TEAL} />
                    <text x={toX(d.x)} y={toY(d.y)-14} fontSize={10} fill={TEAL} textAnchor="middle" fontFamily="'Inter',sans-serif">当前位置</text>
                  </>
                ) : (
                  <>
                    <circle cx={toX(d.x)} cy={toY(d.y)} r={14} fill="rgba(70,214,224,.08)" stroke="rgba(70,214,224,.25)" strokeWidth={1} style={{ animation: "map-glow 3s ease-in-out infinite" }} />
                    <circle cx={toX(d.x)} cy={toY(d.y)} r={7}  fill={TEAL} />
                    <text x={toX(d.x)} y={toY(d.y) - 18} fontSize={9} fill={TEAL} textAnchor="middle" fontFamily="'JetBrains Mono',monospace" fontWeight={700}>{d.n}</text>
                    <text x={toX(d.x)} y={toY(d.y) + 20} fontSize={9} fill="rgba(255,255,255,.50)" textAnchor="middle" fontFamily="'Inter',sans-serif">{d.dist}</text>
                    {/* Connector line */}
                    <line x1={toX(50)} y1={toY(50)} x2={toX(d.x)} y2={toY(d.y)} stroke="rgba(70,214,224,.12)" strokeWidth={1} strokeDasharray="3,5" />
                  </>
                )}
              </g>
            ))}
          </g>
        )}

        {/* ── Route view ── */}
        {(type === "route") && (
          <g>
            <polyline
              points={routePts.map(p => `${toX(p.x)},${toY(p.y)}`).join(" ")}
              fill="none" stroke={TEAL} strokeWidth={3} strokeLinecap="round"
              strokeDasharray="12,6" style={{ animation: "route-dash 2s linear infinite" }}
            />
            {routePts.map((p, i) => (
              <g key={i}>
                <circle cx={toX(p.x)} cy={toY(p.y)} r={i === routePts.length-1 ? 10 : 7}
                  fill={i === routePts.length-1 ? TEAL : i === 0 ? "#46D6E0" : "#F59E0B"}
                  stroke="rgba(6,8,15,.8)" strokeWidth={2} />
                <text x={toX(p.x)} y={toY(p.y)-14} fontSize={9} fill="rgba(255,255,255,.65)" textAnchor="middle" fontFamily="'Inter','Noto Sans SC',sans-serif">{p.label}</text>
              </g>
            ))}
          </g>
        )}

        {/* ── Charging route view ── */}
        {type === "charge" && (
          <g>
            <polyline
              points={chargePts.map(p => `${toX(p.x)},${toY(p.y)}`).join(" ")}
              fill="none" stroke={TEAL} strokeWidth={2.5} strokeLinecap="round"
              strokeDasharray="10,5" style={{ animation: "route-dash 3s linear infinite" }}
            />
            {chargePts.map((p, i) => (
              <g key={i}>
                {p.charge ? (
                  <>
                    <circle cx={toX(p.x)} cy={toY(p.y)} r={14} fill="rgba(245,158,11,.15)" stroke="#F59E0B" strokeWidth={1.5} />
                    <text cx={toX(p.x)} y={toY(p.y)+4} fontSize={12} fill="#F59E0B" textAnchor="middle" fontFamily="'Inter',sans-serif" x={toX(p.x)}>⚡</text>
                    <text x={toX(p.x)} y={toY(p.y)-20} fontSize={9} fill="#F59E0B" textAnchor="middle" fontFamily="'Inter','Noto Sans SC',sans-serif">补电站</text>
                  </>
                ) : (
                  <>
                    <circle cx={toX(p.x)} cy={toY(p.y)} r={8} fill={i === 0 ? TEAL : "#34D399"} stroke="rgba(6,8,15,.8)" strokeWidth={2} />
                    <text x={toX(p.x)} y={toY(p.y)-(i===0?14:14)} fontSize={9} fill="rgba(255,255,255,.65)" textAnchor="middle" fontFamily="'Inter','Noto Sans SC',sans-serif">{p.label}</text>
                  </>
                )}
              </g>
            ))}
            {/* SoC bar overlay */}
            <rect x={20} y={H-50} width={180} height={16} rx={8} fill="rgba(255,255,255,.06)" stroke="rgba(255,255,255,.10)" strokeWidth={1} />
            <rect x={22} y={H-48} width={180*.62-4} height={12} rx={6} fill={TEAL} opacity={.8} />
            <text x={210} y={H-38} fontSize={9} fill={TEAL} fontFamily="'JetBrains Mono',monospace">62% SoC</text>
          </g>
        )}

        {/* ── Itinerary view ── */}
        {type === "itinerary" && (
          <g>
            {cityDots.map((d, i) => (
              <g key={i}>
                {i > 0 && (
                  <line x1={toX(cityDots[i-1].x)} y1={toY(cityDots[i-1].y)}
                        x2={toX(d.x)} y2={toY(d.y)}
                        stroke="rgba(70,214,224,.25)" strokeWidth={1.5} strokeDasharray="6,4" />
                )}
                <circle cx={toX(d.x)} cy={toY(d.y)} r={12} fill={`rgba(${[245,158,11,16,59,130,16,185,129][i*3]},${[245,158,11,16,59,130,16,185,129][i*3+1]},${[245,158,11,16,59,130,16,185,129][i*3+2]},.2)`} stroke="rgba(255,255,255,.3)" strokeWidth={1.5} />
                <text x={toX(d.x)} y={toY(d.y)+4} fontSize={9} fill="rgba(255,255,255,.85)" textAnchor="middle" fontFamily="'JetBrains Mono',monospace" fontWeight={700}>{`D${d.day||"出"}`}</text>
                <text x={toX(d.x)} y={toY(d.y)-18} fontSize={9} fill="rgba(255,255,255,.55)" textAnchor="middle" fontFamily="'Inter','Noto Sans SC',sans-serif">{d.label}</text>
              </g>
            ))}
          </g>
        )}

        {/* ── Sports view ── */}
        {type === "sports" && (
          <g>
            {/* Stadium shape */}
            <ellipse cx={W/2} cy={H/2} rx={160} ry={100} fill="rgba(16,185,129,.07)" stroke="rgba(16,185,129,.20)" strokeWidth={1.5} />
            <ellipse cx={W/2} cy={H/2} rx={100} ry={64}  fill="rgba(16,185,129,.05)" stroke="rgba(16,185,129,.12)" strokeWidth={1} />
            {/* Center circle */}
            <circle cx={W/2} cy={H/2} r={30} fill="none" stroke="rgba(16,185,129,.15)" strokeWidth={1} />
            <line x1={W/2} y1={H/2-100} x2={W/2} y2={H/2+100} stroke="rgba(16,185,129,.10)" strokeWidth={1} />
            {/* Score overlay */}
            <text x={W/2-60} y={H/2-10} fontSize={28} fill="#6CABDD" textAnchor="middle" fontFamily="'JetBrains Mono',monospace" fontWeight={700}>2</text>
            <text x={W/2} y={H/2-10} fontSize={16} fill="rgba(255,255,255,.40)" textAnchor="middle" fontFamily="'JetBrains Mono',monospace">:</text>
            <text x={W/2+60} y={H/2-10} fontSize={28} fill="#EF0107" textAnchor="middle" fontFamily="'JetBrains Mono',monospace" fontWeight={700}>1</text>
            <text x={W/2} y={H/2+20} fontSize={9} fill="rgba(255,255,255,.35)" textAnchor="middle" fontFamily="'Inter',sans-serif">曼城 · 阿森纳 · 英超</text>
          </g>
        )}
      </svg>

      {/* Map type label */}
      <div style={{ position: "absolute", top: 16, left: 16, display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{ padding: "4px 12px", borderRadius: 20, background: "rgba(70,214,224,.10)", border: "1px solid rgba(70,214,224,.22)" }}>
          <span style={{ fontSize: 11, color: TEAL, fontWeight: 500 }}>
            {{ poi: "附近充电站", route: "行驶路线", charge: "充电路线", itinerary: "行程地图", sports: "赛事信息" }[type]}
          </span>
        </div>
      </div>

      {/* Bottom city label */}
      <div style={{ position: "absolute", bottom: 16, right: 20, fontSize: 11, color: FG3, fontFamily: "'JetBrains Mono',monospace" }}>
        {{ poi: "杭州 Hangzhou", route: "杭州西湖", charge: "杭州 → 都江堰", itinerary: "杭州 → 成都", sports: "Etihad Stadium" }[type]}
      </div>
    </div>
  );
}

// ─── Helper: POI star rating ───────────────────────────────────────────────────
function Stars({ rating }: { rating: number }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 3 }}>
      <Star size={10} fill="#F59E0B" color="#F59E0B" />
      <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, fontWeight: 600, color: "#F59E0B" }}>{rating}</span>
    </div>
  );
}

// ─── A-5.1 POI Card ───────────────────────────────────────────────────────────
function POICard({ active, onClick }: { active: boolean; onClick: () => void }) {
  const [selected, setSelected] = useState<number | null>(null);

  return (
    <GlassCard r={22} active={active} onClick={onClick}>
      {/* Header */}
      <div style={{ padding: "15px 16px 12px" }}>
        <AIBadge label="AI · 位置搜索" />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
            <Zap size={14} color={TEAL} />
            <span style={{ fontSize: 14.5, fontWeight: 600 }}>附近充电站</span>
          </div>
          <span style={{ fontSize: 11, color: FG3 }}>已更新 · 共{POIS.length}个</span>
        </div>
      </div>
      <HR />

      {/* POI list */}
      {POIS.map((poi, i) => {
        const isSel = selected === poi.n;
        return (
          <div key={poi.n}>
            <div
              onClick={e => { e.stopPropagation(); setSelected(isSel ? null : poi.n); }}
              style={{
                padding: "12px 16px", display: "flex", gap: 12, alignItems: "flex-start",
                background: isSel ? "rgba(70,214,224,.07)" : "transparent",
                cursor: "pointer", transition: "background .18s",
              }}>
              {/* Number badge — for voice "第N个" */}
              <div style={{
                width: 26, height: 26, borderRadius: 8, flexShrink: 0,
                background: isSel ? TEAL : "rgba(255,255,255,.07)",
                border: `1px solid ${isSel ? TEAL : "rgba(255,255,255,.12)"}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                transition: "all .18s",
              }}>
                <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, fontWeight: 700, color: isSel ? "#06080F" : FG3 }}>{poi.n}</span>
              </div>

              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
                  <span style={{ fontSize: 13, fontWeight: 600, color: FG1 }}>{poi.name}</span>
                  <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, color: TEAL, fontWeight: 600, flexShrink: 0, marginLeft: 8 }}>{poi.dist}</span>
                </div>
                <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 4 }}>
                  <Stars rating={poi.rating} />
                  {poi.fast && <span style={{ padding: "1px 6px", borderRadius: 4, background: "rgba(70,214,224,.12)", border: "1px solid rgba(70,214,224,.25)", fontSize: 9.5, color: TEAL, fontWeight: 600 }}>快充</span>}
                  <span style={{ fontSize: 11, color: poi.slots.startsWith("0") ? "#EF4444" : "#34D399" }}>{poi.slots}</span>
                </div>
                <div style={{ fontSize: 11, color: FG3 }}>{poi.addr}</div>
              </div>

              {isSel && <Navigation size={14} color={TEAL} style={{ flexShrink: 0, marginTop: 4 }} />}
            </div>
            {i < POIS.length - 1 && <div style={{ height: 1, background: DIV, margin: "0 16px" }} />}
          </div>
        );
      })}

      {/* Footer voice hint */}
      <div style={{ padding: "11px 16px 13px", borderTop: `1px solid ${DIV}`, display: "flex", alignItems: "center", gap: 8 }}>
        <Mic size={12} color={FG3} />
        <span style={{ fontSize: 11, color: FG3 }}>说"<span style={{ color: FG2 }}>导航去第2个</span>"或"<span style={{ color: FG2 }}>附近最快的充电站</span>"</span>
      </div>
    </GlassCard>
  );
}

// ─── A-5.1 POI Empty ─────────────────────────────────────────────────────────
function EmptyPOI({ active, onClick }: { active: boolean; onClick: () => void }) {
  return (
    <GlassCard r={22} active={active} onClick={onClick} style={{ height: 200, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10 }}>
      <Zap size={28} color="rgba(255,255,255,.18)" />
      <div style={{ textAlign: "center" }}><div style={{ fontSize: 14, fontWeight: 500, color: FG2, marginBottom: 4 }}>附近暂无充电站数据</div><div style={{ fontSize: 12, color: FG3 }}>请检查网络或刷新位置</div></div>
    </GlassCard>
  );
}

// ─── A-5.2 Route Card ────────────────────────────────────────────────────────
function RouteCard({ active, onClick }: { active: boolean; onClick: () => void }) {
  const total = { dur: "28分钟", dist: "12.3km" };
  return (
    <GlassCard r={22} active={active} onClick={onClick}>
      <div style={{ padding: "15px 16px 12px" }}>
        <AIBadge label="AI · 路线规划" />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
            <Navigation size={14} color={TEAL} />
            <span style={{ fontSize: 14.5, fontWeight: 600 }}>规划路线</span>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <Clock size={11} color={FG3} />
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, color: FG1, fontWeight: 600 }}>{total.dur}</span>
            </div>
            <span style={{ fontSize: 11, color: FG3 }}>{total.dist}</span>
          </div>
        </div>
      </div>
      <HR />

      {/* Timeline */}
      <div style={{ padding: "14px 20px" }}>
        {ROUTE_WPS.map((wp, i) => (
          <div key={i} style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
            {/* Left: dot + connector */}
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flexShrink: 0 }}>
              <div style={{
                width: 28, height: 28, borderRadius: "50%",
                background: wp.type === "origin" ? TEAL : wp.type === "dest" ? "#34D399" : "rgba(245,158,11,.15)",
                border: `2px solid ${wp.type === "origin" ? TEAL : wp.type === "dest" ? "#34D399" : "#F59E0B"}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 13, lineHeight: 1,
              }}>{wp.icon}</div>
              {i < ROUTE_WPS.length - 1 && (
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3, marginTop: 4, marginBottom: 4 }}>
                  {/* Segment info */}
                  <div style={{ fontSize: 9.5, color: FG3, textAlign: "center", lineHeight: 1.4, fontFamily: "'JetBrains Mono',monospace" }}>
                    {ROUTE_WPS[i+1].dur}<br />{ROUTE_WPS[i+1].dist}
                  </div>
                  <div style={{ width: 1, height: 24, background: "rgba(255,255,255,.12)", borderRadius: 1 }} />
                </div>
              )}
            </div>

            {/* Right: content */}
            <div style={{ paddingTop: 4, paddingBottom: i < ROUTE_WPS.length - 1 ? 0 : 4, flex: 1 }}>
              <div style={{ fontSize: 13.5, fontWeight: 600, color: FG1, marginBottom: 2 }}>{wp.label}</div>
              <div style={{ fontSize: 11.5, color: FG3, marginBottom: wp.type !== "dest" ? 24 : 0 }}>{wp.sub}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Start navigation CTA */}
      <div style={{ padding: "0 16px 14px" }}>
        <button style={{ width: "100%", padding: "11px 0", borderRadius: 14, background: AURORA, border: "none", color: "white", fontSize: 13.5, fontWeight: 600, cursor: "pointer", letterSpacing: ".02em" }}>
          开始导航
        </button>
      </div>
    </GlassCard>
  );
}

// ─── A-5.3 Charging Route Card ────────────────────────────────────────────────
function ChargingRouteCard({ active, onClick }: { active: boolean; onClick: () => void }) {
  const needsCharge = CHARGE_ROUTE.soc < 80;
  return (
    <GlassCard r={22} active={active} onClick={onClick}>
      <div style={{ padding: "15px 16px 12px" }}>
        <AIBadge label="AI · 充电路线" />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
            <Zap size={14} color="#F59E0B" />
            <span style={{ fontSize: 14.5, fontWeight: 600 }}>充电路线规划</span>
          </div>
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, color: FG1 }}>{CHARGE_ROUTE.totalDist}km</span>
            <span style={{ fontSize: 11, color: FG3 }}>{CHARGE_ROUTE.totalTime}</span>
          </div>
        </div>
      </div>
      <HR />

      {/* SoC bar */}
      <div style={{ padding: "14px 16px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
          <span style={{ fontSize: 12, color: FG3 }}>当前电量</span>
          <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 13, fontWeight: 700, color: CHARGE_ROUTE.soc > 50 ? TEAL : "#F59E0B" }}>{CHARGE_ROUTE.soc}%</span>
        </div>
        <div style={{ height: 8, borderRadius: 4, background: "rgba(255,255,255,.07)", overflow: "hidden" }}>
          <div style={{ width: `${CHARGE_ROUTE.soc}%`, height: "100%", borderRadius: 4, background: `linear-gradient(to right,${CHARGE_ROUTE.soc>50?"#46D6E0":"#F59E0B"},${CHARGE_ROUTE.soc>50?"#34D399":"#EF4444"})`, transition: "width .4s ease" }} />
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
          <span style={{ fontSize: 10, color: FG3 }}>{CHARGE_ROUTE.origin}</span>
          <span style={{ fontSize: 10, color: FG3 }}>目的地: {CHARGE_ROUTE.dest}</span>
        </div>
      </div>
      <HR />

      {/* Route with stops or "no charge needed" */}
      {needsCharge ? (
        <div style={{ padding: "14px 20px" }}>
          {/* Origin */}
          <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 12 }}>
            <div style={{ width: 10, height: 10, borderRadius: "50%", background: TEAL, flexShrink: 0 }} />
            <div><div style={{ fontSize: 13, fontWeight: 600, color: FG1 }}>{CHARGE_ROUTE.origin}</div><div style={{ fontSize: 11, color: FG3 }}>出发地 · SoC {CHARGE_ROUTE.soc}%</div></div>
          </div>
          {/* Charging stop */}
          {CHARGE_ROUTE.stops.map((stop, i) => (
            <div key={i}>
              <div style={{ display: "flex", gap: 10, alignItems: "center", padding: "3px 0 3px 1px" }}>
                <div style={{ width: 1, height: 28, background: "rgba(255,255,255,.10)", marginLeft: 4 }} />
                <div style={{ fontSize: 10.5, color: FG3, fontFamily: "'JetBrains Mono',monospace" }}>约{stop.atKm}km处</div>
              </div>
              <div style={{
                display: "flex", gap: 12, alignItems: "flex-start", marginBottom: 12,
                padding: "12px 14px", borderRadius: 14,
                background: "rgba(245,158,11,.08)",
                border: "1px solid rgba(245,158,11,.20)",
              }}>
                <div style={{ width: 28, height: 28, borderRadius: 8, background: "rgba(245,158,11,.18)", border: "1px solid rgba(245,158,11,.30)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, flexShrink: 0 }}>⚡</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: FG1, marginBottom: 3 }}>{stop.name}</div>
                  <div style={{ display: "flex", gap: 10 }}>
                    <span style={{ fontSize: 11, color: "#F59E0B" }}>{stop.time}</span>
                    <span style={{ fontSize: 11, color: FG3 }}>{stop.power}</span>
                    <span style={{ fontSize: 11, color: "#34D399" }}>补电{stop.addSoc}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
          {/* Destination */}
          <div style={{ display: "flex", gap: 10, alignItems: "center", padding: "3px 0 3px 1px" }}>
            <div style={{ width: 1, height: 24, background: "rgba(255,255,255,.10)", marginLeft: 4 }} />
          </div>
          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
            <div style={{ width: 10, height: 10, borderRadius: "50%", background: "#34D399", flexShrink: 0 }} />
            <div><div style={{ fontSize: 13, fontWeight: 600, color: FG1 }}>{CHARGE_ROUTE.dest}</div><div style={{ fontSize: 11, color: FG3 }}>到达时预计 SoC {CHARGE_ROUTE.soc + 30 - 35}%</div></div>
          </div>
        </div>
      ) : (
        <div style={{ padding: "20px 16px", display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 36, height: 36, borderRadius: 10, background: "rgba(52,211,153,.12)", border: "1px solid rgba(52,211,153,.28)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>✅</div>
          <div><div style={{ fontSize: 14, fontWeight: 600, color: "#34D399" }}>全程无需补电</div><div style={{ fontSize: 11.5, color: FG3, marginTop: 2 }}>当前电量足以完成全程，到达时余量充足</div></div>
        </div>
      )}
    </GlassCard>
  );
}

// ─── A-5.4 Itinerary Card ────────────────────────────────────────────────────
function ItineraryCard({ active, onClick }: { active: boolean; onClick: () => void }) {
  const [expandedDays, setExpandedDays] = useState<Set<number>>(new Set([1, 2, 3]));
  const toggle = (d: number) => setExpandedDays(prev => { const s = new Set(prev); s.has(d) ? s.delete(d) : s.add(d); return s; });

  return (
    <GlassCard r={22} active={active} onClick={onClick}>
      <div style={{ padding: "15px 16px 12px" }}>
        <AIBadge label="AI · 行程规划" />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
            <Calendar size={14} color={TEAL} />
            <span style={{ fontSize: 14.5, fontWeight: 600 }}>{ITINERARY.dest} · {ITINERARY.days}日行程</span>
          </div>
          <span style={{ fontSize: 11, color: FG3 }}>自驾 · AI 规划</span>
        </div>
      </div>
      <HR />

      <div style={{ padding: "10px 0 4px" }}>
        {ITINERARY.plan.map((day, di) => (
          <div key={day.day}>
            {/* Charge note between days */}
            {day.charge && (
              <div style={{ margin: "0 16px 6px", padding: "6px 12px", borderRadius: 10, background: "rgba(245,158,11,.08)", border: "1px solid rgba(245,158,11,.18)", display: "flex", alignItems: "center", gap: 8 }}>
                <Zap size={11} color="#F59E0B" />
                <span style={{ fontSize: 11, color: "#F59E0B" }}>{day.charge}</span>
              </div>
            )}

            {/* Day header */}
            <button
              onClick={e => { e.stopPropagation(); toggle(day.day); }}
              style={{ width: "100%", padding: "10px 16px", display: "flex", alignItems: "center", gap: 10, background: "none", border: "none", cursor: "pointer", color: FG1, fontFamily: "'Inter','Noto Sans SC',sans-serif" }}>
              <div style={{ width: 28, height: 20, borderRadius: 6, background: `${day.color}20`, border: `1px solid ${day.color}40`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <span style={{ fontSize: 9.5, fontWeight: 700, color: day.color, fontFamily: "'JetBrains Mono',monospace" }}>D{day.day}</span>
              </div>
              <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: FG1, textAlign: "left" }}>{day.theme}</span>
              <span style={{ fontSize: 11, color: FG3 }}>{day.stops.length}个点</span>
              <ChevronRight size={13} color={FG3} style={{ transform: expandedDays.has(day.day) ? "rotate(90deg)" : "none", transition: "transform .2s" }} />
            </button>

            {/* Stops */}
            <div style={{ maxHeight: expandedDays.has(day.day) ? 500 : 0, overflow: "hidden", transition: "max-height .3s ease" }}>
              {day.stops.map((stop, si) => (
                <div key={si} style={{ padding: "7px 16px 7px 52px", display: "flex", alignItems: "center", gap: 10 }}>
                  <span style={{ fontSize: 14, flexShrink: 0 }}>{stop.icon}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12.5, fontWeight: 500, color: FG1, marginBottom: 1 }}>{stop.name}</div>
                    <div style={{ fontSize: 10.5, color: FG3, overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>{stop.addr}</div>
                  </div>
                  {stop.nav && (
                    <button
                      onClick={e => e.stopPropagation()}
                      style={{ padding: "3px 10px", borderRadius: 8, background: "rgba(70,214,224,.10)", border: "1px solid rgba(70,214,224,.22)", fontSize: 10.5, color: TEAL, cursor: "pointer", flexShrink: 0, fontFamily: "'Inter',sans-serif" }}>
                      导航
                    </button>
                  )}
                </div>
              ))}
            </div>

            {di < ITINERARY.plan.length - 1 && <HR />}
          </div>
        ))}
      </div>

      {/* Voice hint */}
      <div style={{ padding: "11px 16px 13px", borderTop: `1px solid ${DIV}`, display: "flex", alignItems: "center", gap: 8 }}>
        <Mic size={12} color={FG3} />
        <span style={{ fontSize: 11, color: FG3 }}>说"<span style={{ color: FG2 }}>下一站</span>"或"<span style={{ color: FG2 }}>导航去第2天的都江堰</span>"</span>
      </div>
    </GlassCard>
  );
}

// ─── A-5.5 Sports Card ────────────────────────────────────────────────────────
function SportsCard({ active, onClick }: { active: boolean; onClick: () => void }) {
  const { home, away, goals, scorers } = MATCH;
  const totalMins = 90;

  return (
    <GlassCard r={22} active={active} onClick={onClick}>
      <div style={{ padding: "15px 16px 12px" }}>
        <AIBadge label="AI · 赛事信息" />
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
            <Trophy size={14} color="#F59E0B" />
            <span style={{ fontSize: 14.5, fontWeight: 600 }}>{MATCH.league}</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ padding: "2px 8px", borderRadius: 6, background: "rgba(107,114,128,.14)", border: "1px solid rgba(107,114,128,.22)", fontSize: 10.5, color: FG3 }}>{MATCH.status}</span>
            <span style={{ fontSize: 10.5, color: FG3 }}>{MATCH.date}</span>
          </div>
        </div>
      </div>
      <HR />

      {/* Scoreboard */}
      <div style={{ padding: "20px 16px 16px", display: "flex", alignItems: "center", gap: 12 }}>
        {/* Home */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
          <div style={{ width: 48, height: 48, borderRadius: 12, background: `${home.color}22`, border: `2px solid ${home.color}55`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, fontWeight: 700, color: home.color }}>{home.abbr}</span>
          </div>
          <span style={{ fontSize: 12, fontWeight: 600, color: FG1, textAlign: "center" }}>{home.short}</span>
        </div>

        {/* Score */}
        <div style={{ textAlign: "center", flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 44, fontWeight: 700, color: home.color, lineHeight: 1 }}>{home.score}</span>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 24, fontWeight: 300, color: FG3, lineHeight: 1 }}>–</span>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 44, fontWeight: 700, color: away.color, lineHeight: 1 }}>{away.score}</span>
          </div>
          <div style={{ fontSize: 10.5, color: FG3, marginTop: 4 }}>全场</div>
        </div>

        {/* Away */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
          <div style={{ width: 48, height: 48, borderRadius: 12, background: `${away.color}22`, border: `2px solid ${away.color}55`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, fontWeight: 700, color: away.color }}>{away.abbr}</span>
          </div>
          <span style={{ fontSize: 12, fontWeight: 600, color: FG1, textAlign: "center" }}>{away.short}</span>
        </div>
      </div>

      <HR />

      {/* Goal timeline */}
      <div style={{ padding: "13px 16px" }}>
        <div style={{ fontSize: 10.5, color: FG3, letterSpacing: ".09em", textTransform: "uppercase" as const, fontWeight: 600, marginBottom: 12 }}>进球时间线</div>
        {/* Timeline bar */}
        <div style={{ position: "relative", height: 6, borderRadius: 3, background: "rgba(255,255,255,.06)", marginBottom: 16 }}>
          {goals.map((g, i) => {
            const pct = (g.min / totalMins) * 100;
            const color = g.side === "home" ? home.color : away.color;
            return (
              <div key={i} style={{ position: "absolute", left: `${pct}%`, top: -3, transform: "translateX(-50%)", cursor: "default" }}>
                <div style={{ width: 12, height: 12, borderRadius: "50%", background: color, border: "2px solid rgba(6,8,15,.8)", boxShadow: `0 0 8px ${color}80` }} />
              </div>
            );
          })}
          {/* Progress line */}
          <div style={{ position: "absolute", inset: 0, borderRadius: 3, background: `linear-gradient(to right,${home.color}40,${away.color}30)` }} />
        </div>
        {/* Goal events */}
        {goals.map((g, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, fontWeight: 700, color: g.side === "home" ? home.color : away.color, width: 28, textAlign: "right", flexShrink: 0 }}>{g.min}'</span>
            <span style={{ fontSize: 13 }}>⚽</span>
            <span style={{ fontSize: 12.5, color: FG1 }}>{g.player}</span>
            <span style={{ fontSize: 11, color: FG3, marginLeft: "auto" }}>{g.side === "home" ? home.short : away.short}</span>
          </div>
        ))}
      </div>

      <HR />

      {/* Top scorers */}
      <div style={{ padding: "13px 16px" }}>
        <div style={{ fontSize: 10.5, color: FG3, letterSpacing: ".09em", textTransform: "uppercase" as const, fontWeight: 600, marginBottom: 10 }}>本赛季射手榜</div>
        {scorers.map((s, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: i < scorers.length - 1 ? 9 : 0 }}>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10.5, color: FG3, width: 16, textAlign: "right", flexShrink: 0 }}>{i + 1}</span>
            <span style={{ flex: 1, fontSize: 13, color: FG1, fontWeight: i === 0 ? 600 : 400 }}>{s.name}</span>
            <span style={{ fontSize: 11, color: FG3 }}>{s.team}</span>
            <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <div style={{ width: Math.round((s.goals / scorers[0].goals) * 60), height: 4, borderRadius: 2, background: i === 0 ? "#F59E0B" : "rgba(255,255,255,.18)", transition: "width .3s" }} />
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, fontWeight: 700, color: i === 0 ? "#F59E0B" : FG2, minWidth: 20 }}>{s.goals}</span>
            </div>
          </div>
        ))}
      </div>
    </GlassCard>
  );
}

// Empty sports
function EmptySports({ active, onClick }: { active: boolean; onClick: () => void }) {
  return (
    <GlassCard r={22} active={active} onClick={onClick} style={{ height: 200, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10 }}>
      <Trophy size={28} color="rgba(255,255,255,.18)" />
      <div style={{ textAlign: "center" }}><div style={{ fontSize: 14, fontWeight: 500, color: FG2, marginBottom: 4 }}>暂无比赛安排</div><div style={{ fontSize: 12, color: FG3 }}>今天没有关注球队的赛事</div></div>
    </GlassCard>
  );
}

// ─── Section label ─────────────────────────────────────────────────────────────
function SL({ num, title, sub }: { num: string; title: string; sub?: string }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: sub ? 4 : 0 }}>
        <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: FG3, letterSpacing: ".12em" }}>{num}</span>
        <div style={{ width: 1, height: 12, background: "rgba(255,255,255,.10)" }} />
        <div style={{ width: 3, height: 14, background: AURORA, borderRadius: 2 }} />
        <h3 style={{ fontSize: 13, fontWeight: 600, margin: 0, color: FG2, letterSpacing: ".02em" }}>{title}</h3>
      </div>
      {sub && <p style={{ fontSize: 11, color: FG3, margin: 0, paddingLeft: 42, lineHeight: 1.5 }}>{sub}</p>}
    </div>
  );
}

// ─── App — A-5 Showcase ───────────────────────────────────────────────────────
export default function App() {
  const [active, setActive] = useState<CardType>("poi");

  const TABS: { key: CardType; label: string; icon: string }[] = [
    { key: "poi",       label: "充电站",  icon: "⚡" },
    { key: "route",     label: "路线",    icon: "🗺" },
    { key: "charge",    label: "充电路线", icon: "🔋" },
    { key: "itinerary", label: "多日行程", icon: "📅" },
    { key: "sports",    label: "赛事",    icon: "⚽" },
  ];

  return (
    <div style={{ minHeight: "100vh", fontFamily: "'Inter','Noto Sans SC',-apple-system,sans-serif", color: FG1, background: "linear-gradient(155deg,#06080F 0%,#0A0E1A 52%,#080D18 100%)" }}>
      <style>{KEYFRAMES}</style>

      {/* Atmosphere */}
      <div aria-hidden style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
        <div style={{ position: "absolute", bottom: "10%", left: "14%", width: 600, height: 420, background: "radial-gradient(circle,rgba(91,140,255,.10) 0%,transparent 68%)", filter: "blur(52px)" }} />
        <div style={{ position: "absolute", top: "8%",  right: "8%",  width: 500, height: 360, background: "radial-gradient(circle,rgba(91,233,255,.07) 0%,transparent 68%)", filter: "blur(58px)" }} />
        <div style={{ position: "absolute", top: "42%", left: "38%",  width: 640, height: 480, background: "radial-gradient(circle,rgba(154,107,255,.06) 0%,transparent 68%)", filter: "blur(64px)" }} />
      </div>

      {/* Header */}
      <header style={{ position: "sticky", top: 0, zIndex: 30, height: 56, padding: "0 48px", display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(6,8,15,.80)", backdropFilter: "blur(28px)", WebkitBackdropFilter: "blur(28px)", borderBottom: `1px solid ${DIV}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 26, height: 26 }}><AuroraOrb state="idle" size={26} /></div>
          <span style={{ ...AURORA_TEXT, fontSize: 14, fontWeight: 600 }}>Aurora Glass</span>
          <span style={{ fontSize: 13, color: FG3, fontWeight: 300 }}>· A-5 卡片族 · 出行 / 行程 / 赛事 · 地图联动</span>
        </div>
        {/* Tab bar in header */}
        <div style={{ display: "flex", gap: 6 }}>
          {TABS.map(t => (
            <button key={t.key} onClick={() => setActive(t.key)} style={{
              padding: "5px 12px", borderRadius: 20, cursor: "pointer", fontSize: 12, fontFamily: "'Inter','Noto Sans SC',sans-serif",
              background: active === t.key ? "rgba(70,214,224,.12)" : "rgba(255,255,255,.04)",
              border: `1px solid ${active === t.key ? "rgba(70,214,224,.30)" : "rgba(255,255,255,.08)"}`,
              color: active === t.key ? TEAL : FG3, fontWeight: active === t.key ? 600 : 400,
              transition: "all .18s ease",
            }}>{t.icon} {t.label}</button>
          ))}
        </div>
      </header>

      {/* Content */}
      <div style={{ position: "relative", zIndex: 1, maxWidth: 1440, margin: "0 auto", padding: "28px 48px 80px" }}>

        {/* Page intro */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 5 }}>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10.5, color: FG3, letterSpacing: ".12em" }}>A-5</span>
            <div style={{ width: 1, height: 14, background: "rgba(255,255,255,.10)" }} />
            <div style={{ width: 3, height: 18, background: AURORA, borderRadius: 2 }} />
            <h2 style={{ fontSize: 17, fontWeight: 500, margin: 0, letterSpacing: ".03em" }}>出行 / 行程 / 赛事卡 · 右舞台地图联动</h2>
          </div>
          <p style={{ fontSize: 12.5, color: FG3, margin: 0, paddingLeft: 52, lineHeight: 1.6 }}>点击顶部 Tab 或卡片切换类型；右侧地图舞台随卡片内容实时联动高亮。正常态 + 空态各一。</p>
        </div>

        {/* 2-col: cards + map */}
        <div style={{ display: "grid", gridTemplateColumns: "460px 1fr", gap: 20, alignItems: "start" }}>

          {/* Left: card + empty state */}
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {/* Card */}
            {active === "poi"       && <><SL num="A-5.1" title="POI 列表卡 · 附近充电站" sub="编号选择态，供语音「导航去第N个」" /><POICard active onClick={() => {}} /></>}
            {active === "route"     && <><SL num="A-5.2" title="路线卡 · 时间线式导航" sub="出发→途经→目的地，分段距离/时长" /><RouteCard active onClick={() => {}} /></>}
            {active === "charge"    && <><SL num="A-5.3" title="充电路线卡 · SoC 可视化" sub="沿途补电点，电量不足时展开充电站" /><ChargingRouteCard active onClick={() => {}} /></>}
            {active === "itinerary" && <><SL num="A-5.4" title="多日行程卡 · 按天分组" sub="可折叠日程，一键导航，语音控制" /><ItineraryCard active onClick={() => {}} /></>}
            {active === "sports"    && <><SL num="A-5.5" title="赛事卡 · 比分 + 时间线 + 射手榜" sub="已完赛态，进球事件 + 积分条" /><SportsCard active onClick={() => {}} /></>}

            {/* Divider */}
            <div style={{ height: 1, background: DIV, margin: "4px 0" }} />

            {/* Empty state */}
            <SL num="空态" title="Empty State" />
            {active === "poi"       && <EmptyPOI active={false} onClick={() => {}} />}
            {active === "route"     && (
              <GlassCard r={22} style={{ height: 180, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10 }}>
                <Navigation size={28} color="rgba(255,255,255,.18)" />
                <div style={{ textAlign: "center" }}><div style={{ fontSize: 14, fontWeight: 500, color: FG2, marginBottom: 4 }}>暂无规划路线</div><div style={{ fontSize: 12, color: FG3 }}>说出"导航去XX"开始规划</div></div>
              </GlassCard>
            )}
            {active === "charge"    && (
              <GlassCard r={22} style={{ height: 180, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10 }}>
                <Zap size={28} color="rgba(255,255,255,.18)" />
                <div style={{ textAlign: "center" }}><div style={{ fontSize: 14, fontWeight: 500, color: FG2, marginBottom: 4 }}>暂无充电路线</div><div style={{ fontSize: 12, color: FG3 }}>请先设置目的地</div></div>
              </GlassCard>
            )}
            {active === "itinerary" && (
              <GlassCard r={22} style={{ height: 180, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 10 }}>
                <Calendar size={28} color="rgba(255,255,255,.18)" />
                <div style={{ textAlign: "center" }}><div style={{ fontSize: 14, fontWeight: 500, color: FG2, marginBottom: 4 }}>暂无行程安排</div><div style={{ fontSize: 12, color: FG3 }}>说出"规划去成都3天"开始</div></div>
              </GlassCard>
            )}
            {active === "sports"    && <EmptySports active={false} onClick={() => {}} />}
          </div>

          {/* Right: sticky map stage */}
          <div style={{ position: "sticky", top: 76 }}>
            <MapStage type={active} />
          </div>
        </div>
      </div>
    </div>
  );
}
