import { useState, useEffect, CSSProperties, ReactNode } from "react";

// ─── Aurora Glass · Design Tokens ─────────────────────────────────────────────
const AURORA = "linear-gradient(135deg, #5BE9FF 0%, #5B8CFF 33%, #9A6BFF 66%, #FF6BD6 100%)";
const AURORA_CONIC = "conic-gradient(from 0deg, #5BE9FF, #5B8CFF, #9A6BFF, #FF6BD6, #5BE9FF)";
const AURORA_TEXT: CSSProperties = {
  background: AURORA,
  WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent",
  backgroundClip: "text",
};
const TEAL = "#46D6E0";

// ─── Keyframes injected once ──────────────────────────────────────────────────
const KEYFRAMES = `
  @keyframes aurora-breathe {
    0%, 100% { opacity: 0.82; transform: scale(1); }
    50%       { opacity: 1;    transform: scale(1.038); }
  }
  @keyframes aurora-breathe-fast {
    0%, 100% { opacity: 0.85; transform: scale(1); }
    50%       { opacity: 1;    transform: scale(1.045); }
  }
  @keyframes aurora-spin {
    from { transform: rotate(0deg); }
    to   { transform: rotate(360deg); }
  }
  @keyframes aurora-spin-r {
    from { transform: rotate(360deg); }
    to   { transform: rotate(0deg); }
  }
  @keyframes aurora-pulse {
    0%, 100% { transform: scale(1);    opacity: 0.86; }
    25%       { transform: scale(1.07); opacity: 1; }
    75%       { transform: scale(0.96); opacity: 0.80; }
  }
  @keyframes aurora-edge {
    0%, 100% { opacity: 0.35; }
    50%       { opacity: 0.72; }
  }
  @keyframes shimmer-lr {
    0%   { transform: translateX(-120%); }
    100% { transform: translateX(220%); }
  }
  @keyframes ripple-out {
    0%   { transform: translate(-50%, -50%) scale(0.85); opacity: 0.5; }
    100% { transform: translate(-50%, -50%) scale(1.6);  opacity: 0; }
  }
`;

// ─── Primitive components ──────────────────────────────────────────────────────
type OrbState = "idle" | "thinking" | "speaking";

function AuroraOrb({ state, size = 140 }: { state: OrbState; size?: number }) {
  const thinking = state === "thinking";
  const speaking  = state === "speaking";
  const glowMult  = speaking ? 1.35 : 1;

  const outerAnim  = thinking ? "aurora-breathe-fast 1.4s ease-in-out infinite"
                   : speaking  ? "aurora-pulse 0.72s ease-in-out infinite"
                   :             "aurora-breathe 4s ease-in-out infinite";
  const haloSpeed  = thinking ? "1.6s" : "8s";
  const innerSpeed = thinking ? "1.1s" : "5s";
  const ctSpeed    = thinking ? "0.8s" : "3.8s";

  return (
    <div style={{ position: "relative", width: size, height: size, flexShrink: 0 }}>
      {/* Ambient glow */}
      <div style={{
        position: "absolute",
        inset: -size * 0.52,
        borderRadius: "50%",
        background: `radial-gradient(circle, rgba(91,140,255,${0.20 * glowMult}) 0%, rgba(154,107,255,${0.11 * glowMult}) 40%, transparent 70%)`,
        animation: outerAnim,
        pointerEvents: "none",
      }} />
      {/* Aurora halo ring */}
      <div style={{
        position: "absolute",
        inset: -size * 0.06,
        borderRadius: "50%",
        background: AURORA_CONIC,
        opacity: thinking ? 0.52 : 0.26,
        filter: `blur(${size * 0.115}px)`,
        animation: `aurora-spin ${haloSpeed} linear infinite`,
        pointerEvents: "none",
      }} />
      {/* Glass orb body */}
      <div style={{
        position: "absolute",
        inset: 0,
        borderRadius: "50%",
        background: `radial-gradient(circle at 36% 28%,
          rgba(255,255,255,0.44) 0%,
          rgba(91,233,255,0.22) 28%,
          rgba(91,140,255,0.18) 56%,
          rgba(154,107,255,0.26) 78%,
          rgba(255,107,214,0.14) 100%)`,
        backdropFilter: "blur(14px)",
        WebkitBackdropFilter: "blur(14px)",
        border: "1px solid rgba(255,255,255,0.24)",
        boxShadow: `
          0 0 ${size * 0.32 * glowMult}px rgba(91,142,255,0.52),
          0 0 ${size * 0.70 * glowMult}px rgba(154,107,255,0.22),
          inset 0 0 ${size * 0.24}px rgba(91,233,255,0.20),
          inset 0 ${size * 0.012}px 0 rgba(255,255,255,0.34)`,
        animation: outerAnim,
        pointerEvents: "none",
      }} />
      {/* Inner aurora swirl */}
      <div style={{
        position: "absolute",
        inset: size * 0.16,
        borderRadius: "50%",
        background: AURORA_CONIC,
        opacity: 0.70,
        filter: `blur(${size * 0.036}px)`,
        animation: `aurora-spin ${innerSpeed} linear infinite`,
        pointerEvents: "none",
      }} />
      {/* Counter swirl */}
      <div style={{
        position: "absolute",
        inset: size * 0.28,
        borderRadius: "50%",
        background: `conic-gradient(from 180deg, #9A6BFF, #5B8CFF, #5BE9FF, #FF6BD6, #9A6BFF)`,
        opacity: 0.54,
        filter: `blur(${size * 0.028}px)`,
        animation: `aurora-spin-r ${ctSpeed} linear infinite`,
        pointerEvents: "none",
      }} />
      {/* Specular highlight top-left */}
      <div style={{
        position: "absolute",
        top: "9%", left: "13%",
        width: "44%", height: "33%",
        borderRadius: "50%",
        background: "radial-gradient(ellipse, rgba(255,255,255,0.70) 0%, transparent 100%)",
        filter: "blur(2px)",
        pointerEvents: "none",
      }} />
      {/* Chromatic refraction bottom-right */}
      <div style={{
        position: "absolute",
        bottom: "11%", right: "14%",
        width: "26%", height: "19%",
        borderRadius: "50%",
        background: "radial-gradient(ellipse, rgba(255,107,214,0.48) 0%, transparent 100%)",
        filter: "blur(3px)",
        pointerEvents: "none",
      }} />
    </div>
  );
}

function GlassCard({
  children, p = 24, r = 24, light = false, style,
}: {
  children?: ReactNode; p?: number; r?: number; light?: boolean; style?: CSSProperties;
}) {
  return (
    <div style={{
      padding: p,
      borderRadius: r,
      background: light ? "rgba(255,255,255,0.76)" : "rgba(255,255,255,0.056)",
      backdropFilter: "blur(32px)",
      WebkitBackdropFilter: "blur(32px)",
      border: light ? "1px solid rgba(255,255,255,0.95)" : "1px solid rgba(255,255,255,0.10)",
      borderTop: light ? "1px solid rgba(255,255,255,1)" : "1px solid rgba(255,255,255,0.18)",
      borderLeft: light ? "1px solid rgba(255,255,255,1)" : "1px solid rgba(255,255,255,0.14)",
      boxShadow: light
        ? "0 8px 32px rgba(10,14,26,0.09), 0 2px 8px rgba(10,14,26,0.05), inset 0 1px 0 rgba(255,255,255,1)"
        : "0 8px 40px rgba(0,0,0,0.50), 0 2px 12px rgba(0,0,0,0.28), inset 0 1px 0 rgba(255,255,255,0.13)",
      ...style,
    }}>
      {children}
    </div>
  );
}

function SectionTitle({ num, title, sub }: { num: string; title: string; sub?: string }) {
  return (
    <div style={{ marginBottom: 36 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 6 }}>
        <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, fontWeight: 500, letterSpacing: "0.14em", opacity: 0.36 }}>{num}</span>
        <div style={{ width: 1, height: 16, background: "rgba(255,255,255,0.12)" }} />
        <div style={{ width: 3, height: 22, background: AURORA, borderRadius: 2 }} />
        <h2 style={{ fontSize: 18, fontWeight: 500, letterSpacing: "0.04em", margin: 0 }}>{title}</h2>
      </div>
      {sub && <p style={{ fontSize: 12.5, opacity: 0.40, paddingLeft: 60, margin: 0, letterSpacing: "0.015em", lineHeight: 1.6 }}>{sub}</p>}
    </div>
  );
}

function Label({ children, color }: { children: ReactNode; color?: string }) {
  return (
    <div style={{
      fontSize: 10.5, fontWeight: 600,
      letterSpacing: "0.12em", textTransform: "uppercase",
      opacity: color ? 1 : 0.36, color: color ?? undefined,
      marginBottom: 14,
    }}>
      {children}
    </div>
  );
}

function ColorBlock({ hex, label, sub, w = 88, h = 56 }: { hex: string; label: string; sub?: string; w?: number; h?: number }) {
  return (
    <div>
      <div style={{ width: w, height: h, background: hex, borderRadius: 14, border: "1px solid rgba(255,255,255,0.08)", boxShadow: "0 4px 14px rgba(0,0,0,0.32)", marginBottom: 8 }} />
      <div style={{ fontSize: 11.5, fontWeight: 500, opacity: 0.88 }}>{label}</div>
      {sub && <div style={{ fontSize: 10, opacity: 0.38, fontFamily: "'JetBrains Mono', monospace", marginTop: 2 }}>{sub}</div>}
    </div>
  );
}

const DIVIDER_DARK  = "rgba(255,255,255,0.07)";
const DIVIDER_LIGHT = "rgba(10,14,26,0.07)";

const AQI_GRADES = [
  { label: "优", hex: "#34D399", range: "0–50" },
  { label: "良", hex: "#A3E635", range: "51–100" },
  { label: "轻度", hex: "#FCD34D", range: "101–150" },
  { label: "中度", hex: "#FB923C", range: "151–200" },
  { label: "重度", hex: "#EF4444", range: "201–300" },
  { label: "严重", hex: "#9333EA", range: "301–400" },
  { label: "爆表", hex: "#7F1D1D", range: "400+" },
];

// ─── Main export ───────────────────────────────────────────────────────────────
export default function App() {
  const [isDark, setIsDark] = useState(true);
  const [orbState, setOrbState] = useState<OrbState>("idle");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
  }, [isDark]);

  const fg1 = isDark ? "rgba(255,255,255,0.92)" : "rgba(10,14,26,0.92)";
  const fg2 = isDark ? "rgba(255,255,255,0.56)" : "rgba(10,14,26,0.55)";
  const fg3 = isDark ? "rgba(255,255,255,0.32)" : "rgba(10,14,26,0.30)";
  const div = isDark ? DIVIDER_DARK : DIVIDER_LIGHT;

  const pageBg = isDark
    ? "linear-gradient(155deg, #06080F 0%, #0A0E1A 55%, #080D18 100%)"
    : "linear-gradient(155deg, #EDF1FA 0%, #E4EBF7 100%)";

  return (
    <div style={{ minHeight: "100vh", fontFamily: "'Inter','Noto Sans SC',-apple-system,sans-serif", background: pageBg, color: fg1, overflowX: "hidden" }}>
      <style>{KEYFRAMES}</style>

      {/* ── STICKY HEADER ─────────────────────────────────────────────── */}
      <header style={{
        position: "sticky", top: 0, zIndex: 50,
        borderBottom: `1px solid ${div}`,
        backdropFilter: "blur(28px)", WebkitBackdropFilter: "blur(28px)",
        background: isDark ? "rgba(6,8,15,0.76)" : "rgba(237,241,250,0.84)",
        height: 60, padding: "0 48px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ width: 30, height: 30 }}><AuroraOrb state="idle" size={30} /></div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 10 }}>
            <span style={{ ...AURORA_TEXT, fontSize: 15, fontWeight: 600, letterSpacing: "0.025em" }}>Aurora Glass</span>
            <span style={{ fontSize: 14, fontWeight: 300, opacity: 0.42 }}>· 极光液态座舱 · Design System</span>
          </div>
          <div style={{
            padding: "3px 10px", borderRadius: 20,
            border: `1px solid rgba(70,214,224,0.28)`,
            fontSize: 10.5, fontWeight: 500,
            color: TEAL, fontFamily: "'JetBrains Mono',monospace",
            letterSpacing: "0.06em",
          }}>v1.0 · DS</div>
        </div>

        {/* Theme toggle */}
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 12, opacity: isDark ? 0.8 : 0.35, transition: "opacity .2s" }}>深色</span>
          <button onClick={() => setIsDark(!isDark)} style={{
            width: 46, height: 24, borderRadius: 12, cursor: "pointer",
            background: isDark ? "rgba(91,140,255,0.3)" : "rgba(10,14,26,0.12)",
            border: `1px solid ${isDark ? "rgba(91,140,255,0.55)" : "rgba(10,14,26,0.18)"}`,
            position: "relative", transition: "all .25s ease",
          }}>
            <div style={{
              position: "absolute", top: 3, left: isDark ? 2 : 22,
              width: 16, height: 16, borderRadius: "50%",
              background: isDark ? AURORA : "rgba(10,14,26,0.45)",
              transition: "left .25s ease",
              boxShadow: isDark ? "0 0 8px rgba(91,140,255,0.6)" : "none",
            }} />
          </button>
          <span style={{ fontSize: 12, opacity: isDark ? 0.35 : 0.8, transition: "opacity .2s" }}>浅色</span>
        </div>
      </header>

      {/* ── PAGE CONTENT ─────────────────────────────────────────────── */}
      <div style={{ maxWidth: 1440, margin: "0 auto", padding: "64px 48px 120px" }}>

        {/* ════════════════════════════════════════════════════════════ */}
        {/* 01  COLOR SYSTEM                                           */}
        {/* ════════════════════════════════════════════════════════════ */}
        <section style={{ marginBottom: 88 }}>
          <SectionTitle num="01" title="COLOR SYSTEM · 色彩系统" sub="深色 + 浅色两套色板，含签名渐变与全部语义色。严禁在正文与关键数字上使用极光渐变。" />

          {/* Deep Space Base */}
          <Label>DEEP SPACE BASE · 深空底色（深色主题）</Label>
          <div style={{ display: "flex", gap: 14, marginBottom: 44, flexWrap: "wrap" }}>
            {[
              { hex: "#06080F", label: "Space-950", sub: "#06080F" },
              { hex: "#0A0E1A", label: "Space-900", sub: "#0A0E1A" },
              { hex: "#0F1525", label: "Space-800", sub: "#0F1525" },
              { hex: "#151D30", label: "Space-700", sub: "#151D30" },
              { hex: "#1C2540", label: "Space-600", sub: "#1C2540" },
              { hex: "#243055", label: "Space-500", sub: "#243055" },
              { hex: "#2D3D6A", label: "Space-400", sub: "#2D3D6A" },
            ].map(c => <ColorBlock key={c.hex} {...c} w={96} h={64} />)}
          </div>

          {/* Aurora Signature Gradient */}
          <Label>AI AURORA SIGNATURE · 极光签名渐变（仅 AI 时刻）</Label>
          <div style={{ marginBottom: 44 }}>
            <div style={{ height: 72, borderRadius: 20, background: AURORA, boxShadow: "0 8px 32px rgba(91,140,255,0.32), 0 4px 16px rgba(154,107,255,0.22)", marginBottom: 16 }} />
            <div style={{ display: "flex", justifyContent: "space-between", padding: "0 6px" }}>
              {[
                { stop: "0%",   hex: "#5BE9FF", name: "Aurora Cyan" },
                { stop: "33%",  hex: "#5B8CFF", name: "Aurora Blue" },
                { stop: "66%",  hex: "#9A6BFF", name: "Aurora Violet" },
                { stop: "100%", hex: "#FF6BD6", name: "Aurora Magenta" },
              ].map(s => (
                <div key={s.hex} style={{ textAlign: "center" }}>
                  <div style={{ width: 34, height: 34, borderRadius: 10, background: s.hex, margin: "0 auto 7px", border: "1px solid rgba(255,255,255,0.15)", boxShadow: `0 4px 12px ${s.hex}55` }} />
                  <div style={{ fontSize: 11.5, fontWeight: 500 }}>{s.name}</div>
                  <div style={{ fontSize: 10, opacity: 0.38, fontFamily: "'JetBrains Mono',monospace" }}>{s.hex}</div>
                  <div style={{ fontSize: 10, opacity: 0.25, fontFamily: "'JetBrains Mono',monospace" }}>{s.stop}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Interactive + Text levels */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 44 }}>
            <div>
              <Label>INTERACTIVE BLUE · 冷蓝交互色（非AI时刻）</Label>
              <GlassCard p={20} r={18}>
                <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
                  <div style={{ width: 80, height: 54, borderRadius: 14, background: TEAL, boxShadow: "0 4px 18px rgba(70,214,224,0.40)", flexShrink: 0 }} />
                  <div>
                    <div style={{ fontSize: 15, fontWeight: 600, color: TEAL, marginBottom: 4 }}>Interactive Blue</div>
                    <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 12, opacity: 0.44, marginBottom: 8 }}>#46D6E0</div>
                    <div style={{ fontSize: 11.5, opacity: 0.42, lineHeight: 1.6 }}>普通交互·导航激活·置信高·不用于AI高亮时刻</div>
                  </div>
                </div>
              </GlassCard>
            </div>
            <div>
              <Label>TEXT HIERARCHY · 文字三级冷白灰阶</Label>
              <GlassCard p={20} r={18} style={{ height: "100%" }}>
                <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                  {[
                    { name: "Primary",   opacity: "92%", sample: "正文与关键数据内容", contrast: "≥ 8.5 : 1" },
                    { name: "Secondary", opacity: "56%", sample: "标签与辅助说明文字", contrast: "≥ 4.5 : 1" },
                    { name: "Tertiary",  opacity: "32%", sample: "占位符与禁用状态",   contrast: "≥ 3.0 : 1" },
                  ].map((t, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <div style={{ width: 36, height: 5, borderRadius: 3, background: `rgba(255,255,255,${parseFloat(t.opacity)/100})`, flexShrink: 0 }} />
                      <span style={{ fontSize: 13, opacity: parseFloat(t.opacity)/100, flex: 1 }}>{t.sample}</span>
                      <span style={{ fontSize: 10, opacity: 0.28, fontFamily: "'JetBrains Mono',monospace", flexShrink: 0 }}>{t.contrast}</span>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </div>
          </div>

          {/* Semantic */}
          <Label>SEMANTIC COLORS · 语义色（实色·不虹彩·A股涨绿跌红）</Label>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 36 }}>
            {[
              { hex: "#22C55E", label: "涨 Up",     sub: "#22C55E" },
              { hex: "#EF4444", label: "跌 Down",   sub: "#EF4444" },
              { hex: TEAL,      label: "置信高",    sub: "#46D6E0" },
              { hex: "#F59E0B", label: "置信中·警告", sub: "#F59E0B" },
              { hex: "#6B7280", label: "置信低",    sub: "#6B7280" },
              { hex: "#EF4444", label: "危险",       sub: "#EF4444" },
              { hex: "#34D399", label: "在线",       sub: "#34D399" },
            ].map(c => <ColorBlock key={c.label} {...c} w={82} h={52} />)}
          </div>

          {/* AQI */}
          <Label>AQI · 空气质量 7 档（实色·不虹彩）</Label>
          <div style={{ display: "flex", gap: 10, marginBottom: 44 }}>
            {AQI_GRADES.map(a => (
              <div key={a.label} style={{ textAlign: "center" }}>
                <div style={{ width: 62, height: 38, borderRadius: 10, background: a.hex, marginBottom: 6, border: "1px solid rgba(255,255,255,0.08)" }} />
                <div style={{ fontSize: 12, fontWeight: 500 }}>{a.label}</div>
                <div style={{ fontSize: 10, opacity: 0.35, fontFamily: "'JetBrains Mono',monospace" }}>{a.range}</div>
              </div>
            ))}
          </div>

          {/* Light theme swatches */}
          <Label>LIGHT THEME · 浅色主题色板（磨砂白玻璃）</Label>
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
            {[
              { hex: "#EDF1FA",               label: "Light BG-1",     sub: "#EDF1FA" },
              { hex: "#E4EBF7",               label: "Light BG-2",     sub: "#E4EBF7" },
              { hex: "rgba(255,255,255,0.76)", label: "Frosted Glass",  sub: "white·76%" },
              { hex: "rgba(255,255,255,1.00)", label: "Edge Highlight", sub: "white·100%" },
              { hex: "rgba(10,14,26,0.92)",   label: "Text-1",         sub: "#0A0E1A·92%" },
              { hex: "rgba(10,14,26,0.55)",   label: "Text-2",         sub: "#0A0E1A·55%" },
              { hex: "rgba(10,14,26,0.30)",   label: "Text-3",         sub: "#0A0E1A·30%" },
            ].map(c => (
              <div key={c.label}>
                <div style={{ width: 90, height: 56, background: c.hex, borderRadius: 14, border: "1px solid rgba(10,14,26,0.10)", boxShadow: "0 2px 10px rgba(10,14,26,0.06)", marginBottom: 8 }} />
                <div style={{ fontSize: 11.5, fontWeight: 500, color: fg2 }}>{c.label}</div>
                <div style={{ fontSize: 10, opacity: 0.35, fontFamily: "'JetBrains Mono',monospace", color: fg2 }}>{c.sub}</div>
              </div>
            ))}
          </div>
        </section>

        {/* ════════════════════════════════════════════════════════════ */}
        {/* 02  GLASS MATERIAL                                         */}
        {/* ════════════════════════════════════════════════════════════ */}
        <section style={{ marginBottom: 88 }}>
          <SectionTitle num="02" title="GLASS MATERIAL · 液态玻璃材质" sub="半透明 + 背景模糊 28–40px + 冷色 tint + 镜面边缘 + 悬浮投影，明暗两版规格" />

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 36 }}>
            {/* Dark specimen */}
            <div>
              <Label>DARK MODE · 深色液态玻璃</Label>
              <div style={{ borderRadius: 26, padding: 3, background: "linear-gradient(135deg, rgba(91,233,255,0.18), rgba(154,107,255,0.12), rgba(255,107,214,0.08))" }}>
                <div style={{ borderRadius: 23, padding: 28, background: "linear-gradient(135deg, #0F1525, #151D30)", position: "relative", minHeight: 292, overflow: "hidden" }}>
                  <div style={{ position: "absolute", top: -50, right: -30, width: 200, height: 200, borderRadius: "50%", background: "radial-gradient(circle, rgba(91,140,255,0.32), transparent 70%)", pointerEvents: "none" }} />
                  <div style={{ position: "absolute", bottom: -30, left: 10, width: 140, height: 140, borderRadius: "50%", background: "radial-gradient(circle, rgba(154,107,255,0.22), transparent 70%)", pointerEvents: "none" }} />
                  <GlassCard p={20} r={18} style={{ marginBottom: 14 }}>
                    <div style={{ fontSize: 11.5, opacity: 0.48, marginBottom: 6 }}>当前车速</div>
                    <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 38, fontWeight: 700, letterSpacing: "-0.025em", color: "rgba(255,255,255,0.95)", lineHeight: 1 }}>
                      87 <span style={{ fontSize: 15, fontWeight: 400, opacity: 0.45 }}>km/h</span>
                    </div>
                  </GlassCard>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <GlassCard p={16} r={14}>
                      <div style={{ fontSize: 10.5, opacity: 0.42, marginBottom: 5 }}>续航里程</div>
                      <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 22, fontWeight: 600 }}>324 <span style={{ fontSize: 11.5, opacity: 0.44 }}>km</span></div>
                    </GlassCard>
                    <GlassCard p={16} r={14} style={{ border: `1px solid rgba(70,214,224,0.28)`, boxShadow: `0 0 18px rgba(70,214,224,0.11), inset 0 1px 0 rgba(255,255,255,0.13)` }}>
                      <div style={{ fontSize: 10.5, color: TEAL, marginBottom: 5 }}>导航中</div>
                      <div style={{ fontSize: 13.5, fontWeight: 500 }}>朝阳·望京</div>
                    </GlassCard>
                  </div>
                </div>
              </div>
            </div>

            {/* Light specimen */}
            <div>
              <Label>LIGHT MODE · 浅色磨砂白玻璃</Label>
              <div style={{ borderRadius: 26, padding: 3, background: "linear-gradient(135deg, rgba(255,255,255,0.95), rgba(91,140,255,0.18))" }}>
                <div style={{ borderRadius: 23, padding: 28, background: "linear-gradient(135deg, #EDF1FA, #E0EAF8)", position: "relative", minHeight: 292, overflow: "hidden" }}>
                  <div style={{ position: "absolute", top: -40, right: -20, width: 170, height: 170, borderRadius: "50%", background: "radial-gradient(circle, rgba(91,140,255,0.14), transparent 70%)", pointerEvents: "none" }} />
                  <GlassCard p={20} r={18} light style={{ marginBottom: 14 }}>
                    <div style={{ fontSize: 11.5, color: "rgba(10,14,26,0.48)", marginBottom: 6 }}>当前车速</div>
                    <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 38, fontWeight: 700, letterSpacing: "-0.025em", color: "rgba(10,14,26,0.90)", lineHeight: 1 }}>
                      87 <span style={{ fontSize: 15, fontWeight: 400, color: "rgba(10,14,26,0.38)" }}>km/h</span>
                    </div>
                  </GlassCard>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <GlassCard p={16} r={14} light>
                      <div style={{ fontSize: 10.5, color: "rgba(10,14,26,0.40)", marginBottom: 5 }}>续航里程</div>
                      <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 22, fontWeight: 600, color: "rgba(10,14,26,0.88)" }}>324 <span style={{ fontSize: 11.5, color: "rgba(10,14,26,0.36)" }}>km</span></div>
                    </GlassCard>
                    <GlassCard p={16} r={14} light style={{ border: `1px solid rgba(70,214,224,0.45)` }}>
                      <div style={{ fontSize: 10.5, color: TEAL, marginBottom: 5 }}>导航中</div>
                      <div style={{ fontSize: 13.5, fontWeight: 500, color: "rgba(10,14,26,0.85)" }}>朝阳·望京</div>
                    </GlassCard>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Spec table */}
          <Label>GLASS MATERIAL SPEC · 材质参数规格表</Label>
          <GlassCard p={0} r={20} style={{ overflow: "hidden" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: `1px solid ${div}` }}>
                  {["属性 Property", "深色模式 Dark", "浅色模式 Light", "备注"].map((h, i) => (
                    <th key={i} style={{ padding: "13px 20px", textAlign: "left", fontSize: 10.5, fontWeight: 600, letterSpacing: "0.09em", textTransform: "uppercase", opacity: 0.36 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[
                  ["背景透明度", "rgba(255,255,255, 5.6%)", "rgba(255,255,255, 76%)", "越高→越磨砂；深色低防穿帮"],
                  ["背景模糊", "blur(32px)  [28–40px]", "blur(32px)  [28–40px]", "行车态可降至 24px 节省 GPU"],
                  ["冷色 tint", "rgba(180,220,255, 8–11%)", "无（纯白磨砂）", "深色叠冷色 tint 强化深邃感"],
                  ["饱和提升", "saturate(1.1–1.2)", "saturate(1.05)", "backdrop-filter 附加"],
                  ["顶/左缘高光", "rgba(255,255,255,18%) 1px", "rgba(255,255,255,100%) 1px", "形成液态玻璃厚度感"],
                  ["底缘微暗", "rgba(0,0,0,20%) 1px", "rgba(0,0,0,6%) 1px", "强化悬浮立体感"],
                  ["圆角 squircle", "20–28px  (推荐 24px)", "20–28px  (推荐 24px)", "连续曲率，非普通 border-radius"],
                  ["外发投影", "0 8px 40px rgba(0,0,0,50%)", "0 8px 32px rgba(0,0,0,9%)", "深色投影更重"],
                  ["内顶高光", "inset 0 1px 0 rgba(255,255,255,13%)", "inset 0 1px 0 rgba(255,255,255,100%)", "悬浮感的关键笔触"],
                  ["折射色散", "border-color hsl(220,80%,80%,4%)", "border-color rgba(200,220,255,6%)", "极淡冷色边缘色散"],
                ].map((row, i) => (
                  <tr key={i} style={{ borderBottom: `1px solid ${div}` }}>
                    {row.map((cell, j) => (
                      <td key={j} style={{
                        padding: "11px 20px",
                        fontSize: j === 0 ? 13 : j < 3 ? 11.5 : 12,
                        fontWeight: j === 0 ? 500 : 400,
                        opacity: j === 3 ? 0.40 : 0.84,
                        fontFamily: j > 0 && j < 3 ? "'JetBrains Mono',monospace" : "inherit",
                        color: fg1,
                      }}>{cell}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </GlassCard>
        </section>

        {/* ════════════════════════════════════════════════════════════ */}
        {/* 03  AI AURORA GLOW USAGE                                   */}
        {/* ════════════════════════════════════════════════════════════ */}
        <section style={{ marginBottom: 88 }}>
          <SectionTitle num="03" title="AI AURORA GLOW · 极光辉光用法规范" sub="克制·专属·有意义——极光只在「AI 时刻」出现，其余场景一律用单一冷蓝 #46D6E0" />

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            {/* Allowed */}
            <div>
              <Label color="#22C55E">✓ ALLOWED · 允许使用场景</Label>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>

                {/* AI Orb */}
                <GlassCard p={18} r={16}>
                  <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                    <AuroraOrb state="idle" size={52} />
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 3 }}>AI 光球 · 助手化身「小舟」</div>
                      <div style={{ fontSize: 12, opacity: 0.44, lineHeight: 1.6 }}>极光流动即 AI 生命感的核心标识，唯一持续存在的极光元素</div>
                    </div>
                  </div>
                </GlassCard>

                {/* Edge glow */}
                <div style={{ borderRadius: 16, overflow: "hidden", height: 76, position: "relative" }}>
                  <div style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg, #0F1525, #151D30)" }} />
                  <div style={{
                    position: "absolute", inset: 0, borderRadius: 16,
                    background: "linear-gradient(#0F1525, #0F1525) padding-box, linear-gradient(135deg,#5BE9FF,#5B8CFF,#9A6BFF,#FF6BD6) border-box",
                    border: "2px solid transparent",
                    animation: "aurora-edge 2.8s ease-in-out infinite",
                  }} />
                  <div style={{ position: "relative", zIndex: 1, padding: "14px 20px", display: "flex", alignItems: "center", gap: 12 }}>
                    <AuroraOrb state="thinking" size={38} />
                    <div>
                      <div style={{ fontSize: 12.5, fontWeight: 500, marginBottom: 2 }}>聆听/思考 · 屏幕边缘极光辉光</div>
                      <div style={{ fontSize: 11.5, opacity: 0.42 }}>类 Apple Intelligence / Siri 激活态，2px aurora border</div>
                    </div>
                  </div>
                </div>

                {/* Streaming text */}
                <GlassCard p={20} r={16}>
                  <div style={{ fontSize: 11, opacity: 0.40, marginBottom: 8 }}>AI 流式输出 · 虹彩光标 + 微光扫过</div>
                  <div style={{ fontSize: 14.5, lineHeight: 1.65, position: "relative", overflow: "hidden" }}>
                    <span style={{ opacity: 0.88 }}>正在为您规划最优路线，预计抵达约</span>
                    <span style={{ ...AURORA_TEXT, fontWeight: 600 }}> 23 分钟 </span>
                    <span style={{ opacity: 0.88 }}>，高速费 ¥28</span>
                    <div style={{
                      position: "absolute", top: 0, bottom: 0,
                      width: "28%",
                      background: "linear-gradient(90deg, transparent, rgba(91,233,255,0.09), transparent)",
                      animation: "shimmer-lr 2.6s ease-in-out infinite",
                      pointerEvents: "none",
                    }} />
                  </div>
                </GlassCard>

                {/* AI generated content border */}
                <div style={{
                  padding: 20, borderRadius: 16,
                  background: "rgba(15,21,37,0.8)",
                  border: "1px solid transparent",
                  backgroundClip: "padding-box",
                  position: "relative",
                }}>
                  <div style={{
                    position: "absolute", inset: 0, borderRadius: 16,
                    background: "linear-gradient(rgba(15,21,37,0.85),rgba(15,21,37,0.85)) padding-box, linear-gradient(135deg,#5BE9FF,#5B8CFF,#9A6BFF,#FF6BD6) border-box",
                    border: "1px solid transparent",
                    pointerEvents: "none",
                  }} />
                  <div style={{ position: "relative", zIndex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 7 }}>
                      <div style={{ width: 14, height: 14, borderRadius: 4, background: AURORA }} />
                      <span style={{ ...AURORA_TEXT, fontSize: 10.5, fontWeight: 700, letterSpacing: "0.09em" }}>AI GENERATED</span>
                    </div>
                    <div style={{ fontSize: 12.5, opacity: 0.65, lineHeight: 1.6 }}>AI 生成内容（调研报告/摘要）的虹彩细描边或左侧角标，用于区分 AI 与人工内容</div>
                  </div>
                </div>

                {/* Primary actions */}
                <div style={{ display: "flex", gap: 12 }}>
                  <button style={{ padding: "11px 26px", borderRadius: 14, background: AURORA, border: "none", color: "white", fontSize: 13.5, fontWeight: 600, cursor: "pointer", boxShadow: "0 4px 22px rgba(91,140,255,0.45)", letterSpacing: "0.01em" }}>
                    主操作 · 虹彩填充
                  </button>
                  <button style={{
                    padding: "11px 24px", borderRadius: 14, fontSize: 13.5, fontWeight: 500, cursor: "pointer",
                    color: "rgba(255,255,255,0.88)", letterSpacing: "0.01em",
                    background: "transparent",
                    border: "1.5px solid transparent",
                    backgroundImage: `linear-gradient(rgba(15,21,37,0.95),rgba(15,21,37,0.95)), ${AURORA}`,
                    backgroundOrigin: "border-box",
                    backgroundClip: "padding-box, border-box",
                  }}>虹彩描边按钮</button>
                </div>
              </div>
            </div>

            {/* Forbidden */}
            <div>
              <Label color="#EF4444">✗ FORBIDDEN · 禁止使用场景（铁律）</Label>
              <GlassCard p={24} r={16} style={{ height: "fit-content" }}>
                {[
                  { bad: "正文段落使用极光渐变色", note: "可读性崩溃，正文≥4.5:1 实色优先" },
                  { bad: "车速/温度/价格等关键数字上虹彩", note: "数值需等宽实色，保证仪表级精密度" },
                  { bad: "玻璃面板背景使用彩虹渐变", note: "面板只用深空色+冷色tint，极光是前景" },
                  { bad: "语义色（涨/跌/警告/危险）虹彩化", note: "语义色须实色，错误语义会危及行车安全" },
                  { bad: "普通功能图标使用极光描边", note: "极光专属AI身份，泛化即失去标识性" },
                  { bad: "极光作为背景、分割线或装饰纹理", note: "滥用导致「廉价彩虹感」，严重拉低品质" },
                ].map((item, i) => (
                  <div key={i} style={{ display: "flex", gap: 12, paddingBottom: 14, marginBottom: 14, borderBottom: i < 5 ? `1px solid ${div}` : "none" }}>
                    <div style={{ color: "#EF4444", fontSize: 16, flexShrink: 0, lineHeight: 1.2 }}>✗</div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 3, textDecoration: "line-through", opacity: 0.65 }}>{item.bad}</div>
                      <div style={{ fontSize: 11.5, opacity: 0.40, lineHeight: 1.55 }}>{item.note}</div>
                    </div>
                  </div>
                ))}
              </GlassCard>
            </div>
          </div>
        </section>

        {/* ════════════════════════════════════════════════════════════ */}
        {/* 04  TYPOGRAPHY                                             */}
        {/* ════════════════════════════════════════════════════════════ */}
        <section style={{ marginBottom: 88 }}>
          <SectionTitle num="04" title="TYPOGRAPHY · 字体排印" sub="HarmonyOS/MiSans 气质现代中文无衬线 + 干净西文 + 仪表级等宽数字，三轴层次" />

          <Label>FONT STACK · 字体族三件套</Label>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 44 }}>
            {[
              { name: "Noto Sans SC", role: "中文正文 · UI 汉字", sample: "智能座舱\n语音助手", sub: "HarmonyOS/MiSans 气质替代方案，300/400/500/700", ff: "'Noto Sans SC',sans-serif" },
              { name: "Inter",         role: "拉丁字符 · UI 英文", sample: "Aurora Glass\nHMI System",  sub: "可变字体，高可读性，14–32px optical sizing",    ff: "'Inter',sans-serif" },
              { name: "JetBrains Mono", role: "仪表数字 · 代码标签", sample: "87.3 km/h\n324 km",    sub: "等宽·精密感·数字优化·车速/温度/价格均用此",  ff: "'JetBrains Mono',monospace" },
            ].map(f => (
              <GlassCard key={f.name} p={24} r={18}>
                <div style={{ fontSize: 10.5, opacity: 0.36, letterSpacing: "0.09em", textTransform: "uppercase", marginBottom: 14 }}>{f.role}</div>
                <div style={{ fontSize: 26, fontWeight: 500, marginBottom: 10, fontFamily: f.ff, whiteSpace: "pre-line", lineHeight: 1.35 }}>{f.sample}</div>
                <div style={{ fontSize: 14, fontWeight: 400, opacity: 0.55, fontFamily: f.ff, marginBottom: 10 }}>{f.name}</div>
                <div style={{ fontSize: 11, opacity: 0.32, lineHeight: 1.6 }}>{f.sub}</div>
              </GlassCard>
            ))}
          </div>

          <Label>TYPE SCALE · 字阶体系</Label>
          <GlassCard p={0} r={20} style={{ overflow: "hidden" }}>
            {[
              { level: "Display",   px: "48px",   w: 700, ls: "-0.03em", usage: "欢迎语·空态大标题",   sample: "你好，小舟",           mono: false },
              { level: "H1",        px: "32px",   w: 600, ls: "-0.02em", usage: "页面主标题",           sample: "智驾导航规划",         mono: false },
              { level: "H2",        px: "24px",   w: 500, ls: "-0.01em", usage: "分区/卡片标题",        sample: "实时路况分析",         mono: false },
              { level: "H3",        px: "18px",   w: 500, ls: "0",       usage: "子项标题",             sample: "续航预测模型",         mono: false },
              { level: "Body",      px: "15px",   w: 400, ls: "0.01em",  usage: "正文·对话气泡",       sample: "当前路段轻度拥堵，建议绕行", mono: false },
              { level: "Caption",   px: "12px",   w: 400, ls: "0.02em",  usage: "标签·辅助·时间戳",   sample: "最后更新 2 分钟前",    mono: false },
              { level: "Mono·Data", px: "32px",   w: 700, ls: "-0.025em", usage: "车速/温度/里程数字", sample: "87.3",                 mono: true  },
              { level: "Mono·SM",   px: "14px",   w: 500, ls: "0",       usage: "小数值·代码标签",    sample: "324 km  /  21°C",      mono: true  },
            ].map((t, i) => (
              <div key={i} style={{
                display: "grid", gridTemplateColumns: "96px 130px 180px 1fr",
                alignItems: "center", padding: "15px 24px",
                borderBottom: i < 7 ? `1px solid ${div}` : "none", gap: 16,
              }}>
                <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10.5, fontWeight: 600, opacity: 0.36, letterSpacing: "0.07em" }}>{t.level}</span>
                <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10.5, opacity: 0.38 }}>{t.px} · {t.w} · {t.ls}</span>
                <span style={{ fontSize: 11, opacity: 0.36 }}>{t.usage}</span>
                <span style={{
                  fontSize: t.px,
                  fontWeight: t.w,
                  letterSpacing: t.ls,
                  fontFamily: t.mono ? "'JetBrains Mono',monospace" : undefined,
                  color: t.mono ? TEAL : fg1,
                  lineHeight: 1.1,
                  overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis",
                }}>{t.sample}</span>
              </div>
            ))}
          </GlassCard>
        </section>

        {/* ════════════════════════════════════════════════════════════ */}
        {/* 05  SPACING · RADIUS · SHADOW                              */}
        {/* ════════════════════════════════════════════════════════════ */}
        <section style={{ marginBottom: 88 }}>
          <SectionTitle num="05" title="SPACING · RADIUS · SHADOW · 间距·圆角·阴影" sub="基于 4px 网格的设计令牌体系，确保跨组件一致节奏" />

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 20 }}>
            {/* Spacing */}
            <div>
              <Label>SPACING · 间距令牌</Label>
              <GlassCard p={22} r={18}>
                {[
                  { t: "4",   v: 4,  desc: "图标内边距" },
                  { t: "8",   v: 8,  desc: "紧凑行内间距" },
                  { t: "12",  v: 12, desc: "同组元素间距" },
                  { t: "16",  v: 16, desc: "卡片内间距" },
                  { t: "24",  v: 24, desc: "卡片内边距" },
                  { t: "32",  v: 32, desc: "区块间距" },
                  { t: "48",  v: 48, desc: "分区间距" },
                  { t: "64",  v: 64, desc: "页面分区" },
                ].map(s => (
                  <div key={s.t} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 11 }}>
                    <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10.5, opacity: 0.40, width: 28 }}>{s.t}</span>
                    <div style={{ width: s.v, height: 7, background: AURORA, borderRadius: 2, flexShrink: 0, opacity: 0.8 }} />
                    <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, opacity: 0.35, width: 28 }}>{s.v}px</span>
                    <span style={{ fontSize: 11, opacity: 0.34 }}>{s.desc}</span>
                  </div>
                ))}
              </GlassCard>
            </div>

            {/* Radius */}
            <div>
              <Label>BORDER RADIUS · 圆角令牌</Label>
              <GlassCard p={22} r={18}>
                {[
                  { t: "sm",   v: 6,    desc: "标签·图标背景" },
                  { t: "md",   v: 10,   desc: "按钮·输入框" },
                  { t: "lg",   v: 14,   desc: "小卡片" },
                  { t: "xl",   v: 18,   desc: "标准卡片" },
                  { t: "2xl",  v: 24,   desc: "主面板(squircle)" },
                  { t: "3xl",  v: 28,   desc: "覆盖层·大卡片" },
                  { t: "full", v: 9999, desc: "胶囊·标签·光球" },
                ].map((r, i) => (
                  <div key={r.t} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 11 }}>
                    <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10.5, opacity: 0.40, width: 36 }}>{r.t}</span>
                    <div style={{
                      width: 36, height: 36, flexShrink: 0,
                      background: i === 6 ? `rgba(70,214,224,0.15)` : "rgba(255,255,255,0.07)",
                      border: "1px solid rgba(255,255,255,0.10)",
                      borderRadius: Math.min(r.v, 18),
                    }} />
                    <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, opacity: 0.35, width: 30 }}>{r.v > 100 ? "∞" : `${r.v}px`}</span>
                    <span style={{ fontSize: 11, opacity: 0.34 }}>{r.desc}</span>
                  </div>
                ))}
              </GlassCard>
            </div>

            {/* Shadow */}
            <div>
              <Label>SHADOW · 阴影令牌</Label>
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {[
                  { name: "glass-sm",    shadow: "0 4px 16px rgba(0,0,0,0.30)",       desc: "小卡片悬浮" },
                  { name: "glass-md",    shadow: "0 8px 32px rgba(0,0,0,0.44)",       desc: "标准卡片" },
                  { name: "glass-lg",    shadow: "0 16px 48px rgba(0,0,0,0.55)",      desc: "主面板·浮层" },
                  { name: "aurora-glow", shadow: "0 0 32px rgba(91,142,255,0.45)",    desc: "AI 光球辉光" },
                  { name: "teal-action", shadow: "0 4px 18px rgba(70,214,224,0.40)",  desc: "交互元素高亮" },
                ].map(s => (
                  <div key={s.name} style={{
                    padding: "16px 18px", borderRadius: 14,
                    background: "rgba(255,255,255,0.045)",
                    boxShadow: s.shadow,
                    border: "1px solid rgba(255,255,255,0.07)",
                  }}>
                    <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 11, opacity: 0.48, marginBottom: 4 }}>{s.name}</div>
                    <div style={{ fontSize: 11.5, opacity: 0.35 }}>{s.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ════════════════════════════════════════════════════════════ */}
        {/* 06  AI AVATAR 小舟                                         */}
        {/* ════════════════════════════════════════════════════════════ */}
        <section style={{ marginBottom: 88 }}>
          <SectionTitle num="06" title='AI AVATAR · "小舟" 全状态展示' sub="液态玻璃光球，内部极光流动；待机慢呼吸·思考极光旋动·说话脉动波纹——设计的记忆点" />

          {/* State switcher */}
          <div style={{ display: "flex", gap: 8, marginBottom: 36 }}>
            {([
              { key: "idle",     label: "待机  Idle" },
              { key: "thinking", label: "思考  Thinking" },
              { key: "speaking", label: "说话  Speaking" },
            ] as { key: OrbState; label: string }[]).map(s => (
              <button key={s.key} onClick={() => setOrbState(s.key)} style={{
                padding: "8px 22px", borderRadius: 22,
                border: `1px solid ${orbState === s.key ? "rgba(91,140,255,0.55)" : "rgba(255,255,255,0.10)"}`,
                background: orbState === s.key ? "rgba(91,140,255,0.14)" : "transparent",
                color: orbState === s.key ? TEAL : fg3,
                fontSize: 13, fontWeight: orbState === s.key ? 600 : 400,
                cursor: "pointer", transition: "all .22s ease",
              }}>{s.label}</button>
            ))}
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1.6fr", gap: 20 }}>
            {/* Live orb stage */}
            <GlassCard p={40} r={24} style={{
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
              minHeight: 360, background: "rgba(8,12,24,0.72)", position: "relative", overflow: "hidden",
            }}>
              <div style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 50% 42%, rgba(91,140,255,0.14) 0%, rgba(154,107,255,0.08) 50%, transparent 75%)", pointerEvents: "none" }} />
              {/* Speaking ripples */}
              {orbState === "speaking" && [1, 2, 3].map(i => (
                <div key={i} style={{
                  position: "absolute", top: "45%", left: "50%",
                  width: 170 + i * 55, height: 170 + i * 55,
                  borderRadius: "50%",
                  border: `1px solid rgba(70,214,224,${0.22 / i})`,
                  animation: `ripple-out ${0.9 + i * 0.28}s ease-out infinite`,
                  pointerEvents: "none",
                }} />
              ))}
              <AuroraOrb state={orbState} size={168} />
              <div style={{ marginTop: 28, textAlign: "center", position: "relative", zIndex: 1 }}>
                <div style={{ fontSize: 22, fontWeight: 500, marginBottom: 6, letterSpacing: "-0.01em" }}>小舟</div>
                <div style={{ fontSize: 12.5, opacity: 0.40 }}>
                  {orbState === "idle" ? "慢呼吸 · 待机" : orbState === "thinking" ? "极光旋动 · 思考中…" : "脉动波纹 · 正在说话"}
                </div>
              </div>
              {/* Thinking edge glow */}
              {orbState === "thinking" && (
                <div style={{
                  position: "absolute", inset: 0, borderRadius: 24,
                  background: "linear-gradient(rgba(8,12,24,0),rgba(8,12,24,0)) padding-box, linear-gradient(135deg,#5BE9FF,#5B8CFF,#9A6BFF,#FF6BD6) border-box",
                  border: "2px solid transparent",
                  animation: "aurora-edge 1.8s ease-in-out infinite",
                  pointerEvents: "none",
                }} />
              )}
            </GlassCard>

            {/* State specs */}
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {[
                {
                  s: "idle" as OrbState,
                  title: "待机 · Idle",
                  color: TEAL,
                  timing: "呼吸 4s / 旋转 8s",
                  desc: "极光缓慢流动，光球轻微呼吸缩放（scale 1.0→1.038）。辉光柔和不打扰驾驶注意力。可朝最近激活内容微倾 ±4° translateX(-6px)，体现「注意力」感知。",
                  specs: ["breathe 4s ease-in-out", "halo-spin 8s linear", "scale: 1.0–1.038", "glow: 1× intensity"],
                },
                {
                  s: "thinking" as OrbState,
                  title: "思考 · Thinking",
                  color: "#9A6BFF",
                  timing: "快速旋转 1.6s / 1.1s",
                  desc: "极光加速旋动，内外层逆向旋转形成漩涡感，整体亮度提升。屏幕四边出现 2px 极光辉光边框，类 Apple Intelligence Siri 激活态。呼吸频率加倍。",
                  specs: ["halo-spin 1.6s linear", "inner-spin 1.1s (反向)", "breathe 1.4s", "border: 2px aurora"],
                },
                {
                  s: "speaking" as OrbState,
                  title: "说话 · Speaking",
                  color: "#FF6BD6",
                  timing: "脉动 0.72s / 波纹扩散",
                  desc: "光球随语音节奏脉动（scale 0.96→1.07），向外扩散三层同心圆波纹。波纹颜色为交互蓝 #46D6E0 而非极光色，保持极光的「AI 专属」克制性。",
                  specs: ["pulse 0.72s ease-in-out", "scale: 0.96–1.07", "ripple 3× teal rings", "glow: 1.35× intensity"],
                },
              ].map(item => (
                <GlassCard key={item.s} p={20} r={18} style={{ border: orbState === item.s ? `1px solid ${item.color}40` : undefined, transition: "border-color .3s ease" }}>
                  <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
                    <div style={{ flexShrink: 0, marginTop: 2 }}><AuroraOrb state={item.s} size={44} /></div>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6, flexWrap: "wrap" }}>
                        <span style={{ fontSize: 14, fontWeight: 600 }}>{item.title}</span>
                        <span style={{ fontSize: 10.5, color: item.color, fontFamily: "'JetBrains Mono',monospace", opacity: 0.82 }}>{item.timing}</span>
                      </div>
                      <p style={{ fontSize: 12, opacity: 0.52, lineHeight: 1.70, margin: "0 0 10px" }}>{item.desc}</p>
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                        {item.specs.map((sp, i) => (
                          <span key={i} style={{ padding: "3px 8px", borderRadius: 6, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", fontSize: 10.5, fontFamily: "'JetBrains Mono',monospace", opacity: 0.58 }}>{sp}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                </GlassCard>
              ))}

              {/* Accessibility / drive mode note */}
              <GlassCard p={18} r={16} style={{ border: "1px solid rgba(245,158,11,0.22)" }}>
                <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                  <span style={{ fontSize: 18, color: "#F59E0B", lineHeight: 1.2, flexShrink: 0 }}>⚠</span>
                  <div>
                    <div style={{ fontSize: 12.5, fontWeight: 600, color: "#F59E0B", marginBottom: 4 }}>行车态 · 车规护栏</div>
                    <div style={{ fontSize: 11.5, opacity: 0.50, lineHeight: 1.65 }}>
                      行驶中降低模糊与辉光 GPU 开销，提高不透明度与对比度。极光更安静（opacity 降 40%，呼吸放慢）。
                      尊重 <code style={{ fontSize: 10.5, opacity: 0.8, fontFamily: "'JetBrains Mono',monospace" }}>prefers-reduced-motion</code> 完全停止动效。
                    </div>
                  </div>
                </div>
              </GlassCard>
            </div>
          </div>
        </section>

        {/* ════════════════════════════════════════════════════════════ */}
        {/* 07  ICON STYLE                                             */}
        {/* ════════════════════════════════════════════════════════════ */}
        <section style={{ marginBottom: 40 }}>
          <SectionTitle num="07" title="ICON STYLE · 图标风格指南" sub="线性 1.8px 描边 · 圆角端点 · 冷色灰阶；交互态填充；AI 时刻极光 linearGradient 描边" />

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20 }}>
            {/* Default state icons */}
            <GlassCard p={24} r={18}>
              <Label>DEFAULT · 默认态（冷色灰 · 1.8px）</Label>
              <div style={{ display: "flex", gap: 18, flexWrap: "wrap", marginBottom: 20 }}>
                {/* Navigation */}
                <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="rgba(255,255,255,0.52)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 3L25 25L14 21L3 25L14 3Z" />
                </svg>
                {/* Music note */}
                <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="rgba(255,255,255,0.52)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="9" cy="20" r="3.5" /><circle cx="21" cy="18" r="3.5" /><path d="M12.5 20V9L24.5 7V18" />
                </svg>
                {/* Phone */}
                <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="rgba(255,255,255,0.52)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 5h5l2.5 6.5-3 2a14 14 0 006 6l2-3L24 19v5a2 2 0 01-2 2C8 31 -2 18 3 5a2 2 0 012 0z" />
                </svg>
                {/* Settings */}
                <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="rgba(255,255,255,0.52)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="14" cy="14" r="3" />
                  <path d="M19.4 9l1.3-2.3-2-2L16.4 6A7 7 0 0014 5a7 7 0 00-2.4.6L9.3 4.3l-2 2L8.6 9A7 7 0 007 12v2a7 7 0 001.6 3l-1.3 2.3 2 2 2.3-1.3A7 7 0 0014 21a7 7 0 002.4-.6l2.3 1.3 2-2L19.4 17A7 7 0 0021 14v-2a7 7 0 00-1.6-3z" />
                </svg>
                {/* AC/Fan */}
                <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="rgba(255,255,255,0.52)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="14" cy="14" r="2.5" />
                  <path d="M14 4c0 5-3 8-8 9" /><path d="M24 14c-5 0-8 3-9 8" />
                  <path d="M14 24c0-5 3-8 8-9" /><path d="M4 14c5 0 8-3 9-8" />
                </svg>
                {/* Battery */}
                <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="rgba(255,255,255,0.52)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="2" y="9" width="20" height="10" rx="3" />
                  <path d="M22 12v4" strokeWidth="2.5" />
                  <rect x="4" y="11" width="10" height="6" rx="1" fill="rgba(255,255,255,0.52)" stroke="none" />
                </svg>
              </div>
              <div style={{ fontSize: 11, opacity: 0.32, lineHeight: 1.7 }}>
                描边 1.8px · strokeLinecap round · 冷白灰 52% opacity<br />
                尺寸: 16 / 20 / 24 / 28 / 36 / 48px
              </div>
            </GlassCard>

            {/* Active state */}
            <GlassCard p={24} r={18}>
              <Label>ACTIVE · 激活态（填充 + 冷蓝底）</Label>
              <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 20 }}>
                {[
                  <svg key="nav" width="28" height="28" viewBox="0 0 28 28" fill={TEAL}><path d="M14 3L25 25L14 21L3 25L14 3Z" /></svg>,
                  <svg key="music" width="28" height="28" viewBox="0 0 28 28" fill="none" stroke={TEAL} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="9" cy="20" r="3.5" fill={`${TEAL}28`} /><circle cx="21" cy="18" r="3.5" fill={`${TEAL}28`} />
                    <path d="M12.5 20V9L24.5 7V18" />
                  </svg>,
                  <svg key="ac" width="28" height="28" viewBox="0 0 28 28" fill="none" stroke={TEAL} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="14" cy="14" r="2.5" fill={`${TEAL}30`} />
                    <path d="M14 4c0 5-3 8-8 9" /><path d="M24 14c-5 0-8 3-9 8" />
                    <path d="M14 24c0-5 3-8 8-9" /><path d="M4 14c5 0 8-3 9-8" />
                  </svg>,
                ].map((icon, i) => (
                  <div key={i} style={{ padding: 8, borderRadius: 10, background: `${TEAL}14`, border: `1px solid ${TEAL}28`, boxShadow: `0 0 14px ${TEAL}1A` }}>{icon}</div>
                ))}
              </div>
              <div style={{ fontSize: 11, opacity: 0.32, lineHeight: 1.7 }}>
                实色 #46D6E0 填充 · 浅色背景底<br />
                柔和投影 0 0 14px rgba(70,214,224,0.1)
              </div>

              <div style={{ marginTop: 20, paddingTop: 18, borderTop: `1px solid ${div}` }}>
                <Label>SIZE GUIDE · 尺寸规范</Label>
                {[
                  { size: 16, token: "xs", use: "标签内图标" },
                  { size: 20, token: "sm", use: "按钮前置图标" },
                  { size: 24, token: "md", use: "导航栏图标" },
                  { size: 28, token: "lg", use: "卡片功能图标" },
                  { size: 36, token: "xl", use: "主功能入口" },
                  { size: 48, token: "2xl", use: "空状态·欢迎页" },
                ].map(s => (
                  <div key={s.size} style={{ display: "flex", gap: 10, marginBottom: 7, alignItems: "center" }}>
                    <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, opacity: 0.36, width: 46 }}>{s.size}px</span>
                    <div style={{ width: s.size, height: s.size, borderRadius: 4, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.09)", flexShrink: 0 }} />
                    <span style={{ fontSize: 11, opacity: 0.32 }}>{s.use}</span>
                  </div>
                ))}
              </div>
            </GlassCard>

            {/* AI moment */}
            <GlassCard p={24} r={18}>
              <Label color="#9A6BFF">AI MOMENT · AI 时刻（极光 linearGradient 描边）</Label>
              <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 20 }}>
                {/* Microphone — AI listening */}
                <div style={{ padding: 10, borderRadius: 12, background: "linear-gradient(135deg,rgba(91,233,255,0.10),rgba(154,107,255,0.10))", border: "1px solid rgba(91,233,255,0.28)" }}>
                  <svg width="28" height="28" viewBox="0 0 28 28" fill="none" strokeLinecap="round" strokeLinejoin="round">
                    <defs>
                      <linearGradient id="ag1" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor="#5BE9FF" /><stop offset="50%" stopColor="#9A6BFF" /><stop offset="100%" stopColor="#FF6BD6" />
                      </linearGradient>
                    </defs>
                    <rect x="10" y="3" width="8" height="14" rx="4" stroke="url(#ag1)" strokeWidth="1.8" />
                    <path d="M5 14c0 5 4 9 9 9s9-4 9-9" stroke="url(#ag1)" strokeWidth="1.8" />
                    <line x1="14" y1="23" x2="14" y2="26" stroke="url(#ag1)" strokeWidth="1.8" />
                  </svg>
                </div>
                {/* Sparkle — AI generate */}
                <div style={{ padding: 10, borderRadius: 12, background: "linear-gradient(135deg,rgba(91,233,255,0.10),rgba(154,107,255,0.10))", border: "1px solid rgba(154,107,255,0.28)" }}>
                  <svg width="28" height="28" viewBox="0 0 28 28" fill="none" strokeLinecap="round" strokeLinejoin="round">
                    <defs>
                      <linearGradient id="ag2" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor="#5B8CFF" /><stop offset="100%" stopColor="#FF6BD6" />
                      </linearGradient>
                    </defs>
                    <path d="M14 3l2.5 8.5L25 14l-8.5 2.5L14 25l-2.5-8.5L3 14l8.5-2.5L14 3z" stroke="url(#ag2)" strokeWidth="1.8" />
                  </svg>
                </div>
              </div>
              <div style={{ fontSize: 12, opacity: 0.50, lineHeight: 1.70, marginBottom: 16 }}>
                仅 AI 触发图标（麦克风·星形·生成）使用极光 SVG linearGradient 描边。
                普通功能图标（导航、音乐、空调）严禁使用极光渐变。
              </div>
              <div style={{ borderTop: `1px solid ${div}`, paddingTop: 16 }}>
                <Label>ANIMATION · 图标动效</Label>
                {[
                  { name: "hover",    rule: "scale(1.08) · 120ms ease" },
                  { name: "pressed",  rule: "scale(0.94) · 80ms ease" },
                  { name: "AI pulse", rule: "opacity 0.8→1.0 · 1.2s breathe" },
                  { name: "active",   rule: "fill 从灰→蓝 · 200ms ease" },
                ].map((a, i) => (
                  <div key={i} style={{ display: "flex", gap: 10, marginBottom: 8, alignItems: "baseline" }}>
                    <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, opacity: 0.36, width: 60, flexShrink: 0 }}>{a.name}</span>
                    <span style={{ fontSize: 11.5, opacity: 0.50 }}>{a.rule}</span>
                  </div>
                ))}
              </div>
            </GlassCard>
          </div>
        </section>

        {/* ── FOOTER ────────────────────────────────────────────────── */}
        <footer style={{ paddingTop: 44, borderTop: `1px solid ${div}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 22, height: 22 }}><AuroraOrb state="idle" size={22} /></div>
            <span style={{ fontSize: 12, opacity: 0.32 }}>Aurora Glass · 极光液态座舱 · Design System v1.0</span>
          </div>
          <div style={{ display: "flex", gap: 20 }}>
            {["色彩系统", "玻璃材质", "极光用法", "字体排印", "间距令牌", "AI 光球", "图标风格"].map((item, i) => (
              <span key={i} style={{ fontSize: 11, opacity: 0.22 }}>{`0${i + 1} ${item}`}</span>
            ))}
          </div>
        </footer>

      </div>
    </div>
  );
}
