// Design contract: guidelines/Guidelines.md
// Page: A-2 Hero · 泊车态主屏 1920×1080
// Reused: AuroraOrb, GlassCard, AURORA, AURORA_CONIC, AURORA_TEXT, TEAL, KEYFRAMES
// New for A-2: StatusBar, ConversationPanel, ContextStage, InputBar, WeatherStageCard

import { useState, useMemo, CSSProperties, ReactNode } from "react";
import { Volume2, VolumeX, Settings, Send, Mic } from "lucide-react";

// ─── Aurora Glass · Design Tokens (§3 Guidelines.md) ─────────────────────────
const AURORA      = "linear-gradient(135deg, #5BE9FF 0%, #5B8CFF 33%, #9A6BFF 66%, #FF6BD6 100%)";
const AURORA_CONIC = "conic-gradient(from 0deg, #5BE9FF, #5B8CFF, #9A6BFF, #FF6BD6, #5BE9FF)";
const AURORA_TEXT: CSSProperties = {
  background: AURORA,
  WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent",
  backgroundClip: "text",
};
const TEAL = "#46D6E0";
const FG1  = "rgba(255,255,255,0.92)";
const FG2  = "rgba(255,255,255,0.56)";
const FG3  = "rgba(255,255,255,0.32)";
const DIV  = "rgba(255,255,255,0.07)";

// ─── Keyframes (§8 z-index, §10 orb animations) ──────────────────────────────
const KEYFRAMES = `
  @keyframes aurora-breathe {
    0%, 100% { opacity: 0.82; transform: scale(1); }
    50%       { opacity: 1;    transform: scale(1.038); }
  }
  @keyframes aurora-breathe-fast {
    0%, 100% { opacity: 0.85; transform: scale(1); }
    50%       { opacity: 1;    transform: scale(1.045); }
  }
  @keyframes aurora-spin {
    from { transform: rotate(0deg); }
    to   { transform: rotate(360deg); }
  }
  @keyframes aurora-spin-r {
    from { transform: rotate(360deg); }
    to   { transform: rotate(0deg); }
  }
  @keyframes aurora-pulse {
    0%, 100% { transform: scale(1);    opacity: 0.86; }
    25%       { transform: scale(1.07); opacity: 1; }
    75%       { transform: scale(0.96); opacity: 0.80; }
  }
  @keyframes aurora-edge {
    0%, 100% { opacity: 0.35; }
    50%       { opacity: 0.72; }
  }
  @keyframes shimmer-lr {
    0%   { transform: translateX(-120%); }
    100% { transform: translateX(220%); }
  }
  @keyframes ripple-out {
    0%   { transform: translate(-50%, -50%) scale(0.85); opacity: 0.5; }
    100% { transform: translate(-50%, -50%) scale(1.6);  opacity: 0; }
  }
  @keyframes rain-fall {
    0%   { transform: translateY(-28px) translateX(0); opacity: 0; }
    8%   { opacity: 1; }
    88%  { opacity: 0.65; }
    100% { transform: translateY(340px) translateX(-6px); opacity: 0; }
  }
  @keyframes cloud-float {
    0%,100% { transform: translateX(0) translateY(0); }
    40%     { transform: translateX(14px) translateY(-7px); }
    70%     { transform: translateX(-9px) translateY(5px); }
  }
  @keyframes cloud-float-2 {
    0%,100% { transform: translateX(0) translateY(0); }
    50%     { transform: translateX(-18px) translateY(8px); }
  }
  @keyframes temp-float {
    0%,100% { transform: translateY(0); }
    50%     { transform: translateY(-10px); }
  }
  @keyframes aurora-edge-pulse {
    0%,100% { opacity: 0.22; }
    50%     { opacity: 0.55; }
  }
  * { scrollbar-width: none; }
  *::-webkit-scrollbar { display: none; }
  input::placeholder { color: rgba(255,255,255,0.28); }
  @media (prefers-reduced-motion: reduce) {
    * { animation-duration: 0.01ms !important; }
  }
`;

// ─── AuroraOrb — §9 Component, §10 Three States ──────────────────────────────
type OrbState = "idle" | "thinking" | "speaking";

function AuroraOrb({ state = "idle", size = 140 }: { state?: OrbState; size?: number }) {
  const thinking  = state === "thinking";
  const speaking  = state === "speaking";
  const glowMult  = speaking ? 1.35 : 1;
  const outerAnim = thinking ? "aurora-breathe-fast 1.4s ease-in-out infinite"
                  : speaking  ? "aurora-pulse 0.72s ease-in-out infinite"
                  :             "aurora-breathe 4s ease-in-out infinite";
  const haloSpeed  = thinking ? "1.6s" : "8s";
  const innerSpeed = thinking ? "1.1s" : "5s";
  const ctSpeed    = thinking ? "0.8s" : "3.8s";
  const s = size;

  return (
    <div style={{ position: "relative", width: s, height: s, flexShrink: 0 }}>
      <div style={{ position: "absolute", inset: -s*0.52, borderRadius: "50%", background: `radial-gradient(circle,rgba(91,140,255,${0.20*glowMult}) 0%,rgba(154,107,255,${0.11*glowMult}) 40%,transparent 70%)`, animation: outerAnim, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: -s*0.06, borderRadius: "50%", background: AURORA_CONIC, opacity: thinking ? 0.52 : 0.26, filter: `blur(${s*0.115}px)`, animation: `aurora-spin ${haloSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: 0, borderRadius: "50%", background: `radial-gradient(circle at 36% 28%,rgba(255,255,255,0.44) 0%,rgba(91,233,255,0.22) 28%,rgba(91,140,255,0.18) 56%,rgba(154,107,255,0.26) 78%,rgba(255,107,214,0.14) 100%)`, backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)", border: "1px solid rgba(255,255,255,0.24)", boxShadow: `0 0 ${s*0.32*glowMult}px rgba(91,142,255,0.52),0 0 ${s*0.70*glowMult}px rgba(154,107,255,0.22),inset 0 0 ${s*0.24}px rgba(91,233,255,0.20),inset 0 ${s*0.012}px 0 rgba(255,255,255,0.34)`, animation: outerAnim, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: s*0.16, borderRadius: "50%", background: AURORA_CONIC, opacity: 0.70, filter: `blur(${s*0.036}px)`, animation: `aurora-spin ${innerSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: s*0.28, borderRadius: "50%", background: `conic-gradient(from 180deg,#9A6BFF,#5B8CFF,#5BE9FF,#FF6BD6,#9A6BFF)`, opacity: 0.54, filter: `blur(${s*0.028}px)`, animation: `aurora-spin-r ${ctSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", top: "9%", left: "13%", width: "44%", height: "33%", borderRadius: "50%", background: "radial-gradient(ellipse,rgba(255,255,255,0.70) 0%,transparent 100%)", filter: "blur(2px)", pointerEvents: "none" }} />
      <div style={{ position: "absolute", bottom: "11%", right: "14%", width: "26%", height: "19%", borderRadius: "50%", background: "radial-gradient(ellipse,rgba(255,107,214,0.48) 0%,transparent 100%)", filter: "blur(3px)", pointerEvents: "none" }} />
    </div>
  );
}

// ─── GlassCard — §6 Liquid Glass Material ────────────────────────────────────
function GlassCard({
  children, p = 24, r = 24, light = false, style,
}: {
  children?: ReactNode; p?: number; r?: number; light?: boolean; style?: CSSProperties;
}) {
  return (
    <div style={{
      padding: p, borderRadius: r,
      background: light ? "rgba(255,255,255,0.76)" : "rgba(255,255,255,0.056)",
      backdropFilter: "blur(32px)", WebkitBackdropFilter: "blur(32px)",
      border: light ? "1px solid rgba(255,255,255,0.95)" : "1px solid rgba(255,255,255,0.10)",
      borderTop:  light ? "1px solid rgba(255,255,255,1)"    : "1px solid rgba(255,255,255,0.18)",
      borderLeft: light ? "1px solid rgba(255,255,255,1)"    : "1px solid rgba(255,255,255,0.14)",
      boxShadow:  light
        ? "0 8px 32px rgba(10,14,26,0.09),0 2px 8px rgba(10,14,26,0.05),inset 0 1px 0 rgba(255,255,255,1)"
        : "0 8px 40px rgba(0,0,0,0.50),0 2px 12px rgba(0,0,0,0.28),inset 0 1px 0 rgba(255,255,255,0.13)",
      ...style,
    }}>
      {children}
    </div>
  );
}

// ─── Divider ──────────────────────────────────────────────────────────────────
const HR = () => <div style={{ height: 1, background: DIV }} />;

// ─── IconBtn (status bar controls) ───────────────────────────────────────────
function IconBtn({ onClick, active = false, children }: { onClick?: () => void; active?: boolean; children: ReactNode }) {
  return (
    <button onClick={onClick} style={{
      width: 36, height: 36, borderRadius: 10, flexShrink: 0,
      background: active ? "rgba(70,214,224,.12)" : "rgba(255,255,255,.055)",
      border: `1px solid ${active ? "rgba(70,214,224,.28)" : "rgba(255,255,255,.09)"}`,
      display: "flex", alignItems: "center", justifyContent: "center",
      cursor: "pointer", transition: "all .2s ease",
    }}>
      {children}
    </button>
  );
}

// ─── A-2 · App export ────────────────────────────────────────────────────────
export default function App() {
  const [voiceOn,    setVoiceOn]    = useState(true);
  const [input,      setInput]      = useState("");
  const [activeChip, setActiveChip] = useState<number | null>(null);

  const CHIPS = ["打开空调 26°", "附近的充电站", "导航去公司", "今天限行吗", "讲个笑话"];

  // Memoised rain — stable across renders (§11 can GPU-budget for parking mode)
  const rain = useMemo(() =>
    Array.from({ length: 24 }, (_, i) => ({
      id: i,
      x:     Math.random() * 98,
      h:     14 + Math.random() * 10,
      delay: Math.random() * 3.5,
      dur:   1.1  + Math.random() * 0.9,
      op:    0.28 + Math.random() * 0.38,
    })), []);

  const handleSend = () => { if (input.trim()) setInput(""); };

  const selectChip = (i: number) => {
    const same = i === activeChip;
    setActiveChip(same ? null : i);
    setInput(same ? "" : CHIPS[i]);
  };

  return (
    <div style={{
      width: "100vw", height: "100vh", overflow: "hidden", position: "relative",
      fontFamily: "'Inter','Noto Sans SC',-apple-system,sans-serif",
      color: FG1,
      background: "linear-gradient(158deg,#06080F 0%,#0A0E1A 55%,#080D18 100%)",
    }}>
      <style>{KEYFRAMES}</style>

      {/* ── Layer 0: Living scene atmosphere (§2 z-0) ─────────────────────── */}
      <div aria-hidden style={{ position: "absolute", inset: 0, pointerEvents: "none", zIndex: 0 }}>
        {/* Aurora blobs */}
        <div style={{ position: "absolute", bottom: "10%", left: "20%",  width: 680, height: 480, background: "radial-gradient(circle,rgba(91,140,255,.13) 0%,transparent 68%)", filter: "blur(48px)" }} />
        <div style={{ position: "absolute", top: "6%",    right: "12%", width: 520, height: 380, background: "radial-gradient(circle,rgba(91,233,255,.09) 0%,transparent 68%)", filter: "blur(56px)" }} />
        <div style={{ position: "absolute", top: "30%",   left: "42%",  width: 760, height: 540, background: "radial-gradient(circle,rgba(154,107,255,.07) 0%,transparent 68%)", filter: "blur(64px)" }} />
        {/* Ground scrim — protects text from bare map (§11) */}
        <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 320, background: "linear-gradient(to top,rgba(6,8,15,.70),transparent)" }} />
        {/* Sparse star field */}
        {Array.from({ length: 28 }, (_, i) => (
          <div key={i} style={{ position: "absolute", top: `${(i * 37 + 11) % 62}%`, left: `${(i * 53 + 7) % 100}%`, width: i % 4 === 0 ? 2 : 1, height: i % 4 === 0 ? 2 : 1, borderRadius: "50%", background: "white", opacity: 0.07 + (i % 3) * 0.05 }} />
        ))}
      </div>

      {/* ── TOP STATUS BAR (z-30) ─────────────────────────────────────────── */}
      <header style={{
        position: "absolute", top: 0, left: 0, right: 0, height: 58, zIndex: 30,
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "0 28px",
        background: "rgba(6,8,15,.76)",
        backdropFilter: "blur(28px)", WebkitBackdropFilter: "blur(28px)",
        borderBottom: `1px solid ${DIV}`,
      }}>
        {/* Left: brand + name + status badges */}
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ width: 32, height: 32 }}>
            <AuroraOrb state="idle" size={32} />
          </div>
          <span style={{ fontSize: 16, fontWeight: 600, letterSpacing: "-.01em" }}>小舟</span>
          <div style={{ width: 1, height: 18, background: "rgba(255,255,255,.10)" }} />
          {/* Online */}
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ width: 7, height: 7, borderRadius: "50%", background: "#34D399", boxShadow: "0 0 7px #34D399" }} />
            <span style={{ fontSize: 12.5, color: "#34D399", fontWeight: 500 }}>在线</span>
          </div>
          {/* Mode */}
          <div style={{ padding: "3px 11px", borderRadius: 20, background: "rgba(70,214,224,.10)", border: "1px solid rgba(70,214,224,.22)" }}>
            <span style={{ fontSize: 12, color: TEAL, fontWeight: 500 }}>自动</span>
          </div>
        </div>

        {/* Right: time + controls */}
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 12.5, color: FG3 }}>周六 · 6月29日</span>
          <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 20, fontWeight: 600, letterSpacing: ".03em" }}>17:42</span>
          <div style={{ width: 1, height: 18, background: "rgba(255,255,255,.10)" }} />
          <IconBtn onClick={() => setVoiceOn(v => !v)} active={voiceOn}>
            {voiceOn
              ? <Volume2 size={15} color={TEAL} />
              : <VolumeX size={15} color="rgba(255,255,255,.40)" />}
          </IconBtn>
          <IconBtn>
            <Settings size={15} color="rgba(255,255,255,.48)" />
          </IconBtn>
        </div>
      </header>

      {/* ── LEFT CONVERSATION PANEL (z-10, Layer 1) ──────────────────────── */}
      <div style={{
        position: "absolute",
        top: 66, left: 20, width: 452, bottom: 148,
        zIndex: 10,
      }}>
        <GlassCard p={0} r={24} style={{ height: "100%", display: "flex", flexDirection: "column", overflow: "hidden" }}>

          {/* Panel header */}
          <div style={{ padding: "15px 20px", borderBottom: `1px solid ${DIV}`, display: "flex", alignItems: "center", gap: 11, flexShrink: 0 }}>
            <div style={{ width: 38, height: 38 }}><AuroraOrb state="idle" size={38} /></div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600, lineHeight: 1.2 }}>小舟</div>
              <div style={{ fontSize: 11, color: FG3 }}>AI 智能助手 · 对话</div>
            </div>
            <span style={{ fontSize: 11, color: FG3 }}>今天 17:41</span>
          </div>

          {/* Message list */}
          <div style={{ flex: 1, padding: "18px 16px", display: "flex", flexDirection: "column", gap: 18, overflowY: "auto" }}>

            {/* System pill */}
            <div style={{ textAlign: "center" }}>
              <span style={{ fontSize: 11, color: FG3, padding: "4px 12px", borderRadius: 20, background: "rgba(255,255,255,.04)" }}>
                泊车模式 · 已停车
              </span>
            </div>

            {/* ── User bubble ── */}
            <div style={{ display: "flex", justifyContent: "flex-end" }}>
              <div style={{
                maxWidth: "84%", padding: "12px 16px",
                borderRadius: "18px 18px 4px 18px",
                background: "rgba(70,214,224,.12)",
                border: "1px solid rgba(70,214,224,.22)",
                backdropFilter: "blur(16px)", WebkitBackdropFilter: "blur(16px)",
                boxShadow: "0 4px 18px rgba(0,0,0,.24)",
              }}>
                <div style={{ fontSize: 14.5, lineHeight: 1.65, color: FG1 }}>今天杭州天气怎么样</div>
                <div style={{ fontSize: 10.5, color: FG3, marginTop: 6, textAlign: "right" }}>17:41</div>
              </div>
            </div>

            {/* ── AI bubble + weather card ── */}
            <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
              <div style={{ width: 30, height: 30, flexShrink: 0, marginTop: 2 }}>
                <AuroraOrb state="idle" size={30} />
              </div>
              <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 10 }}>

                {/* Response text */}
                <div style={{
                  padding: "14px 16px",
                  borderRadius: "4px 18px 18px 18px",
                  background: "rgba(255,255,255,.062)",
                  border: "1px solid rgba(255,255,255,.09)",
                  borderTop: "1px solid rgba(255,255,255,.16)",
                  backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
                  boxShadow: "0 4px 20px rgba(0,0,0,.30),inset 0 1px 0 rgba(255,255,255,.10)",
                  position: "relative", overflow: "hidden",
                }}>
                  {/* Shimmer sweep — AI流式微光 (§5 allowed) */}
                  <div style={{ position: "absolute", inset: 0, width: "28%", background: "linear-gradient(90deg,transparent,rgba(91,233,255,.06),transparent)", animation: "shimmer-lr 3.2s ease-in-out infinite", pointerEvents: "none" }} />
                  <p style={{ fontSize: 14.5, lineHeight: 1.72, margin: 0, color: FG1, position: "relative" }}>
                    杭州今天<strong style={{ fontWeight: 600, color: "rgba(255,255,255,.96)" }}>多云 28℃</strong>，体感偏闷，傍晚有阵雨，出门带把伞 ☂️
                  </p>
                  <div style={{ fontSize: 10.5, color: FG3, marginTop: 8, position: "relative" }}>17:41 · 小舟</div>
                </div>

                {/* ── Weather card placeholder ── */}
                <div style={{
                  padding: "14px 16px", borderRadius: 18,
                  background: "rgba(91,140,255,.08)",
                  border: "1px solid rgba(91,140,255,.18)",
                  borderTop: "1px solid rgba(91,140,255,.26)",
                  backdropFilter: "blur(24px)", WebkitBackdropFilter: "blur(24px)",
                  boxShadow: "0 4px 20px rgba(0,0,0,.22),inset 0 1px 0 rgba(255,255,255,.07)",
                }}>
                  {/* Icon + temp + condition */}
                  <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 12 }}>
                    <span style={{ fontSize: 36, lineHeight: 1 }}>⛅</span>
                    <div>
                      <div style={{ display: "flex", alignItems: "baseline", gap: 5, marginBottom: 2 }}>
                        <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 30, fontWeight: 700, color: FG1, lineHeight: 1 }}>28</span>
                        <span style={{ fontSize: 15, color: FG2, fontWeight: 300 }}>°C</span>
                        <span style={{ fontSize: 13, color: FG2, marginLeft: 4 }}>多云转阵雨</span>
                      </div>
                      <div style={{ fontSize: 11.5, color: FG3 }}>杭州 · 傍晚起阵雨 · 18°–29°</div>
                    </div>
                  </div>
                  {/* Quick stats (A-3 细化占位) */}
                  <div style={{ display: "flex" }}>
                    {[
                      { l: "湿度",   v: "65%"  },
                      { l: "东南风", v: "3级"  },
                      { l: "能见度", v: "24km" },
                      { l: "降水概率", v: "65%" },
                    ].map((s, i) => (
                      <div key={i} style={{ flex: 1, textAlign: "center", padding: "6px 0", borderRight: i < 3 ? `1px solid ${DIV}` : "none" }}>
                        <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 13, fontWeight: 600, color: FG1 }}>{s.v}</div>
                        <div style={{ fontSize: 10.5, color: FG3, marginTop: 2 }}>{s.l}</div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* ── RIGHT CONTEXT STAGE — Weather Scene (z-5) ────────────────────── */}
      <div style={{
        position: "absolute",
        top: 66, left: 490, right: 20, bottom: 148,
        zIndex: 5, overflow: "hidden", borderRadius: 24,
      }}>
        {/* Stage glass edge */}
        <div style={{ position: "absolute", inset: 0, borderRadius: 24, border: "1px solid rgba(255,255,255,.06)", pointerEvents: "none", zIndex: 10 }} />
        {/* Aurora border — AI context active (§5 allowed: AI moment) */}
        <div style={{
          position: "absolute", inset: 0, borderRadius: 24,
          background: "linear-gradient(rgba(0,0,0,0),rgba(0,0,0,0)) padding-box, linear-gradient(135deg,#5BE9FF,#5B8CFF,#9A6BFF,#FF6BD6) border-box",
          border: "1.5px solid transparent",
          opacity: .22,
          animation: "aurora-edge-pulse 3.5s ease-in-out infinite",
          pointerEvents: "none", zIndex: 11,
        }} />

        {/* Rain drops */}
        <div style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none", zIndex: 2 }}>
          {rain.map(d => (
            <div key={d.id} style={{
              position: "absolute",
              left: `${d.x}%`, top: 0,
              width: 1.5, height: d.h, borderRadius: 1,
              background: `linear-gradient(to bottom,transparent,rgba(70,214,224,${d.op}))`,
              animation: `rain-fall ${d.dur}s ${d.delay}s linear infinite`,
            }} />
          ))}
        </div>

        {/* Cloud #1 — large, back */}
        <div style={{ position: "absolute", top: "6%", left: "10%", width: "58%", opacity: .28, animation: "cloud-float 10s ease-in-out infinite", pointerEvents: "none", zIndex: 1 }}>
          <svg viewBox="0 0 520 220" fill="none">
            <path d="M90,165 Q110,90 185,84 Q205,18 310,38 Q378,10 400,84 Q478,78 488,155 Q498,198 442,202 L140,202 Q52,202 65,162 Z" fill="rgba(140,175,255,0.14)" />
          </svg>
        </div>

        {/* Cloud #2 — smaller, right */}
        <div style={{ position: "absolute", top: "32%", right: "8%", width: "28%", opacity: .18, animation: "cloud-float-2 14s ease-in-out infinite", pointerEvents: "none", zIndex: 1 }}>
          <svg viewBox="0 0 300 140" fill="none">
            <path d="M40,100 Q58,55 106,54 Q118,18 175,32 Q218,14 234,54 Q282,48 288,95 Q292,120 262,126 L68,126 Q18,126 30,100 Z" fill="rgba(140,175,255,0.12)" />
          </svg>
        </div>

        {/* Main weather display — centred, floating */}
        <div style={{
          position: "absolute", top: "50%", left: "50%",
          transform: "translate(-50%,-54%)",
          textAlign: "center",
          animation: "temp-float 7s ease-in-out infinite",
          zIndex: 3,
        }}>
          {/* City */}
          <div style={{ fontSize: 15, fontWeight: 300, letterSpacing: "0.55em", color: FG2, marginBottom: 14, textTransform: "uppercase" }}>杭 州</div>

          {/* Giant temperature — JetBrains Mono (§7 数字排印铁律) */}
          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "center", gap: 6, marginBottom: 18 }}>
            <span style={{
              fontFamily: "'JetBrains Mono',monospace",
              fontSize: "clamp(100px,11vw,148px)",
              fontWeight: 700, letterSpacing: "-0.04em", lineHeight: 1,
              color: "rgba(255,255,255,.94)",
              textShadow: "0 0 80px rgba(91,233,255,.12),0 0 120px rgba(91,140,255,.08)",
            }}>28</span>
            <span style={{
              fontFamily: "'JetBrains Mono',monospace",
              fontSize: "clamp(28px,3vw,40px)",
              fontWeight: 300, color: FG2, marginTop: "1.1em",
            }}>°C</span>
          </div>

          {/* Condition row */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 14, marginBottom: 32 }}>
            <span style={{ fontSize: "clamp(36px,4vw,52px)", lineHeight: 1 }}>⛅</span>
            <div style={{ textAlign: "left" }}>
              <div style={{ fontSize: "clamp(18px,1.8vw,24px)", fontWeight: 500, letterSpacing: ".02em" }}>多云转阵雨</div>
              <div style={{ fontSize: 13, color: FG3, marginTop: 4 }}>傍晚起有阵雨 · 能见度 24km</div>
            </div>
          </div>

          {/* Quick stat chips */}
          <div style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" }}>
            {[
              { icon: "💧",  label: "湿度",    value: "65%"    },
              { icon: "🌬️", label: "风速",    value: "东南 3级" },
              { icon: "🌿",  label: "空气质量", value: "良 68"  },
              { icon: "☀️", label: "UV 指数", value: "3 低"   },
            ].map(s => (
              <div key={s.label} style={{
                padding: "10px 18px", borderRadius: 18, textAlign: "center", minWidth: 88,
                background: "rgba(255,255,255,.05)",
                backdropFilter: "blur(24px)", WebkitBackdropFilter: "blur(24px)",
                border: "1px solid rgba(255,255,255,.09)",
                borderTop: "1px solid rgba(255,255,255,.14)",
                boxShadow: "0 4px 16px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.08)",
              }}>
                <div style={{ fontSize: 20, marginBottom: 5 }}>{s.icon}</div>
                <div style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 13.5, fontWeight: 600, color: FG1, marginBottom: 3 }}>{s.value}</div>
                <div style={{ fontSize: 11, color: FG3 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom info strip */}
        <div style={{ position: "absolute", bottom: 20, left: "50%", transform: "translateX(-50%)", zIndex: 4 }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 20,
            padding: "10px 28px", borderRadius: 30,
            background: "rgba(6,8,15,.55)",
            backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
            border: "1px solid rgba(255,255,255,.08)",
            boxShadow: "0 4px 20px rgba(0,0,0,.40)",
            whiteSpace: "nowrap",
          }}>
            {/* Temp range */}
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 11.5, color: FG3 }}>今日</span>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 13, color: "#93C5FD" }}>18°</span>
              <div style={{ width: 56, height: 3, borderRadius: 2, background: "linear-gradient(to right,rgba(91,140,255,.55),rgba(255,165,50,.55))" }} />
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 13, color: "#FCA5A5" }}>29°</span>
            </div>
            <div style={{ width: 1, height: 16, background: "rgba(255,255,255,.09)" }} />
            <div style={{ display: "flex", gap: 7, alignItems: "center" }}>
              <span style={{ fontSize: 11.5, color: FG3 }}>降水概率</span>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 13, color: TEAL }}>65%</span>
            </div>
            <div style={{ width: 1, height: 16, background: "rgba(255,255,255,.09)" }} />
            <div style={{ display: "flex", gap: 7, alignItems: "center" }}>
              <span style={{ fontSize: 11.5, color: FG3 }}>空气质量</span>
              <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 13, color: "#A3E635" }}>良 · 68</span>
            </div>
            <div style={{ width: 1, height: 16, background: "rgba(255,255,255,.09)" }} />
            <div style={{ display: "flex", gap: 7, alignItems: "center" }}>
              <span style={{ fontSize: 14 }}>☂️</span>
              <span style={{ fontSize: 12, color: FG2 }}>建议带伞</span>
            </div>
          </div>
        </div>
      </div>

      {/* ── BOTTOM INPUT AREA (z-20) ──────────────────────────────────────── */}
      <div style={{
        position: "absolute", bottom: 0, left: 0, right: 0, height: 140, zIndex: 20,
        background: "rgba(6,8,15,.82)",
        backdropFilter: "blur(32px)", WebkitBackdropFilter: "blur(32px)",
        borderTop: `1px solid ${DIV}`,
        padding: "12px 24px 20px",
        display: "flex", flexDirection: "column", gap: 11,
      }}>

        {/* Chip rail */}
        <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 1 }}>
          {CHIPS.map((chip, i) => (
            <button
              key={i}
              onClick={() => selectChip(i)}
              style={{
                flexShrink: 0, padding: "7px 16px", borderRadius: 20, cursor: "pointer",
                background: activeChip === i ? "rgba(70,214,224,.14)" : "rgba(255,255,255,.054)",
                border: `1px solid ${activeChip === i ? "rgba(70,214,224,.32)" : "rgba(255,255,255,.09)"}`,
                color: activeChip === i ? TEAL : FG2,
                fontSize: 13, fontWeight: activeChip === i ? 500 : 400,
                whiteSpace: "nowrap", transition: "all .18s ease",
                fontFamily: "'Inter','Noto Sans SC',sans-serif",
              }}>
              {chip}
            </button>
          ))}
        </div>

        {/* Input row */}
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>

          {/* Mic orb button — AuroraOrb idle state (§10) */}
          <button style={{
            width: 52, height: 52, flexShrink: 0, borderRadius: 15, cursor: "pointer",
            background: "rgba(255,255,255,.05)",
            border: "1px solid rgba(255,255,255,.09)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <div style={{ width: 40, height: 40 }}>
              <AuroraOrb state="idle" size={40} />
            </div>
          </button>

          {/* Text input */}
          <div style={{ flex: 1, position: "relative" }}>
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleSend()}
              placeholder="发送消息，或说出你的需求…"
              style={{
                width: "100%", height: 52, boxSizing: "border-box",
                paddingLeft: 20, paddingRight: 52,
                borderRadius: 15,
                background: "rgba(255,255,255,.058)",
                backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
                border: "1px solid rgba(255,255,255,.10)",
                borderTop: "1px solid rgba(255,255,255,.17)",
                boxShadow: "inset 0 1px 0 rgba(255,255,255,.08),0 4px 16px rgba(0,0,0,.22)",
                color: FG1, fontSize: 14,
                fontFamily: "'Inter','Noto Sans SC',sans-serif",
                outline: "none", caretColor: TEAL,
              }}
            />
            <div style={{ position: "absolute", right: 16, top: "50%", transform: "translateY(-50%)", opacity: input ? 0 : .22, transition: "opacity .2s", pointerEvents: "none" }}>
              <Mic size={16} color="white" />
            </div>
          </div>

          {/* Send button — aurora fill when active (§5 allowed: main action) */}
          <button
            onClick={handleSend}
            style={{
              width: 52, height: 52, flexShrink: 0, borderRadius: 15, cursor: input.trim() ? "pointer" : "default",
              background: input.trim() ? AURORA : "rgba(255,255,255,.055)",
              border: input.trim() ? "none" : "1px solid rgba(255,255,255,.09)",
              display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: input.trim() ? "0 4px 24px rgba(91,140,255,.45)" : "none",
              transition: "all .22s ease",
            }}>
            <Send size={18} color={input.trim() ? "white" : "rgba(255,255,255,.35)"} />
          </button>
        </div>
      </div>
    </div>
  );
}
