// Design contract: guidelines/Guidelines.md
// Page: A-6 对话动态态 · 语音助手的灵魂
// Reused: AuroraOrb, GlassCard, AURORA*, TEAL, FG1/2/3, DIV, KEYFRAMES, AIBadge
// New: ThinkingBubble, StreamingBubble, ProcessArea, ConfirmBar,
//      ProactiveBubble, ErrorBubble + all demo wrappers

import { useState, useEffect, CSSProperties, ReactNode } from "react";
import { RefreshCw, Check, X, ChevronDown, ChevronRight, AlertTriangle, Lightbulb } from "lucide-react";

// ─── Design Tokens (§3 Guidelines.md) ────────────────────────────────────────
const AURORA       = "linear-gradient(135deg,#5BE9FF 0%,#5B8CFF 33%,#9A6BFF 66%,#FF6BD6 100%)";
const AURORA_CONIC = "conic-gradient(from 0deg,#5BE9FF,#5B8CFF,#9A6BFF,#FF6BD6,#5BE9FF)";
const AURORA_TEXT: CSSProperties = {
  background: AURORA, WebkitBackgroundClip: "text",
  WebkitTextFillColor: "transparent", backgroundClip: "text",
};
const TEAL = "#46D6E0";
const FG1  = "rgba(255,255,255,0.92)";
const FG2  = "rgba(255,255,255,0.56)";
const FG3  = "rgba(255,255,255,0.32)";
const DIV  = "rgba(255,255,255,0.07)";

// ─── Keyframes (§8 §10) — extended for dialog animations ─────────────────────
const KEYFRAMES = `
  @keyframes aurora-breathe {
    0%,100%{opacity:.82;transform:scale(1)} 50%{opacity:1;transform:scale(1.038)}
  }
  @keyframes aurora-breathe-fast {
    0%,100%{opacity:.85;transform:scale(1)} 50%{opacity:1;transform:scale(1.045)}
  }
  @keyframes aurora-spin {
    from{transform:rotate(0deg)} to{transform:rotate(360deg)}
  }
  @keyframes aurora-spin-r {
    from{transform:rotate(360deg)} to{transform:rotate(0deg)}
  }
  @keyframes aurora-pulse {
    0%,100%{transform:scale(1);opacity:.86}
    25%{transform:scale(1.07);opacity:1}
    75%{transform:scale(0.96);opacity:.80}
  }
  @keyframes dot-bounce {
    0%,60%,100%{transform:translateY(0);opacity:.55}
    30%{transform:translateY(-7px);opacity:1}
  }
  @keyframes cursor-blink {
    0%,49%{opacity:1} 50%,100%{opacity:0}
  }
  @keyframes shimmer-lr {
    0%{transform:translateX(-130%)} 100%{transform:translateX(230%)}
  }
  @keyframes slide-up {
    from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:translateY(0)}
  }
  @keyframes step-spin {
    from{transform:rotate(0deg)} to{transform:rotate(360deg)}
  }
  @keyframes proactive-pulse {
    0%,100%{box-shadow:0 0 0 0 rgba(70,214,224,.3)}
    50%{box-shadow:0 0 0 6px rgba(70,214,224,.0)}
  }
  @keyframes check-pop {
    0%{transform:scale(0)} 70%{transform:scale(1.25)} 100%{transform:scale(1)}
  }
  * { scrollbar-width: thin; scrollbar-color: rgba(91,140,255,.22) transparent }
  @media(prefers-reduced-motion:reduce){*{animation-duration:.01ms!important}}
`;

// ─── AuroraOrb (reused §9, §10) ──────────────────────────────────────────────
type OrbState = "idle" | "thinking" | "speaking";
function AuroraOrb({ state = "idle", size = 40 }: { state?: OrbState; size?: number }) {
  const thinking = state === "thinking", speaking = state === "speaking";
  const glowMult = speaking ? 1.35 : 1;
  const outerAnim = thinking ? "aurora-breathe-fast 1.4s ease-in-out infinite"
                  : speaking  ? "aurora-pulse 0.72s ease-in-out infinite"
                  :             "aurora-breathe 4s ease-in-out infinite";
  const haloSpeed = thinking ? "1.6s" : "8s";
  const innerSpeed = thinking ? "1.1s" : "5s";
  const ctSpeed = thinking ? "0.8s" : "3.8s";
  const s = size;
  return (
    <div style={{ position: "relative", width: s, height: s, flexShrink: 0 }}>
      <div style={{ position: "absolute", inset: -s*.52, borderRadius: "50%", background: `radial-gradient(circle,rgba(91,140,255,${.20*glowMult}) 0%,rgba(154,107,255,${.11*glowMult}) 40%,transparent 70%)`, animation: outerAnim, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: -s*.06, borderRadius: "50%", background: AURORA_CONIC, opacity: thinking?.52:.26, filter: `blur(${s*.115}px)`, animation: `aurora-spin ${haloSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: 0, borderRadius: "50%", background: `radial-gradient(circle at 36% 28%,rgba(255,255,255,.44) 0%,rgba(91,233,255,.22) 28%,rgba(91,140,255,.18) 56%,rgba(154,107,255,.26) 78%,rgba(255,107,214,.14) 100%)`, backdropFilter: "blur(14px)", WebkitBackdropFilter: "blur(14px)", border: "1px solid rgba(255,255,255,.24)", boxShadow: `0 0 ${s*.32*glowMult}px rgba(91,142,255,.52),0 0 ${s*.70*glowMult}px rgba(154,107,255,.22),inset 0 0 ${s*.24}px rgba(91,233,255,.20),inset 0 ${s*.012}px 0 rgba(255,255,255,.34)`, animation: outerAnim, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: s*.16, borderRadius: "50%", background: AURORA_CONIC, opacity: .70, filter: `blur(${s*.036}px)`, animation: `aurora-spin ${innerSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: s*.28, borderRadius: "50%", background: `conic-gradient(from 180deg,#9A6BFF,#5B8CFF,#5BE9FF,#FF6BD6,#9A6BFF)`, opacity: .54, filter: `blur(${s*.028}px)`, animation: `aurora-spin-r ${ctSpeed} linear infinite`, pointerEvents: "none" }} />
      <div style={{ position: "absolute", top: "9%", left: "13%", width: "44%", height: "33%", borderRadius: "50%", background: "radial-gradient(ellipse,rgba(255,255,255,.70) 0%,transparent 100%)", filter: "blur(2px)", pointerEvents: "none" }} />
    </div>
  );
}

// ─── GlassCard (reused §6) ────────────────────────────────────────────────────
function GlassCard({ children, p = 0, r = 22, style }: { children?: ReactNode; p?: number; r?: number; style?: CSSProperties }) {
  return (
    <div style={{
      padding: p, borderRadius: r, overflow: "hidden",
      background: "rgba(255,255,255,.056)",
      backdropFilter: "blur(32px)", WebkitBackdropFilter: "blur(32px)",
      border: "1px solid rgba(255,255,255,.10)",
      borderTop: "1px solid rgba(255,255,255,.17)",
      borderLeft: "1px solid rgba(255,255,255,.13)",
      boxShadow: "0 8px 40px rgba(0,0,0,.50),0 2px 12px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.13)",
      ...style,
    }}>{children}</div>
  );
}

const HR = () => <div style={{ height: 1, background: DIV }} />;

// AI-generated content badge (§5)
function AIBadge({ label }: { label: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 10 }}>
      <div style={{ width: 13, height: 13, borderRadius: 4, background: AURORA, flexShrink: 0 }} />
      <span style={{ ...AURORA_TEXT, fontSize: 10, fontWeight: 700, letterSpacing: ".09em" }}>{label}</span>
    </div>
  );
}

// ─── Bubble primitives ────────────────────────────────────────────────────────

// User message bubble (right-aligned)
function UserBubble({ text }: { text: string }) {
  return (
    <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 14 }}>
      <div style={{ maxWidth: "76%", padding: "11px 16px", borderRadius: "18px 18px 4px 18px", background: "rgba(70,214,224,.12)", border: "1px solid rgba(70,214,224,.22)", backdropFilter: "blur(16px)", WebkitBackdropFilter: "blur(16px)", boxShadow: "0 4px 16px rgba(0,0,0,.22)" }}>
        <div style={{ fontSize: 14, lineHeight: 1.65, color: FG1 }}>{text}</div>
      </div>
    </div>
  );
}

// AI base bubble (left-aligned, orb avatar)
function AIBubbleBase({ children, orbState = "idle", style }: { children: ReactNode; orbState?: OrbState; style?: CSSProperties }) {
  return (
    <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
      <div style={{ width: 30, height: 30, flexShrink: 0, marginTop: 2 }}>
        <AuroraOrb state={orbState} size={30} />
      </div>
      <div style={{
        flex: 1, padding: "13px 15px",
        borderRadius: "4px 18px 18px 18px",
        background: "rgba(255,255,255,.062)",
        border: "1px solid rgba(255,255,255,.09)",
        borderTop: "1px solid rgba(255,255,255,.16)",
        backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
        boxShadow: "0 4px 20px rgba(0,0,0,.30),inset 0 1px 0 rgba(255,255,255,.10)",
        position: "relative", overflow: "hidden",
        ...style,
      }}>
        {children}
      </div>
    </div>
  );
}

// State label (small, above each demo cell)
function StateLabel({ num, title, badge, badgeColor = FG3 }: { num: string; title: string; badge?: string; badgeColor?: string }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
      <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: FG3, letterSpacing: ".12em" }}>{num}</span>
      <div style={{ width: 3, height: 14, background: AURORA, borderRadius: 2 }} />
      <span style={{ fontSize: 12.5, fontWeight: 600, color: FG2 }}>{title}</span>
      {badge && (
        <span style={{ padding: "2px 8px", borderRadius: 6, background: `${badgeColor}14`, border: `1px solid ${badgeColor}30`, fontSize: 10, color: badgeColor, fontWeight: 500 }}>{badge}</span>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// A-6.1 · THINKING BUBBLE (慢响应即时反馈)
// ═══════════════════════════════════════════════════════════════════════════════

function ThinkingDots() {
  return (
    <div style={{ display: "flex", gap: 5, alignItems: "center", padding: "2px 0" }}>
      {[0, 1, 2].map(i => (
        <div key={i} style={{
          width: 7, height: 7, borderRadius: "50%",
          background: FG2,
          animation: `dot-bounce 1.5s ease-in-out ${i * 0.18}s infinite`,
        }} />
      ))}
    </div>
  );
}

function ThinkingDemo() {
  return (
    <div>
      <UserBubble text="固态电池 2027 年能量产吗？" />
      <AIBubbleBase orbState="thinking">
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <ThinkingDots />
          <span style={{ fontSize: 13, color: FG3 }}>正在思考…</span>
        </div>
        <div style={{ fontSize: 11, color: FG3, marginTop: 6 }}>这个问题较复杂，正在整理信息</div>
      </AIBubbleBase>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// A-6.2 · STREAMING BUBBLE (流式逐字 + 虹彩光标)
// ═══════════════════════════════════════════════════════════════════════════════

const STREAM_TEXT = "固态电池的主要技术路线有三种：氧化物（LLZO）、硫化物与聚合物路线。目前宁德时代、丰田等主要厂商均已公开各自的技术路径选择，2027年小批量量产技术上可行，但…";

function StreamingDemo() {
  const [shown, setShown] = useState(28);

  useEffect(() => {
    if (shown >= STREAM_TEXT.length) {
      const t = setTimeout(() => setShown(20), 1800);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setShown(n => n + 1), 28);
    return () => clearTimeout(t);
  }, [shown]);

  const visible = STREAM_TEXT.slice(0, shown);

  return (
    <div>
      <UserBubble text="固态电池的技术路线有哪些？" />
      <AIBubbleBase orbState="idle">
        {/* Shimmer sweep — AI流式微光 (§5 allowed) */}
        <div style={{ position: "absolute", inset: 0, width: "32%", background: "linear-gradient(90deg,transparent,rgba(91,233,255,.06),transparent)", animation: "shimmer-lr 2.8s ease-in-out infinite", pointerEvents: "none" }} />
        <div style={{ fontSize: 14, lineHeight: 1.72, color: FG1, position: "relative" }}>
          {visible}
          {/* Blinking teal cursor (§5: 流式虹彩光标) */}
          <span style={{ display: "inline-block", width: 2, height: "1.1em", background: TEAL, verticalAlign: "text-bottom", marginLeft: 1, borderRadius: 1, animation: "cursor-blink 1s step-end infinite" }} />
        </div>
        <div style={{ fontSize: 10.5, color: FG3, marginTop: 8, position: "relative" }}>
          <span style={{ fontFamily: "'JetBrains Mono',monospace" }}>{shown}</span> 字 · 正在生成…
        </div>
      </AIBubbleBase>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// A-6.3 · PROCESS AREA (复杂任务过程区)
// ═══════════════════════════════════════════════════════════════════════════════

type StepStatus = "done" | "active" | "pending";

const STAGES = [
  {
    id: 1, label: "理解需求", status: "done" as StepStatus,
    summary: "\"查询固态电池量产时间\"", steps: [],
  },
  {
    id: 2, label: "规划步骤", status: "done" as StepStatus,
    summary: "制定3个来源搜索方向", steps: [],
  },
  {
    id: 3, label: "执行任务", status: "active" as StepStatus,
    summary: "", steps: [
      { label: "查询盖世汽车",      status: "done"    as StepStatus },
      { label: "查询第一财经",      status: "done"    as StepStatus },
      { label: "查询 IEEE Spectrum", status: "active"  as StepStatus },
      { label: "查询财联社",        status: "pending" as StepStatus },
    ],
  },
  {
    id: 4, label: "整理结果", status: "pending" as StepStatus,
    summary: "", steps: [],
  },
];

const STAGE_ICON: Record<StepStatus, ReactNode> = {
  done:    <Check size={10} color="#34D399" />,
  active:  <div style={{ width: 8, height: 8, borderRadius: "50%", background: TEAL, animation: "aurora-breathe 1.2s ease-in-out infinite" }} />,
  pending: <div style={{ width: 8, height: 8, borderRadius: "50%", border: "1.5px solid rgba(255,255,255,.22)" }} />,
};

const STAGE_COLOR: Record<StepStatus, string> = {
  done: "#34D399", active: TEAL, pending: FG3,
};

function ProcessInProgress() {
  return (
    <AIBubbleBase orbState="thinking">
      <div style={{ fontSize: 11.5, color: FG3, marginBottom: 12 }}>正在处理您的请求…</div>
      {STAGES.map((stage, si) => (
        <div key={stage.id} style={{ marginBottom: si < STAGES.length - 1 ? 10 : 0 }}>
          {/* Stage row */}
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ width: 18, height: 18, borderRadius: 5, background: stage.status === "done" ? "rgba(52,211,153,.15)" : stage.status === "active" ? "rgba(70,214,224,.15)" : "rgba(255,255,255,.05)", border: `1px solid ${stage.status === "done" ? "rgba(52,211,153,.35)" : stage.status === "active" ? "rgba(70,214,224,.30)" : "rgba(255,255,255,.10)"}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "all .25s" }}>
              {STAGE_ICON[stage.status]}
            </div>
            <span style={{ fontSize: 12.5, fontWeight: stage.status === "active" ? 600 : 400, color: STAGE_COLOR[stage.status] }}>{stage.label}</span>
            {stage.status === "done" && stage.summary && (
              <span style={{ fontSize: 11, color: FG3 }}>— {stage.summary}</span>
            )}
            {stage.status === "active" && (
              <div style={{ marginLeft: 4, width: 12, height: 12, border: `1.5px solid ${TEAL}`, borderTopColor: "transparent", borderRadius: "50%", animation: "step-spin .9s linear infinite", flexShrink: 0 }} />
            )}
          </div>

          {/* Sub-steps (only for active stage) */}
          {stage.status === "active" && stage.steps.length > 0 && (
            <div style={{ marginLeft: 26, marginTop: 8, display: "flex", flexDirection: "column", gap: 5 }}>
              {stage.steps.map((step, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 7 }}>
                  <div style={{ width: 14, height: 14, borderRadius: 4, background: step.status === "done" ? "rgba(52,211,153,.12)" : step.status === "active" ? "rgba(70,214,224,.10)" : "rgba(255,255,255,.04)", border: `1px solid ${step.status === "done" ? "rgba(52,211,153,.30)" : step.status === "active" ? "rgba(70,214,224,.25)" : "rgba(255,255,255,.08)"}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    {step.status === "done" ? <Check size={8} color="#34D399" /> : step.status === "active" ? <div style={{ width: 5, height: 5, borderRadius: "50%", background: TEAL, animation: "aurora-breathe 1s ease-in-out infinite" }} /> : <div style={{ width: 4, height: 4, borderRadius: "50%", background: "rgba(255,255,255,.20)" }} />}
                  </div>
                  <span style={{ fontSize: 11.5, color: step.status === "done" ? FG2 : step.status === "active" ? FG1 : FG3, fontWeight: step.status === "active" ? 500 : 400 }}>
                    {step.status === "active" && "正在"}{step.label}{step.status === "active" && "…"}
                  </span>
                  {step.status === "active" && <div style={{ marginLeft: 2, width: 10, height: 10, border: `1.5px solid ${TEAL}`, borderTopColor: "transparent", borderRadius: "50%", animation: "step-spin 1s linear infinite", flexShrink: 0 }} />}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </AIBubbleBase>
  );
}

function ProcessComplete({ drivingMode = false }: { drivingMode?: boolean }) {
  const [expanded, setExpanded] = useState(false);
  const totalSteps = STAGES.reduce((acc, s) => acc + Math.max(1, s.steps.length), 0);

  const allDone = STAGES.map(s => ({ ...s, status: "done" as StepStatus, summary: s.summary || "已完成" }));

  return (
    <AIBubbleBase orbState="idle">
      {/* Collapsed summary row — always visible */}
      <button
        onClick={() => !drivingMode && setExpanded(v => !v)}
        style={{ display: "flex", alignItems: "center", gap: 8, background: "none", border: "none", cursor: drivingMode ? "default" : "pointer", padding: 0, width: "100%", textAlign: "left", color: FG1, fontFamily: "'Inter',sans-serif", marginBottom: expanded ? 12 : 0 }}>
        <div style={{ width: 18, height: 18, borderRadius: 5, background: "rgba(52,211,153,.15)", border: "1px solid rgba(52,211,153,.30)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <Check size={10} color="#34D399" />
        </div>
        <span style={{ fontSize: 12.5, color: FG2, flex: 1 }}>
          处理过程 <span style={{ fontFamily: "'JetBrains Mono',monospace", color: TEAL }}>({totalSteps}</span><span style={{ color: FG2 }}>步)</span>
        </span>
        {drivingMode ? (
          <span style={{ fontSize: 10.5, color: FG3, padding: "2px 8px", borderRadius: 6, background: "rgba(255,165,0,.10)", border: "1px solid rgba(255,165,0,.20)" }}>行车态</span>
        ) : (
          <ChevronDown size={13} color={FG3} style={{ transform: expanded ? "rotate(180deg)" : "none", transition: "transform .2s", flexShrink: 0 }} />
        )}
      </button>

      {/* Expanded timeline */}
      {expanded && !drivingMode && (
        <div style={{ animation: "slide-up .22s ease" }}>
          {allDone.map((stage, si) => (
            <div key={stage.id} style={{ display: "flex", gap: 10, alignItems: "flex-start", marginBottom: si < allDone.length - 1 ? 10 : 0 }}>
              {/* Connector */}
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flexShrink: 0 }}>
                <div style={{ width: 18, height: 18, borderRadius: 5, background: "rgba(52,211,153,.15)", border: "1px solid rgba(52,211,153,.30)", display: "flex", alignItems: "center", justifyContent: "center", animation: "check-pop .3s ease" }}>
                  <Check size={10} color="#34D399" />
                </div>
                {si < allDone.length - 1 && <div style={{ width: 1, height: 16, background: "rgba(52,211,153,.20)", margin: "3px 0" }} />}
              </div>
              <div style={{ paddingTop: 1 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: "#34D399", marginBottom: 2 }}>{stage.label}</div>
                <div style={{ fontSize: 11, color: FG3 }}>{stage.summary}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Answer text follows */}
      <div style={{ marginTop: expanded ? 14 : 10 }}>
        <HR />
        <div style={{ marginTop: 10, fontSize: 14, lineHeight: 1.72, color: FG1 }}>
          根据多来源分析，固态电池2027年量产<span style={{ fontWeight: 600 }}>技术上可行</span>，但规模化量产大概率推迟至2030年后。
        </div>
      </div>
    </AIBubbleBase>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// A-6.4 · CONFIRMATION BAR (危险车控确认)
// ═══════════════════════════════════════════════════════════════════════════════

function ConfirmDemo() {
  const [result, setResult] = useState<"confirmed" | "cancelled" | null>(null);

  return (
    <div>
      <UserBubble text="打开后备箱" />
      {/* Warning AI bubble */}
      <AIBubbleBase orbState="speaking" style={{ border: "1px solid rgba(245,158,11,.32)", borderTop: "1px solid rgba(245,158,11,.45)", boxShadow: "0 4px 20px rgba(0,0,0,.30),0 0 16px rgba(245,158,11,.12),inset 0 1px 0 rgba(255,255,255,.10)" }}>
        <div style={{ display: "flex", alignItems: "flex-start", gap: 10, marginBottom: 14 }}>
          <AlertTriangle size={16} color="#F59E0B" style={{ flexShrink: 0, marginTop: 1 }} />
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: FG1, marginBottom: 4 }}>
              即将打开后备箱
            </div>
            <div style={{ fontSize: 13, color: FG2, lineHeight: 1.6 }}>
              此操作将解锁并弹开后备箱盖，当前车速 <span style={{ fontFamily: "'JetBrains Mono',monospace", color: TEAL }}>0 km/h</span> · 已泊车
            </div>
          </div>
        </div>

        {/* Result feedback */}
        {result && (
          <div style={{ marginBottom: 12, padding: "8px 12px", borderRadius: 10, background: result === "confirmed" ? "rgba(52,211,153,.10)" : "rgba(107,114,128,.08)", border: `1px solid ${result === "confirmed" ? "rgba(52,211,153,.25)" : "rgba(255,255,255,.10)"}`, display: "flex", alignItems: "center", gap: 8, animation: "slide-up .22s ease" }}>
            {result === "confirmed" ? <Check size={13} color="#34D399" /> : <X size={13} color={FG3} />}
            <span style={{ fontSize: 12.5, color: result === "confirmed" ? "#34D399" : FG2 }}>
              {result === "confirmed" ? "已确认，后备箱正在开启" : "已取消操作"}
            </span>
          </div>
        )}

        {/* Confirm / Cancel buttons — §11 ≥48px 车规触控 */}
        <div style={{ display: "flex", gap: 10 }}>
          <button
            onClick={() => setResult("cancelled")}
            style={{
              flex: 1, height: 50, borderRadius: 14, cursor: "pointer",
              background: "rgba(255,255,255,.06)",
              border: "1px solid rgba(255,255,255,.14)",
              color: FG2, fontSize: 14, fontWeight: 500,
              fontFamily: "'Inter','Noto Sans SC',sans-serif",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 7,
              transition: "all .18s",
            }}>
            <X size={15} />
            取消
          </button>
          <button
            onClick={() => setResult("confirmed")}
            style={{
              flex: 2, height: 50, borderRadius: 14, cursor: "pointer",
              background: "rgba(245,158,11,.14)",
              border: "1px solid rgba(245,158,11,.38)",
              color: "#F59E0B", fontSize: 14, fontWeight: 600,
              fontFamily: "'Inter','Noto Sans SC',sans-serif",
              display: "flex", alignItems: "center", justifyContent: "center", gap: 7,
              transition: "all .18s",
              boxShadow: "0 0 16px rgba(245,158,11,.12)",
            }}>
            <Check size={15} />
            确认开启后备箱
          </button>
        </div>
      </AIBubbleBase>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// A-6.5 · PROACTIVE BUBBLES (主动播报)
// ═══════════════════════════════════════════════════════════════════════════════

function ProactiveAlert() {
  return (
    <div>
      {/* Proactive bubble — independent, not a reply */}
      <div style={{
        display: "flex", gap: 10, alignItems: "flex-start",
        padding: "14px 15px",
        borderRadius: "14px 18px 18px 14px",
        background: "rgba(245,158,11,.08)",
        border: "1px solid rgba(245,158,11,.24)",
        borderLeft: "3px solid #F59E0B",
        backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
        boxShadow: "0 4px 20px rgba(0,0,0,.24),0 0 12px rgba(245,158,11,.08)",
        animation: "proactive-pulse 3s ease-in-out infinite",
      }}>
        <div style={{ flexShrink: 0, marginTop: 1 }}>
          <div style={{ width: 30, height: 30 }}><AuroraOrb state="speaking" size={30} /></div>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 6 }}>
            <span style={{ fontSize: 13 }}>⚠️</span>
            <span style={{ fontSize: 11, fontWeight: 700, color: "#F59E0B", letterSpacing: ".05em" }}>主动播报 · 行程预警</span>
          </div>
          <div style={{ fontSize: 14, color: FG1, lineHeight: 1.65, marginBottom: 5 }}>
            前方 <span style={{ fontFamily: "'JetBrains Mono',monospace", fontWeight: 700, color: "#F59E0B" }}>2km</span> 处有交通事故，当前拥堵 <span style={{ fontFamily: "'JetBrains Mono',monospace", color: "#F59E0B" }}>+12分钟</span>
          </div>
          <div style={{ fontSize: 12.5, color: FG2 }}>建议提前并线至左道，可绕行湖滨路节省约8分钟</div>
          <div style={{ marginTop: 10, display: "flex", gap: 8 }}>
            <button style={{ padding: "6px 14px", borderRadius: 10, background: "rgba(245,158,11,.14)", border: "1px solid rgba(245,158,11,.30)", fontSize: 12, color: "#F59E0B", fontWeight: 600, cursor: "pointer", fontFamily: "'Inter','Noto Sans SC',sans-serif" }}>更换路线</button>
            <button style={{ padding: "6px 14px", borderRadius: 10, background: "rgba(255,255,255,.05)", border: "1px solid rgba(255,255,255,.09)", fontSize: 12, color: FG2, cursor: "pointer", fontFamily: "'Inter','Noto Sans SC',sans-serif" }}>忽略</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ProactiveReport() {
  return (
    <div>
      {/* Task-completion proactive bubble */}
      <div style={{
        display: "flex", gap: 10, alignItems: "flex-start",
        padding: "14px 15px",
        borderRadius: "14px 18px 18px 14px",
        background: "rgba(70,214,224,.07)",
        border: "1px solid rgba(70,214,224,.22)",
        borderLeft: `3px solid ${TEAL}`,
        backdropFilter: "blur(20px)", WebkitBackdropFilter: "blur(20px)",
        boxShadow: "0 4px 20px rgba(0,0,0,.24),0 0 12px rgba(70,214,224,.08)",
        marginBottom: 12,
      }}>
        <div style={{ flexShrink: 0, marginTop: 1 }}>
          <div style={{ width: 30, height: 30 }}><AuroraOrb state="idle" size={30} /></div>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 6 }}>
            <Lightbulb size={13} color={TEAL} />
            <span style={{ fontSize: 11, fontWeight: 700, color: TEAL, letterSpacing: ".05em" }}>主动播报 · 任务完成</span>
          </div>
          <div style={{ fontSize: 14, color: FG1, lineHeight: 1.65 }}>
            你委托的<span style={{ fontWeight: 600 }}>固态电池深度调研</span>完成了，共引用5篇来源，置信度「中」
          </div>
        </div>
      </div>

      {/* Attached mini-report card */}
      <div style={{ marginLeft: 40 }}>
        <GlassCard r={16} style={{ overflow: "hidden" }}>
          <div style={{ padding: "12px 14px" }}>
            <AIBadge label="AI · 深度调研报告" />
            <div style={{ fontSize: 13, fontWeight: 600, color: FG1, marginBottom: 6 }}>固态电池 2027 年量产可行性</div>
            <div style={{ fontSize: 12, color: FG2, lineHeight: 1.60, marginBottom: 10 }}>
              技术路线已确立，但量产良率与成本仍是决定性障碍。2027年小批量可行，规模化推迟至2030年后。
            </div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ display: "flex", gap: 8 }}>
                <span style={{ padding: "3px 8px", borderRadius: 6, background: "rgba(245,158,11,.10)", border: "1px solid rgba(245,158,11,.24)", fontSize: 10.5, color: "#F59E0B", fontWeight: 600 }}>置信度 中</span>
                <span style={{ fontSize: 10.5, color: FG3 }}>5篇引用 · 共4节</span>
              </div>
              <button style={{ display: "flex", alignItems: "center", gap: 5, padding: "5px 12px", borderRadius: 10, background: "rgba(70,214,224,.10)", border: "1px solid rgba(70,214,224,.24)", fontSize: 11.5, color: TEAL, cursor: "pointer", fontFamily: "'Inter',sans-serif" }}>
                查看完整报告 <ChevronRight size={11} />
              </button>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// A-6.6 · ERROR / TIMEOUT BUBBLE
// ═══════════════════════════════════════════════════════════════════════════════

function ErrorDemo() {
  const [retrying, setRetrying] = useState(false);

  const handleRetry = () => {
    setRetrying(true);
    setTimeout(() => setRetrying(false), 2000);
  };

  return (
    <div>
      <UserBubble text="帮我查一下今天的天气" />
      <AIBubbleBase orbState="idle" style={{ border: "1px solid rgba(239,68,68,.28)", borderTop: "1px solid rgba(239,68,68,.40)", boxShadow: "0 4px 20px rgba(0,0,0,.30),0 0 12px rgba(239,68,68,.08),inset 0 1px 0 rgba(255,255,255,.10)" }}>
        <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
          <div style={{ width: 22, height: 22, borderRadius: 6, background: "rgba(239,68,68,.14)", border: "1px solid rgba(239,68,68,.28)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <X size={11} color="#EF4444" />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13.5, fontWeight: 600, color: "#EF4444", marginBottom: 4 }}>请求超时</div>
            <div style={{ fontSize: 13, color: FG2, lineHeight: 1.6 }}>
              当前网络连接不稳定，无法获取天气数据。已重试 <span style={{ fontFamily: "'JetBrains Mono',monospace" }}>2</span> 次。
            </div>
            <div style={{ marginTop: 10, display: "flex", gap: 8, alignItems: "center" }}>
              <button
                onClick={handleRetry}
                style={{
                  display: "flex", alignItems: "center", gap: 6,
                  padding: "7px 14px", borderRadius: 10,
                  background: "rgba(239,68,68,.10)", border: "1px solid rgba(239,68,68,.28)",
                  fontSize: 12.5, color: "#EF4444", fontWeight: 600,
                  cursor: "pointer", fontFamily: "'Inter',sans-serif",
                }}>
                <RefreshCw size={12} style={{ animation: retrying ? "step-spin 1s linear infinite" : "none" }} />
                {retrying ? "重试中…" : "重试"}
              </button>
              <span style={{ fontSize: 11.5, color: FG3 }}>或稍后再说</span>
            </div>
          </div>
        </div>
      </AIBubbleBase>
    </div>
  );
}

// ─── Section title (compact) ──────────────────────────────────────────────────
function SectionTitle({ title, sub }: { title: string; sub?: string }) {
  return (
    <div style={{ marginBottom: 24 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 4 }}>
        <div style={{ width: 3, height: 18, background: AURORA, borderRadius: 2 }} />
        <h2 style={{ fontSize: 16, fontWeight: 500, margin: 0, color: FG1, letterSpacing: ".03em" }}>{title}</h2>
      </div>
      {sub && <p style={{ fontSize: 12.5, color: FG3, margin: 0, paddingLeft: 15, lineHeight: 1.6 }}>{sub}</p>}
    </div>
  );
}

// ─── Demo cell wrapper ────────────────────────────────────────────────────────
function DemoCell({ num, label, badge, badgeColor, children }: {
  num: string; label: string; badge?: string; badgeColor?: string; children: ReactNode;
}) {
  return (
    <div>
      <StateLabel num={num} title={label} badge={badge} badgeColor={badgeColor} />
      <GlassCard r={22} p={16}>
        {children}
      </GlassCard>
    </div>
  );
}

// ─── App — A-6 Showcase ───────────────────────────────────────────────────────
export default function App() {
  const [showDriving, setShowDriving] = useState(false);

  return (
    <div style={{ minHeight: "100vh", fontFamily: "'Inter','Noto Sans SC',-apple-system,sans-serif", color: FG1, background: "linear-gradient(155deg,#06080F 0%,#0A0E1A 52%,#080D18 100%)" }}>
      <style>{KEYFRAMES}</style>

      {/* Atmosphere */}
      <div aria-hidden style={{ position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0 }}>
        <div style={{ position: "absolute", bottom: "10%", left: "12%",  width: 600, height: 420, background: "radial-gradient(circle,rgba(91,140,255,.10) 0%,transparent 68%)", filter: "blur(52px)" }} />
        <div style={{ position: "absolute", top: "8%",   right: "10%",  width: 480, height: 360, background: "radial-gradient(circle,rgba(91,233,255,.07) 0%,transparent 68%)", filter: "blur(56px)" }} />
        <div style={{ position: "absolute", top: "44%",  left: "36%",   width: 640, height: 480, background: "radial-gradient(circle,rgba(154,107,255,.06) 0%,transparent 68%)", filter: "blur(64px)" }} />
      </div>

      {/* Header */}
      <header style={{ position: "sticky", top: 0, zIndex: 30, height: 56, padding: "0 48px", display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(6,8,15,.80)", backdropFilter: "blur(28px)", WebkitBackdropFilter: "blur(28px)", borderBottom: `1px solid ${DIV}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 26, height: 26 }}><AuroraOrb state="idle" size={26} /></div>
          <span style={{ ...AURORA_TEXT, fontSize: 14, fontWeight: 600 }}>Aurora Glass</span>
          <span style={{ fontSize: 13, color: FG3, fontWeight: 300 }}>· A-6 对话动态态 · 语音助手的灵魂</span>
        </div>
        {/* Driving mode toggle */}
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 12, color: FG3 }}>行车态模拟</span>
          <button onClick={() => setShowDriving(d => !d)} style={{ width: 44, height: 24, borderRadius: 12, cursor: "pointer", background: showDriving ? "rgba(245,165,0,.28)" : "rgba(255,255,255,.07)", border: `1px solid ${showDriving ? "rgba(245,165,0,.50)" : "rgba(255,255,255,.12)"}`, position: "relative", transition: "all .25s ease" }}>
            <div style={{ position: "absolute", top: 3, left: showDriving ? 22 : 3, width: 16, height: 16, borderRadius: "50%", background: showDriving ? "#F59E0B" : "rgba(255,255,255,.40)", transition: "left .25s ease" }} />
          </button>
        </div>
      </header>

      {/* Content */}
      <div style={{ position: "relative", zIndex: 1, maxWidth: 1440, margin: "0 auto", padding: "44px 48px 100px" }}>

        <div style={{ marginBottom: 32 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 5 }}>
            <span style={{ fontFamily: "'JetBrains Mono',monospace", fontSize: 10.5, color: FG3, letterSpacing: ".12em" }}>A-6</span>
            <div style={{ width: 1, height: 14, background: "rgba(255,255,255,.10)" }} />
            <div style={{ width: 3, height: 18, background: AURORA, borderRadius: 2 }} />
            <h2 style={{ fontSize: 17, fontWeight: 500, margin: 0 }}>对话动态态 — 语音助手的灵魂</h2>
          </div>
          <p style={{ fontSize: 12.5, color: FG3, margin: 0, paddingLeft: 52, lineHeight: 1.6 }}>
            6种对话状态同屏展示。右上角「行车态」开关可观察 A-6.3 过程区的强制单行降级行为。
          </p>
        </div>

        {/* ── Row 1: Thinking · Streaming · Error ── */}
        <div style={{ marginBottom: 28 }}>
          <SectionTitle title="即时反馈态 + 错误态" sub="前三种：等待中的即时安抚 / 流式生成 / 网络错误" />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20 }}>
            <DemoCell num="A-6.1" label="思考中">
              <ThinkingDemo />
            </DemoCell>
            <DemoCell num="A-6.2" label="流式输出" badge="虹彩光标" badgeColor={TEAL}>
              <StreamingDemo />
            </DemoCell>
            <DemoCell num="A-6.6" label="错误 / 超时">
              <ErrorDemo />
            </DemoCell>
          </div>
        </div>

        {/* ── Row 2: Process Area ── */}
        <div style={{ marginBottom: 28 }}>
          <SectionTitle title="过程区 — 复杂任务可见性" sub="进行中展开四阶段子步骤；完成后默认折叠，可展开查看完整时间线；行车态强制单行" />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            <DemoCell num="A-6.3" label="进行中（展开态）">
              <UserBubble text="固态电池 2027 年能量产吗？" />
              <ProcessInProgress />
            </DemoCell>
            <div>
              <StateLabel num="A-6.3" label="已完成（折叠 / 展开）" badge={showDriving ? "行车态·单行锁定" : undefined} badgeColor="#F59E0B" />
              <GlassCard r={22} p={16}>
                <ProcessComplete drivingMode={showDriving} />
              </GlassCard>
            </div>
          </div>
        </div>

        {/* ── Row 3: Confirmation ── */}
        <div style={{ marginBottom: 28 }}>
          <SectionTitle title="确认条 — 危险车控" sub="危险操作必须二次确认；按钮高度 ≥50px（§11 车规触控目标）；琥珀色警告框" />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            <DemoCell num="A-6.4" label="确认 / 取消（可点击）" badge="可交互" badgeColor={TEAL}>
              <ConfirmDemo />
            </DemoCell>
            {/* Spec notes */}
            <div style={{ padding: "20px 0" }}>
              <div style={{ fontSize: 12.5, fontWeight: 600, color: FG2, marginBottom: 16 }}>设计规范</div>
              {[
                { rule: "触控高度", value: "≥ 50px（泊车）/ 56px（行车）" },
                { rule: "确认按钮",  value: "琥珀警告色，flex:2 宽度优势" },
                { rule: "取消按钮",  value: "中性玻璃，flex:1" },
                { rule: "气泡边框",  value: "rgba(245,158,11,.32) 琥珀描边" },
                { rule: "车速校验",  value: "车速>0 时禁用危险操作按钮" },
                { rule: "二次弹出",  value: "车速>5km/h 时升级为全屏拦截" },
              ].map((s, i) => (
                <div key={i} style={{ display: "flex", gap: 10, marginBottom: 10 }}>
                  <span style={{ fontSize: 11, color: FG3, flexShrink: 0, width: 72, textAlign: "right", lineHeight: 1.6 }}>{s.rule}</span>
                  <div style={{ width: 1, background: DIV, flexShrink: 0 }} />
                  <span style={{ fontSize: 12, color: FG2, lineHeight: 1.6 }}>{s.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── Row 4: Proactive ── */}
        <div>
          <SectionTitle title="主动播报 — 💡 独立通知气泡" sub="不依托用户提问主动触发，驾驶预警 + 委托任务完成；后者附报告卡" />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            <DemoCell num="A-6.5" label="行程预警（琥珀）">
              <ProactiveAlert />
            </DemoCell>
            <DemoCell num="A-6.5" label="任务完成（冷蓝）+ 报告卡挂载">
              <ProactiveReport />
            </DemoCell>
          </div>
        </div>

      </div>
    </div>
  );
}
